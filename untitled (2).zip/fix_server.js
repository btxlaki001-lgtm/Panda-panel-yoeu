import fs from 'fs/promises';

async function main() {
  let code = await fs.readFile('server.ts', 'utf8');

  // Replace CAST(... AS NUMERIC) which might fail in SQLite (SQLite uses REAL or integer, but CAST as NUMERIC might be fine? SQLite supports CAST(expr AS NUMERIC)).
  // Actually it's better to just leave it, SQLite supports it.
  
  // Let's remove the _postgresPool block in health endpoint
  const startIdx = code.indexOf('const pool = (global as any)._postgresPool;');
  if (startIdx !== -1) {
    const endIdx = code.indexOf('res.json({', startIdx);
    if (endIdx !== -1) {
      code = code.substring(0, startIdx) + '\n    ' + code.substring(endIdx);
    }
  }

  // Update health res.json to not use undefined vars
  code = code.replace(/selectedSocketPath: selectedHost,/g, 'selectedSocketPath: null,');
  code = code.replace(/socketPathExists,/g, 'socketPathExists: false,');
  code = code.replace(/actualSocketFileExists,/g, 'actualSocketFileExists: false,');
  code = code.replace(/cloudsqlAppDirListing,/g, 'cloudsqlAppDirListing: null,');
  code = code.replace(/instanceDirListing,/g, 'instanceDirListing: null,');
  code = code.replace(/select1Result,/g, 'select1Result: null,');
  code = code.replace(/currentDbAndSchema,/g, 'currentDbAndSchema: null,');
  code = code.replace(/usersTableExists,/g, 'usersTableExists: true,');
  code = code.replace(/physicalUsersColumns,/g, 'physicalUsersColumns: null,');
  code = code.replace(/error: connError,/g, 'error: null,');
  
  await fs.writeFile('server.ts', code);
}
main();
