const fs = require('fs');
let code = fs.readFileSync('restore_real_data_perfectly.ts', 'utf8');

// 1. Add seenReferralCodes
code = code.replace(
  'const seenMobiles = new Set<string>();',
  'const seenMobiles = new Set<string>();\n  const seenReferralCodes = new Set<string>();'
);

// 2. Filter out fake users
code = code.replace(
  'const parsed = parseUser(u);',
  `const parsed = parseUser(u);
    // Filter out fake users
    const lowerName = parsed.username.toLowerCase();
    if (lowerName === "testcustomer3" || lowerName === "testcustomer8" || lowerName === "demouser") {
      console.log(\`[SKIP] Skipping fake user: \${parsed.username}\`);
      continue;
    }`
);

// 3. Ensure unique referralCode
code = code.replace(
  'const dbUser = {',
  `
    let finalReferralCode = parsed.referralCode || \`REF\${parsed.id.slice(-6).toUpperCase()}\`;
    if (finalReferralCode.length > 20) finalReferralCode = finalReferralCode.substring(0, 20);
    let refCount = 1;
    while (seenReferralCodes.has(finalReferralCode.toUpperCase())) {
      finalReferralCode = \`\${finalReferralCode.substring(0, 15)}_\${refCount}\`;
      refCount++;
    }
    seenReferralCodes.add(finalReferralCode.toUpperCase());

    const dbUser = {`
);

// Update dbUser to use finalReferralCode
code = code.replace(
  'referralCode: parsed.referralCode || `REF${parsed.id.slice(-6).toUpperCase()}`,',
  'referralCode: finalReferralCode,'
);

fs.writeFileSync('restore_real_data_perfectly.ts', code);
console.log("Patched restore script!");
