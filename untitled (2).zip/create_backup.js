import pkg from 'pg';
import fs from 'fs';
const { Client } = pkg;

async function backup() {
  const client = new Client({
    host: process.env.SQL_HOST,
    user: process.env.SQL_USER,
    password: process.env.SQL_PASSWORD,
    database: 'cloud_sql_production_database'
  });

  try {
    await client.connect();
    console.log("Connected to production database...");
    const tables = ['users', 'bank_accounts', 'notifications', 'support_tickets', 'site_settings', 'transactions', 'login_history'];
    const backupData = {};

    for (const table of tables) {
      console.log(`Exporting table: ${table}...`);
      const res = await client.query(`SELECT * FROM ${table}`);
      backupData[table] = res.rows;
    }

    fs.writeFileSync('database_backup.json', JSON.stringify(backupData, null, 2));
    console.log("Backup successful! Saved as database_backup.json");
  } catch (err) {
    console.error("Backup failed", err);
  } finally {
    await client.end();
  }
}
backup();
