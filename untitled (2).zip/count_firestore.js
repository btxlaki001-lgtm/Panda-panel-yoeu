import { initializeApp, getApps, getApp } from "firebase/app";
import { getFirestore, collection, getDocs } from "firebase/firestore";
import fs from "fs";
import path from "path";

const configPath = path.join(process.cwd(), "firebase-applet-config.json");
if (!fs.existsSync(configPath)) {
    console.error("firebase-applet-config.json not found!");
    process.exit(1);
}

const config = JSON.parse(fs.readFileSync(configPath, "utf-8"));
const app = getApps().length === 0 ? initializeApp(config) : getApp();
const fdb = getFirestore(app, config.firestoreDatabaseId);

async function check() {
    try {
        const snap = await getDocs(collection(fdb, "users"));
        console.log("Firestore Users count:", snap.size);
    } catch (e) {
        console.error("Error reading Firestore:", e.message || e);
    }
}

check();
