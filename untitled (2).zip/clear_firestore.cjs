const { initializeApp } = require("firebase/app");
const { getFirestore, collection, getDocs, deleteDoc } = require("firebase/firestore");
const fs = require("fs");

async function run() {
  const cfg = JSON.parse(fs.readFileSync("firebase-applet-config.json", "utf-8"));
  const app = initializeApp(cfg);
  const db = getFirestore(app, cfg.firestoreDatabaseId);
  
  console.log("Clearing Firestore...");
  const snap = await getDocs(collection(db, "users"));
  for (const doc of snap.docs) {
    await deleteDoc(doc.ref);
  }
  console.log("Firestore users cleared.");
  process.exit(0);
}
run().catch(console.error);
