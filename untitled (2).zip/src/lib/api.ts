export async function apiFetch(...args: Parameters<typeof fetch>): Promise<Response> {
  let attempts = 0;
  const maxAttempts = 3;
  
  while (attempts < maxAttempts) {
    try {
      const response = await fetch(...args);
      
      if (response.status === 503) {
        let isDbError = false;
        try {
          const clone = response.clone();
          const data = await clone.json();
          if (data && data.error === "Database Connection Error") {
            isDbError = true;
          }
        } catch(e) {}
        
        if (isDbError) {
          attempts++;
          console.log(`[Network] Database waking up... Retrying request (${attempts}/${maxAttempts})`);
          window.dispatchEvent(new CustomEvent('db-waking-up', { 
            detail: { message: "Database is waking up (Power Save Mode)... Please wait." }
          }));
          await new Promise(resolve => setTimeout(resolve, 1500));
          continue;
        }
      }
      
      return response;
    } catch (err) {
      throw err;
    }
  }
  return fetch(...args);
}