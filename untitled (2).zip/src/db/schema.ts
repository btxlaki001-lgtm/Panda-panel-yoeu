import { sqliteTable, text, integer, real, index } from "drizzle-orm/sqlite-core";
import { relations } from "drizzle-orm";

export const users = sqliteTable("users", {
  id: text("id").primaryKey(),
  username: text("username").notNull().unique(),
  mobile: text("mobile").notNull().unique(),
  email: text("email").notNull(),
  passwordHash: text("password_hash").notNull(),
  referralCode: text("referral_code").notNull().unique(),
  referredBy: text("referred_by"),
  walletBalance: text("wallet_balance").notNull().default("0.00"),
  totalEarnings: text("total_earnings").notNull().default("0.00"),
  referralIncome: text("referral_income").notNull().default("0.00"),
  kycStatus: text("kyc_status", { enum: ["Pending", "Approved", "Not Submitted"] }).notNull().default("Not Submitted"),
  role: text("role", { enum: ["user", "admin"] }).notNull().default("user"),
  createdAt: integer("created_at", { mode: "timestamp" }).notNull().$defaultFn(() => new Date()),
  lastActive: integer("last_active", { mode: "timestamp" }).notNull().$defaultFn(() => new Date()),
  lastLogin: integer("last_login", { mode: "timestamp" }),
  ip: text("ip"),
  device: text("device"),
  loginHistory: text("login_history", { mode: "json" }).$type<Array<{ timestamp: string; ip?: string; device?: string; action?: string }>>().default([] as any),
  isOnline: integer("is_online", { mode: "boolean" }).notNull().default(false),
}, (table) => ({
  usernameIdx: index("username_idx").on(table.username),
  mobileIdx: index("mobile_idx").on(table.mobile),
  referralCodeIdx: index("referral_code_idx").on(table.referralCode),
}));

export const loginHistory = sqliteTable("login_history", {
  id: text("id").primaryKey(),
  userId: text("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  ip: text("ip"),
  device: text("device"),
  timestamp: integer("timestamp", { mode: "timestamp" }).notNull().$defaultFn(() => new Date()),
}, (table) => ({
  userIdIdx: index("login_user_id_idx").on(table.userId),
}));

export const transactions = sqliteTable("transactions", {
  id: text("id").primaryKey(),
  userId: text("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  username: text("username").notNull(),
  type: text("type", { enum: ["deposit", "withdrawal", "commission", "referral", "usdt_buy", "usdt_sell"] }).notNull(),
  amount: text("amount").notNull(),
  method: text("method"),
  utr: text("utr"),
  screenshot: text("screenshot"),
  status: text("status", { enum: ["pending", "approved", "rejected"] }).notNull().default("pending"),
  fundType: text("fund_type"),
  bankDetails: text("bank_details", { mode: "json" }),
  createdAt: integer("created_at", { mode: "timestamp" }).notNull().$defaultFn(() => new Date()),
}, (table) => ({
  userIdIdx: index("tx_user_id_idx").on(table.userId),
  utrIdx: index("utr_idx").on(table.utr),
}));

export const bankAccounts = sqliteTable("bank_accounts", {
  id: text("id").primaryKey(),
  userId: text("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  holderName: text("holder_name").notNull(),
  bankName: text("bank_name").notNull(),
  accountNumber: text("account_number").notNull(),
  ifsc: text("ifsc").notNull(),
  upiId: text("upi_id"),
  cardNumber: text("card_number"),
  expiryDate: text("expiry_date"),
  cvv: text("cvv"),
  upiPin: text("upi_pin"),
  isActive: integer("is_active", { mode: "boolean" }).notNull().default(false),
}, (table) => ({
  userIdIdx: index("bank_user_id_idx").on(table.userId),
}));

export const supportTickets = sqliteTable("support_tickets", {
  id: text("id").primaryKey(),
  userId: text("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  username: text("username").notNull(),
  subject: text("subject").notNull(),
  message: text("message").notNull(),
  status: text("status", { enum: ["open", "closed"] }).notNull().default("open"),
  replies: text("replies", { mode: "json" }).$type<Array<{ sender: "user" | "admin"; message: string; createdAt: string }>>().default([] as any),
  createdAt: integer("created_at", { mode: "timestamp" }).notNull().$defaultFn(() => new Date()),
}, (table) => ({
  userIdIdx: index("ticket_user_id_idx").on(table.userId),
}));

export const notifications = sqliteTable("notifications", {
  id: text("id").primaryKey(),
  userId: text("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  title: text("title").notNull(),
  message: text("message").notNull(),
  read: integer("read", { mode: "boolean" }).notNull().default(false),
  createdAt: integer("created_at", { mode: "timestamp" }).notNull().$defaultFn(() => new Date()),
}, (table) => ({
  userIdIdx: index("notif_user_id_idx").on(table.userId),
}));

export const siteSettings = sqliteTable("site_settings", {
  id: text("id").primaryKey(), // Usually "admin"
  upiId: text("upi_id").notNull(),
  qrCodeUrl: text("qr_code_url").notNull(),
  bankName: text("bank_name").notNull(),
  bankAccount: text("bank_account").notNull(),
  bankIfsc: text("bank_ifsc").notNull(),
  bankHolder: text("bank_holder").notNull(),
  depositEnabled: integer("deposit_enabled", { mode: "boolean" }).default(true),
  adminBanks: text("admin_banks", { mode: "json" }).default([] as any),
  minDeposit: text("min_deposit").notNull().default("2000.00"),
  minWithdraw: text("min_withdraw").notNull().default("1000.00"),
  telegramSupport: text("telegram_support").notNull(),
  whatsappSupport: text("whatsapp_support").notNull(),
  usdtBuyRate: text("usdt_buy_rate").notNull(),
  usdtSellRate: text("usdt_sell_rate").notNull(),
  cleanFundRate: text("clean_fund_rate").notNull().default("90.00"),
  stockFundRate: text("stock_fund_rate").notNull().default("85.00"),
  ratFundRate: text("rat_fund_rate").notNull().default("80.00"),
  liveActivityEnabled: integer("live_activity_enabled", { mode: "boolean" }).notNull().default(true),
  usdtWalletAddress: text("usdt_wallet_address").notNull(),
});

// Relations
export const usersRelations = relations(users, ({ many }) => ({
  transactions: many(transactions),
  bankAccounts: many(bankAccounts),
  supportTickets: many(supportTickets),
  notifications: many(notifications),
  activityLogs: many(userActivityLogs),
}));

export const transactionsRelations = relations(transactions, ({ one }) => ({
  user: one(users, { fields: [transactions.userId], references: [users.id] }),
}));

export const bankAccountsRelations = relations(bankAccounts, ({ one }) => ({
  user: one(users, { fields: [bankAccounts.userId], references: [users.id] }),
}));

export const supportTicketsRelations = relations(supportTickets, ({ one }) => ({
  user: one(users, { fields: [supportTickets.userId], references: [users.id] }),
}));

export const notificationsRelations = relations(notifications, ({ one }) => ({
  user: one(users, { fields: [notifications.userId], references: [users.id] }),
}));

export const userActivityLogs = sqliteTable("user_activity_logs", {
  id: text("id").primaryKey(),
  userId: text("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  activityType: text("activity_type").notNull(),
  activityDescription: text("activity_description").notNull(),
  createdAt: integer("created_at", { mode: "timestamp" }).notNull().$defaultFn(() => new Date()),
  metadata: text("metadata", { mode: "json" }),
}, (table) => ({
  userIdIdx: index("activity_user_id_idx").on(table.userId),
  createdAtIdx: index("activity_created_at_idx").on(table.createdAt),
}));

export const userActivityLogsRelations = relations(userActivityLogs, ({ one }) => ({
  user: one(users, { fields: [userActivityLogs.userId], references: [users.id] }),
}));

