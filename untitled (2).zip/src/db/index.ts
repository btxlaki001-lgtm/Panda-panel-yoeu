import { drizzle } from 'drizzle-orm/better-sqlite3';
import Database from 'better-sqlite3';
import * as schema from './schema.ts';
import fs from 'fs';
import { execSync } from 'child_process';

let sqlite: Database.Database;

function initDatabase() {
  sqlite = new Database('local.db');
  sqlite.pragma('journal_mode = WAL');
  sqlite.pragma('synchronous = NORMAL');
  sqlite.pragma('busy_timeout = 5000');
}

function healCorruptedDatabaseFile() {
  console.error("⚠️ [HEAL] Starting inline database repair...");
  try {
    if (sqlite) {
      try { sqlite.close(); } catch {}
    }
  } catch (err) {}
  
  const timestamp = Date.now();
  const backupPath = `local.db.corrupt_${timestamp}`;
  if (fs.existsSync('local.db')) {
    try { fs.renameSync('local.db', backupPath); } catch (err) {}
    console.log(`[HEAL] Moved corrupted database to: ${backupPath}`);
  }
  if (fs.existsSync('local.db-wal')) {
    try { fs.renameSync('local.db-wal', `${backupPath}-wal`); } catch (err) {}
  }
  if (fs.existsSync('local.db-shm')) {
    try { fs.renameSync('local.db-shm', `${backupPath}-shm`); } catch (err) {}
  }

  // Schema push and backup restore
  try {
    console.log("[HEAL] Re-creating database schema via drizzle-kit push...");
    execSync('npx drizzle-kit push', { stdio: 'inherit' });
    console.log("[HEAL] Restoring backup data...");
    execSync('node run_restore.js', { stdio: 'inherit' });
    console.log("✅ [HEAL] Repair and restoration complete!");
  } catch (healErr: any) {
    console.error("❌ [HEAL] Error during database repair:", healErr?.message || healErr);
  }
}

// First-time database initialization with safe automatic healing
try {
  initDatabase();
} catch (err: any) {
  const errMsg = (err?.message || "").toLowerCase();
  if (errMsg.includes("malformed") || errMsg.includes("corrupt") || errMsg.includes("disk image")) {
    console.log("⚠️ [INIT] SQLite database file is corrupt or malformed. Executing safe automatic self-healing repair...");
    healCorruptedDatabaseFile();
    initDatabase();
    console.log("✅ [INIT] Database successfully self-healed and re-initialized!");
  } else {
    console.error("❌ [INIT] Non-corruption error during database start:", err?.message);
    throw err;
  }
}

export const db = drizzle(sqlite, { schema });

// A robust function that automatically heals the database if corruption or malformation is detected at runtime
export function checkAndHealDatabase(err: any): boolean {
  const errMsg = (err?.message || "").toLowerCase();
  if (errMsg.includes("malformed") || errMsg.includes("corrupt") || errMsg.includes("disk image")) {
    healCorruptedDatabaseFile();
    try {
      initDatabase();
    } catch (e) {}
    return true;
  }
  return false;
}

// Perform instant database integrity health check on server startup
try {
  sqlite.prepare("SELECT 1").get();
} catch (err: any) {
  checkAndHealDatabase(err);
}
