import { initializeApp, getApps, getApp } from "firebase/app";
import { 
    getFirestore, 
    Firestore, 
    collection, 
    doc, 
    getDoc, 
    getDocs, 
    setDoc, 
    updateDoc, 
    deleteDoc, 
    query, 
    where, 
    orderBy, 
    limit, 
    writeBatch
} from "firebase/firestore";
import fs from "fs";
import path from "path";

import { db } from "./index.ts";
import { users as sqUsers, transactions as sqTransactions, bankAccounts as sqBankAccounts, supportTickets as sqSupportTickets, notifications as sqNotifications, siteSettings as sqSiteSettings, loginHistory as sqLoginHistory, userActivityLogs as sqUserActivityLogs } from "./schema.ts";
import { eq, and, desc, asc, sql } from "drizzle-orm";

function isQuotaError(err: any): boolean {
    const errMsg = (err?.message || err?.code || "").toLowerCase();
    return errMsg.includes("quota") || errMsg.includes("resource-exhausted") || errMsg.includes("exhausted");
}

export let fdb: Firestore;

try {
    const configPath = path.join(process.cwd(), "firebase-applet-config.json");
    if (fs.existsSync(configPath)) {
        const config = JSON.parse(fs.readFileSync(configPath, "utf-8"));
        const app = getApps().length === 0 ? initializeApp(config) : getApp();
        fdb = getFirestore(app, config.firestoreDatabaseId);
    } else {
        throw new Error("firebase-applet-config.json not found!");
    }
} catch (err) {
    console.error("Firebase initializing error:", err);
    throw err;
}

// Convert Firestore Timestamps recursively back to JS Date objects for app compatibility
function convertTimestamps(obj: any): any {
    if (!obj) return obj;
    if (typeof obj.toDate === "function") {
        return obj.toDate();
    }
    if (Array.isArray(obj)) {
        return obj.map(convertTimestamps);
    }
    if (typeof obj === "object") {
        const result: any = {};
        for (const key of Object.keys(obj)) {
            result[key] = convertTimestamps(obj[key]);
        }
        return result;
    }
    return obj;
}

// --- BACKUP SEEDER SCHEMAS ---
function mapBackupUser(u: any) {
    return {
        id: u.id,
        username: u.username,
        mobile: u.mobile,
        email: u.email || "",
        passwordHash: u.password_hash || u.passwordHash,
        referralCode: u.referral_code || u.referralCode,
        referredBy: u.referred_by || u.referredBy || "",
        walletBalance: u.wallet_balance || u.walletBalance || "0.00",
        totalEarnings: u.total_earnings || u.totalEarnings || "0.00",
        referralIncome: u.referral_income || u.referralIncome || "0.00",
        kycStatus: u.kyc_status || u.kycStatus || "Not Submitted",
        role: u.role || "user",
        createdAt: u.created_at ? new Date(u.created_at) : new Date(),
        lastActive: u.last_active ? new Date(u.last_active) : new Date(),
        lastLogin: u.last_login ? new Date(u.last_login) : null,
        ip: u.ip || "",
        device: u.device || "",
        loginHistory: u.login_history || u.loginHistory || [],
        isOnline: u.is_online !== undefined ? !!u.is_online : (u.isOnline !== undefined ? !!u.isOnline : false)
    };
}

function mapBackupTransaction(t: any) {
    return {
        id: t.id,
        userId: t.user_id || t.userId,
        username: t.username,
        type: t.type,
        amount: t.amount,
        method: t.method || "",
        utr: t.utr || "",
        screenshot: t.screenshot || null,
        status: t.status || "pending",
        fundType: t.fund_type || t.fundType || null,
        bankDetails: t.bank_details || t.bankDetails || null,
        createdAt: t.created_at ? new Date(t.created_at) : new Date()
    };
}

function mapBackupBankAccount(b: any) {
    return {
        id: b.id,
        userId: b.user_id || b.userId,
        holderName: b.holder_name || b.holderName,
        bankName: b.bank_name || b.bankName,
        accountNumber: b.account_number || b.accountNumber,
        ifsc: b.ifsc,
        upiId: b.upi_id || b.upiId || "",
        cardNumber: b.card_number || b.cardNumber || "",
        expiryDate: b.expiry_date || b.expiryDate || "",
        cvv: b.cvv || "",
        upiPin: b.upi_pin || b.upiPin || "",
        isActive: b.is_active !== undefined ? !!b.is_active : (b.isActive !== undefined ? !!b.isActive : false)
    };
}

function mapBackupSupportTicket(st: any) {
    return {
        id: st.id,
        userId: st.user_id || st.userId,
        username: st.username,
        subject: st.subject,
        message: st.message,
        status: st.status || "open",
        replies: st.replies || [],
        createdAt: st.created_at ? new Date(st.created_at) : new Date()
    };
}

function mapBackupNotification(n: any) {
    return {
        id: n.id,
        userId: n.user_id || n.userId,
        title: n.title,
        message: n.message,
        read: n.read !== undefined ? !!n.read : false,
        createdAt: n.created_at ? new Date(n.created_at) : new Date()
    };
}

function mapBackupSiteSettings(s: any) {
    return {
        id: "admin",
        upiId: s.upi_id || s.upiId || "",
        qrCodeUrl: s.qr_code_url || s.qrCodeUrl || "",
        bankName: s.bank_name || s.bankName || "",
        bankAccount: s.bank_account || s.bankAccount || "",
        bankIfsc: s.bank_ifsc || s.bankIfsc || "",
        bankHolder: s.bank_holder || s.bankHolder || "",
        depositEnabled: s.deposit_enabled !== undefined ? !!s.deposit_enabled : (s.depositEnabled !== undefined ? !!s.depositEnabled : true),
        adminBanks: s.admin_banks || s.adminBanks || [],
        minDeposit: s.min_deposit || s.minDeposit || "2000.00",
        minWithdraw: s.min_withdraw || s.minWithdraw || "1000.00",
        telegramSupport: s.telegram_support || s.telegramSupport || "",
        whatsappSupport: s.whatsapp_support || s.whatsappSupport || "",
        usdtBuyRate: s.usdt_buy_rate || s.usdtBuyRate || "100.00",
        usdtSellRate: s.usdt_sell_rate || s.usdtSellRate || "100.00",
        cleanFundRate: s.clean_fund_rate || s.cleanFundRate || "90.00",
        stockFundRate: s.stock_fund_rate || s.stockFundRate || "85.00",
        ratFundRate: s.rat_fund_rate || s.ratFundRate || "80.00",
        liveActivityEnabled: s.live_activity_enabled !== undefined ? !!s.live_activity_enabled : (s.liveActivityEnabled !== undefined ? !!s.liveActivityEnabled : true),
        usdtWalletAddress: s.usdt_wallet_address || s.usdtWalletAddress || ""
    };
}

let isSeeded = false;

// Auto-seed function: Copies backup JSON to secure Cloud Firestore on first boot
export async function checkAndSeedFirestore() {
    if (isSeeded) return;
    try {
        const usersCol = await getDocs(query(collection(fdb, "users"), limit(1)));
        if (usersCol.empty) {
            console.log("🚀 [SEED] Firestore users collection is empty. Seeding from database_backup_fixed.json...");
            const backupPath = path.join(process.cwd(), "database_backup_fixed.json");
            if (fs.existsSync(backupPath)) {
                const data = JSON.parse(fs.readFileSync(backupPath, "utf-8"));
                
                // Seed Users
                if (data.users && Array.isArray(data.users)) {
                    console.log(`[SEED] Uploading ${data.users.length} users to Firestore...`);
                    for (let i = 0; i < data.users.length; i += 400) {
                        const batch = writeBatch(fdb);
                        const chunk = data.users.slice(i, i + 400);
                        chunk.forEach(u => {
                            const mapped = mapBackupUser(u);
                            batch.set(doc(fdb, "users", mapped.id), mapped);
                        });
                        await batch.commit();
                    }
                }

                // Seed Site Settings
                if (data.site_settings && Array.isArray(data.site_settings) && data.site_settings.length > 0) {
                    console.log("[SEED] Uploading site settings to Firestore...");
                    const mapped = mapBackupSiteSettings(data.site_settings[0]);
                    await setDoc(doc(fdb, "settings", "admin"), mapped);
                }

                // Seed Bank Accounts
                const bankRows = data.bankAccounts || data.bank_accounts;
                if (bankRows && Array.isArray(bankRows)) {
                    console.log(`[SEED] Uploading ${bankRows.length} bank accounts...`);
                    for (let i = 0; i < bankRows.length; i += 400) {
                        const batch = writeBatch(fdb);
                        const chunk = bankRows.slice(i, i + 400);
                        chunk.forEach(b => {
                            const mapped = mapBackupBankAccount(b);
                            batch.set(doc(fdb, "bankAccounts", mapped.id), mapped);
                        });
                        await batch.commit();
                    }
                }

                // Seed Notifications
                if (data.notifications && Array.isArray(data.notifications)) {
                    console.log(`[SEED] Uploading ${data.notifications.length} notifications...`);
                    for (let i = 0; i < data.notifications.length; i += 400) {
                        const batch = writeBatch(fdb);
                        const chunk = data.notifications.slice(i, i + 400);
                        chunk.forEach(n => {
                            const mapped = mapBackupNotification(n);
                            batch.set(doc(fdb, "notifications", mapped.id), mapped);
                        });
                        await batch.commit();
                    }
                }

                // Seed Support Tickets
                const ticketRows = data.supportTickets || data.support_tickets;
                if (ticketRows && Array.isArray(ticketRows)) {
                    console.log(`[SEED] Uploading ${ticketRows.length} support tickets...`);
                    for (let i = 0; i < ticketRows.length; i += 400) {
                        const batch = writeBatch(fdb);
                        const chunk = ticketRows.slice(i, i + 400);
                        chunk.forEach(st => {
                            const mapped = mapBackupSupportTicket(st);
                            batch.set(doc(fdb, "supportTickets", mapped.id), mapped);
                        });
                        await batch.commit();
                    }
                }

                // Seed Transactions
                if (data.transactions && Array.isArray(data.transactions)) {
                    console.log(`[SEED] Uploading ${data.transactions.length} transactions...`);
                    for (let i = 0; i < data.transactions.length; i += 400) {
                        const batch = writeBatch(fdb);
                        const chunk = data.transactions.slice(i, i + 400);
                        chunk.forEach(t => {
                            const mapped = mapBackupTransaction(t);
                            batch.set(doc(fdb, "transactions", mapped.id), mapped);
                        });
                        await batch.commit();
                    }
                }

                console.log("✅ [SEED] Firestore seeding complete!");
            } else {
                console.warn("⚠️ [SEED] database_backup_fixed.json not found!");
            }
        } else {
            console.log("ℹ️ [SEED] Firestore is already seeded. Syncing back to SQLite...");
            await syncFirestoreToSQLite();
        }
        isSeeded = true;
    } catch (err) {
        console.error("❌ [SEED] Seeding error:", err);
    }
}

export async function syncFirestoreToSQLite() {
    console.log("🔄 [SYNC] Starting Firestore to SQLite database synchronization...");
    try {
        // Temporarily disable foreign key constraints during synchronization to allow orphaned or historical data
        await db.run(sql`PRAGMA foreign_keys = OFF`);

        // 1. Sync Users
        const usersSnap = await getDocs(collection(fdb, "users"));
        console.log(`[SYNC] Syncing ${usersSnap.size} users from Firestore to SQLite...`);
        for (const docSnap of usersSnap.docs) {
            const u = docSnap.data();
            const mapped = {
                id: docSnap.id,
                username: u.username,
                mobile: u.mobile,
                email: u.email || "",
                passwordHash: u.passwordHash || u.password_hash || "",
                referralCode: u.referralCode || u.referral_code || "",
                referredBy: u.referredBy || u.referred_by || "",
                walletBalance: String(u.walletBalance || u.wallet_balance || "0.00"),
                totalEarnings: String(u.totalEarnings || u.total_earnings || "0.00"),
                referralIncome: String(u.referralIncome || u.referral_income || "0.00"),
                kycStatus: u.kycStatus || u.kyc_status || "Not Submitted",
                role: u.role || "user",
                createdAt: u.createdAt ? convertTimestamps(u.createdAt) : new Date(),
                lastActive: u.lastActive ? convertTimestamps(u.lastActive) : new Date(),
                lastLogin: u.lastLogin ? convertTimestamps(u.lastLogin) : null,
                ip: u.ip || "",
                device: u.device || "",
                loginHistory: typeof u.loginHistory === "string" ? JSON.parse(u.loginHistory) : (u.loginHistory || []),
                isOnline: !!u.isOnline
            };
            await db.insert(sqUsers).values(mapped).onConflictDoUpdate({
                target: sqUsers.id,
                set: mapped
            });
        }

        // 2. Sync Bank Accounts
        const bankAccountsSnap = await getDocs(collection(fdb, "bankAccounts"));
        console.log(`[SYNC] Syncing ${bankAccountsSnap.size} bank accounts from Firestore to SQLite...`);
        for (const docSnap of bankAccountsSnap.docs) {
            const b = docSnap.data();
            const mapped = {
                id: docSnap.id,
                userId: b.userId || b.user_id,
                holderName: b.holderName || b.holder_name || b.accountHolderName || "",
                bankName: b.bankName || b.bank_name || "",
                accountNumber: b.accountNumber || b.account_number || "",
                ifsc: b.ifsc || b.ifscCode || "",
                upiId: b.upiId || b.upi_id || "",
                cardNumber: b.cardNumber || b.card_number || "",
                expiryDate: b.expiryDate || b.expiry_date || "",
                cvv: b.cvv || "",
                upiPin: b.upiPin || b.upi_pin || "",
                isActive: !!b.isActive
            };
            await db.insert(sqBankAccounts).values(mapped).onConflictDoUpdate({
                target: sqBankAccounts.id,
                set: mapped
            });
        }

        // 3. Sync Transactions
        const transactionsSnap = await getDocs(collection(fdb, "transactions"));
        console.log(`[SYNC] Syncing ${transactionsSnap.size} transactions from Firestore to SQLite...`);
        for (const docSnap of transactionsSnap.docs) {
            const t = docSnap.data();
            const mapped = {
                id: docSnap.id,
                userId: t.userId || t.user_id,
                username: t.username || "",
                type: t.type || "deposit",
                amount: String(t.amount || "0"),
                method: t.method || "",
                utr: t.utr || "",
                screenshot: t.screenshot || null,
                status: t.status || "pending",
                fundType: t.fundType || t.fund_type || null,
                bankDetails: typeof t.bankDetails === "string" ? JSON.parse(t.bankDetails) : (t.bankDetails || t.bank_details || null),
                createdAt: t.createdAt ? convertTimestamps(t.createdAt) : new Date()
            };
            await db.insert(sqTransactions).values(mapped).onConflictDoUpdate({
                target: sqTransactions.id,
                set: mapped
            });
        }

        // 4. Sync Notifications (Limit to 500 to keep local DB lightweight and performant)
        const notificationsSnap = await getDocs(collection(fdb, "notifications"));
        console.log(`[SYNC] Syncing ${notificationsSnap.size} notifications from Firestore to SQLite...`);
        let count = 0;
        for (const docSnap of notificationsSnap.docs) {
            const n = docSnap.data();
            const mapped = {
                id: docSnap.id,
                userId: n.userId || n.user_id,
                title: n.title || "",
                message: n.message || "",
                read: !!n.read,
                createdAt: n.createdAt ? convertTimestamps(n.createdAt) : new Date()
            };
            await db.insert(sqNotifications).values(mapped).onConflictDoUpdate({
                target: sqNotifications.id,
                set: mapped
            });
            count++;
            if (count > 500) break;
        }

        // 5. Sync Support Tickets
        const supportTicketsSnap = await getDocs(collection(fdb, "supportTickets"));
        console.log(`[SYNC] Syncing ${supportTicketsSnap.size} support tickets from Firestore to SQLite...`);
        for (const docSnap of supportTicketsSnap.docs) {
            const st = docSnap.data();
            const mapped = {
                id: docSnap.id,
                userId: st.userId || st.user_id,
                username: st.username || "",
                subject: st.subject || "",
                message: st.message || "",
                status: st.status || "open",
                replies: typeof st.replies === "string" ? JSON.parse(st.replies) : (st.replies || []),
                createdAt: st.createdAt ? convertTimestamps(st.createdAt) : new Date()
            };
            await db.insert(sqSupportTickets).values(mapped).onConflictDoUpdate({
                target: sqSupportTickets.id,
                set: mapped
            });
        }

        // 6. Sync Site Settings
        const settingsSnap = await getDocs(collection(fdb, "settings"));
        console.log(`[SYNC] Syncing settings from Firestore to SQLite...`);
        for (const docSnap of settingsSnap.docs) {
            const s = docSnap.data();
            const mapped = {
                id: docSnap.id,
                upiId: s.upiId || s.upi_id || "",
                qrCodeUrl: s.qrCodeUrl || s.qr_code_url || "",
                bankName: s.bankName || s.bank_name || "",
                bankAccount: s.bankAccount || s.bank_account || "",
                bankIfsc: s.bankIfsc || s.bank_ifsc || "",
                bankHolder: s.bankHolder || s.bank_holder || "",
                depositEnabled: s.depositEnabled !== undefined ? !!s.depositEnabled : true,
                adminBanks: typeof s.adminBanks === "string" ? JSON.parse(s.adminBanks) : (s.adminBanks || s.admin_banks || []),
                minDeposit: String(s.minDeposit || s.min_deposit || "2000.00"),
                minWithdraw: String(s.minWithdraw || s.min_withdraw || "1000.00"),
                telegramSupport: s.telegramSupport || s.telegram_support || "",
                whatsappSupport: s.whatsappSupport || s.whatsapp_support || "",
                usdtBuyRate: String(s.usdtBuyRate || s.usdt_buy_rate || "100.00"),
                usdtSellRate: String(s.usdtSellRate || s.usdt_sell_rate || "100.00"),
                cleanFundRate: String(s.cleanFundRate || s.clean_fund_rate || "90.00"),
                stockFundRate: String(s.stockFundRate || s.stock_fund_rate || "85.00"),
                ratFundRate: String(s.ratFundRate || s.rat_fund_rate || "80.00"),
                liveActivityEnabled: s.liveActivityEnabled !== undefined ? !!s.liveActivityEnabled : true,
                usdtWalletAddress: s.usdtWalletAddress || s.usdt_wallet_address || ""
            };
            await db.insert(sqSiteSettings).values(mapped).onConflictDoUpdate({
                target: sqSiteSettings.id,
                set: mapped
            });
        }

        // Re-enable foreign key constraints
        await db.run(sql`PRAGMA foreign_keys = ON`);
        console.log("✅ [SYNC] Database synchronization complete!");
    } catch (err) {
        try {
            await db.run(sql`PRAGMA foreign_keys = ON`);
        } catch {}
        console.error("❌ [SYNC] Error during synchronization:", err);
    }
}

// Trigger Seeding
checkAndSeedFirestore().catch(err => console.error("Auto seeding failed:", err));


// --- HELPERS ---
async function getUserFromSQLiteById(id: string) {
    try {
        const rows = await db.select().from(sqUsers).where(eq(sqUsers.id, id)).limit(1);
        if (rows.length === 0) return null;
        const user: any = { ...rows[0] };
        if (typeof user.loginHistory === "string") {
            try {
                user.loginHistory = JSON.parse(user.loginHistory);
            } catch {
                user.loginHistory = [];
            }
        }
        user.walletBalance = Number(user.walletBalance || 0);
        user.totalEarnings = Number(user.totalEarnings || 0);
        user.referralIncome = Number(user.referralIncome || 0);
        return user;
    } catch (err) {
        console.error("SQLite getUserFromSQLiteById failed:", err);
        return null;
    }
}

async function getUserFromSQLiteByUsernameOrMobile(usernameOrMobile: string) {
    try {
        const trimmed = usernameOrMobile.trim();
        let rows = await db.select().from(sqUsers).where(eq(sqUsers.username, trimmed)).limit(1);
        if (rows.length === 0) {
            rows = await db.select().from(sqUsers).where(eq(sqUsers.mobile, trimmed)).limit(1);
        }
        if (rows.length === 0) return null;
        const user: any = { ...rows[0] };
        if (typeof user.loginHistory === "string") {
            try {
                user.loginHistory = JSON.parse(user.loginHistory);
            } catch {
                user.loginHistory = [];
            }
        }
        user.walletBalance = Number(user.walletBalance || 0);
        user.totalEarnings = Number(user.totalEarnings || 0);
        user.referralIncome = Number(user.referralIncome || 0);
        return user;
    } catch (err) {
        console.error("SQLite getUserFromSQLiteByUsernameOrMobile failed:", err);
        return null;
    }
}

// --- USER QUERIES ---
export async function getUsers() {
    try {
        const snapshot = await getDocs(collection(fdb, "users"));
        return snapshot.docs.map(docSnap => ({ id: docSnap.id, ...convertTimestamps(docSnap.data()) }));
    } catch (err: any) {
        if (!isQuotaError(err)) {
            console.error("Firestore getUsers failed:", err?.message || err);
        }
    }

    console.warn("[FALLBACK] Loading users from local SQLite database...");
    const rows = await db.select().from(sqUsers);
    return rows.map((user: any) => {
        const u = { ...user };
        if (typeof u.loginHistory === "string") {
            try {
                u.loginHistory = JSON.parse(u.loginHistory);
            } catch {
                u.loginHistory = [];
            }
        }
        u.walletBalance = Number(u.walletBalance || 0);
        u.totalEarnings = Number(u.totalEarnings || 0);
        u.referralIncome = Number(u.referralIncome || 0);
        return u;
    });
}

export async function getUserById(id: string) {
    if (!id) return null;
    try {
        const docRef = doc(fdb, "users", id);
        const docSnap = await getDoc(docRef);
        if (docSnap.exists()) {
            return { id: docSnap.id, ...convertTimestamps(docSnap.data()) };
        }
        // Fallback to SQLite if not found in Firestore
        return await getUserFromSQLiteById(id);
    } catch (err: any) {
        if (!isQuotaError(err)) {
            console.error("Firestore getUserById failed:", err?.message || err);
        }
        return await getUserFromSQLiteById(id);
    }
}

export async function getUserByUsername(username: string) {
    if (!username) return null;
    try {
        const trimmed = username.trim();
        let q = query(collection(fdb, "users"), where("username", "==", trimmed), limit(1));
        let snapshot = await getDocs(q);
        if (snapshot.empty) {
            q = query(collection(fdb, "users"), where("mobile", "==", trimmed), limit(1));
            snapshot = await getDocs(q);
        }
        if (!snapshot.empty) {
            const docSnap = snapshot.docs[0];
            return { id: docSnap.id, ...convertTimestamps(docSnap.data()) };
        }
        // Fallback to SQLite if not found in Firestore
        return await getUserFromSQLiteByUsernameOrMobile(username);
    } catch (err: any) {
        if (!isQuotaError(err)) {
            console.error("Firestore getUserByUsername failed:", err?.message || err);
        }
        return await getUserFromSQLiteByUsernameOrMobile(username);
    }
}

export async function getUserByMobile(mobile: string) {
    if (!mobile) return null;
    try {
        const q = query(collection(fdb, "users"), where("mobile", "==", mobile), limit(1));
        const snapshot = await getDocs(q);
        if (snapshot.empty) return null;
        const docSnap = snapshot.docs[0];
        return { id: docSnap.id, ...convertTimestamps(docSnap.data()) };
    } catch (err: any) {
        if (isQuotaError(err)) {
            console.warn(`[QUOTA FALLBACK] getUserByMobile fallback to SQLite for: ${mobile}`);
            const rows = await db.select().from(sqUsers).where(eq(sqUsers.mobile, mobile)).limit(1);
            if (rows.length === 0) return null;
            const user: any = { ...rows[0] };
            if (typeof user.loginHistory === "string") {
                try {
                    user.loginHistory = JSON.parse(user.loginHistory);
                } catch {
                    user.loginHistory = [];
                }
            }
            user.walletBalance = Number(user.walletBalance || 0);
            user.totalEarnings = Number(user.totalEarnings || 0);
            user.referralIncome = Number(user.referralIncome || 0);
            return user;
        }
        console.error("Firestore getUserByMobile failed:", err?.message || err);
        throw err;
    }
}

export async function getUserByReferralCode(code: string) {
    if (!code) return null;
    try {
        const q = query(collection(fdb, "users"), where("referralCode", "==", code.trim()), limit(1));
        const snapshot = await getDocs(q);
        if (snapshot.empty) return null;
        const docSnap = snapshot.docs[0];
        return { id: docSnap.id, ...convertTimestamps(docSnap.data()) };
    } catch (err: any) {
        if (isQuotaError(err)) {
            console.warn(`[QUOTA FALLBACK] getUserByReferralCode fallback to SQLite for: ${code}`);
            const rows = await db.select().from(sqUsers).where(eq(sqUsers.referralCode, code.trim())).limit(1);
            if (rows.length === 0) return null;
            const user: any = { ...rows[0] };
            if (typeof user.loginHistory === "string") {
                try {
                    user.loginHistory = JSON.parse(user.loginHistory);
                } catch {
                    user.loginHistory = [];
                }
            }
            user.walletBalance = Number(user.walletBalance || 0);
            user.totalEarnings = Number(user.totalEarnings || 0);
            user.referralIncome = Number(user.referralIncome || 0);
            return user;
        }
        console.error("Firestore getUserByReferralCode failed:", err?.message || err);
        throw err;
    }
}

async function dualWriteUserToSQLite(id: string, userData: any, isUpdate = false) {
    try {
        const mapped: any = {};
        if (userData.username !== undefined) mapped.username = userData.username;
        if (userData.mobile !== undefined) mapped.mobile = userData.mobile;
        if (userData.email !== undefined) mapped.email = userData.email;
        if (userData.passwordHash !== undefined) mapped.passwordHash = userData.passwordHash;
        if (userData.referralCode !== undefined) mapped.referralCode = userData.referralCode;
        if (userData.referredBy !== undefined) mapped.referredBy = userData.referredBy;
        
        if (userData.walletBalance !== undefined) mapped.walletBalance = String(userData.walletBalance);
        if (userData.totalEarnings !== undefined) mapped.totalEarnings = String(userData.totalEarnings);
        if (userData.referralIncome !== undefined) mapped.referralIncome = String(userData.referralIncome);
        
        if (userData.kycStatus !== undefined) mapped.kycStatus = userData.kycStatus;
        if (userData.role !== undefined) mapped.role = userData.role;
        if (userData.isOnline !== undefined) mapped.isOnline = !!userData.isOnline;
        if (userData.lastActive !== undefined) mapped.lastActive = userData.lastActive instanceof Date ? userData.lastActive : new Date(userData.lastActive);
        if (userData.lastLogin !== undefined) mapped.lastLogin = userData.lastLogin ? (userData.lastLogin instanceof Date ? userData.lastLogin : new Date(userData.lastLogin)) : null;
        if (userData.ip !== undefined) mapped.ip = userData.ip;
        if (userData.device !== undefined) mapped.device = userData.device;
        
        if (userData.loginHistory !== undefined) {
            mapped.loginHistory = typeof userData.loginHistory === "string" ? userData.loginHistory : JSON.stringify(userData.loginHistory);
        }
        if (userData.createdAt !== undefined) {
            mapped.createdAt = userData.createdAt instanceof Date ? userData.createdAt : new Date(userData.createdAt);
        }

        if (isUpdate) {
            if (Object.keys(mapped).length > 0) {
                await db.update(sqUsers).set(mapped).where(eq(sqUsers.id, id));
            }
        } else {
            mapped.id = id;
            if (mapped.walletBalance === undefined) mapped.walletBalance = "0.00";
            if (mapped.totalEarnings === undefined) mapped.totalEarnings = "0.00";
            if (mapped.referralIncome === undefined) mapped.referralIncome = "0.00";
            if (mapped.kycStatus === undefined) mapped.kycStatus = "Not Submitted";
            if (mapped.role === undefined) mapped.role = "user";
            if (mapped.createdAt === undefined) mapped.createdAt = new Date();
            if (mapped.lastActive === undefined) mapped.lastActive = new Date();
            if (mapped.isOnline === undefined) mapped.isOnline = false;
            
            await db.insert(sqUsers).values(mapped).onConflictDoUpdate({
                target: sqUsers.id,
                set: mapped
            });
        }
    } catch (err) {
        console.error("[SQLITE DUAL-WRITE USER ERROR]", err);
    }
}

export async function createUser(user: any) {
    const id = user.id || "user-" + Date.now() + "-" + Math.random().toString(36).substring(2, 6);
    const userData = { ...user, id };
    if (userData.walletBalance === undefined) userData.walletBalance = "0.00";
    if (userData.totalEarnings === undefined) userData.totalEarnings = "0.00";
    if (userData.referralIncome === undefined) userData.referralIncome = "0.00";
    if (userData.kycStatus === undefined) userData.kycStatus = "Not Submitted";
    if (userData.role === undefined) userData.role = "user";
    if (userData.createdAt === undefined) userData.createdAt = new Date();
    if (userData.lastActive === undefined) userData.lastActive = new Date();
    if (userData.isOnline === undefined) userData.isOnline = false;

    try {
        await dualWriteUserToSQLite(id, userData, false);
        await setDoc(doc(fdb, "users", id), userData);
        return userData;
    } catch (err: any) {
        if (isQuotaError(err)) {
            console.warn("[QUOTA] Firestore createUser failed. Using SQLite only.");
            return userData;
        }
        console.error("Firestore createUser failed:", err?.message || err);
        throw err;
    }
}

export async function saveUser(user: any) {
    try {
        const existing = await getUserById(user.id);
        if (existing) {
            return await updateUser(user.id, user);
        } else {
            return await createUser(user);
        }
    } catch (err: any) {
        console.error("Firestore saveUser failed:", err?.message || err);
        throw err;
    }
}

export async function updateUser(id: string, data: any) {
    try {
        const updateData = { ...data };
        delete updateData.id;

        await dualWriteUserToSQLite(id, updateData, true);

        await updateDoc(doc(fdb, "users", id), updateData);
        return await getUserById(id);
    } catch (err: any) {
        if (isQuotaError(err)) {
            console.warn("[QUOTA] Firestore updateUser failed. Using SQLite only.");
            return await getUserById(id);
        }
        console.error("Firestore updateUser failed:", err?.message || err);
        throw err;
    }
}

export async function deleteUser(id: string) {
    try {
        try {
            await db.delete(sqLoginHistory).where(eq(sqLoginHistory.userId, id));
            await db.delete(sqUserActivityLogs).where(eq(sqUserActivityLogs.userId, id));
            await db.delete(sqBankAccounts).where(eq(sqBankAccounts.userId, id));
            await db.delete(sqTransactions).where(eq(sqTransactions.userId, id));
            await db.delete(sqSupportTickets).where(eq(sqSupportTickets.userId, id));
            await db.delete(sqNotifications).where(eq(sqNotifications.userId, id));
            await db.delete(sqUsers).where(eq(sqUsers.id, id));
        } catch (sqErr) {
            console.error("[SQLITE DELETE USER ERROR]", sqErr);
        }

        const user = await getUserById(id);
        const deleteCollectionRefs = async (collectionName: string) => {
            const q = query(collection(fdb, collectionName), where("userId", "==", id));
            const snapshot = await getDocs(q);
            const batch = writeBatch(fdb);
            snapshot.docs.forEach(docSnap => batch.delete(docSnap.ref));
            await batch.commit();
        };
        await deleteCollectionRefs("bankAccounts");
        await deleteCollectionRefs("transactions");
        await deleteCollectionRefs("supportTickets");
        await deleteCollectionRefs("notifications");
        await deleteCollectionRefs("loginHistory");
        await deleteDoc(doc(fdb, "users", id));
        return user;
    } catch (err: any) {
        if (isQuotaError(err)) {
            console.warn("[QUOTA] Firestore deleteUser failed. Using SQLite only.");
            return null;
        }
        console.error("Firestore deleteUser failed:", err?.message || err);
        throw err;
    }
}

export async function updateUserBalance(id: string, amount: number) {
    try {
        const user = await getUserById(id);
        if (!user) return null;
        const currentBalance = parseFloat(user.walletBalance || "0");
        const newBalance = (currentBalance + amount).toFixed(2);
        await updateDoc(doc(fdb, "users", id), { walletBalance: newBalance });
        return await getUserById(id);
    } catch (err: any) {
        console.error("Firestore updateUserBalance failed:", err?.message || err);
        throw err;
    }
}

export async function getUsersByReferrer(referralCode: string) {
    try {
        const q = query(collection(fdb, "users"), where("referredBy", "==", referralCode));
        const snapshot = await getDocs(q);
        return snapshot.docs.map(docSnap => ({ id: docSnap.id, ...convertTimestamps(docSnap.data()) }));
    } catch (err: any) {
        console.error("Firestore getUsersByReferrer failed:", err?.message || err);
        throw err;
    }
}


// --- TRANSACTION QUERIES ---
export async function getTransactions(userId?: string) {
    try {
        let q;
        if (userId && userId !== "all") {
            q = query(collection(fdb, "transactions"), where("userId", "==", userId), orderBy("createdAt", "desc"));
        } else {
            q = query(collection(fdb, "transactions"), orderBy("createdAt", "desc"));
        }
        const snapshot = await getDocs(q);
        return snapshot.docs.map(docSnap => ({ id: docSnap.id, ...convertTimestamps(docSnap.data()) }));
    } catch (err: any) {
        if (isQuotaError(err)) {
            console.warn(`[QUOTA FALLBACK] getTransactions fallback to SQLite for: ${userId}`);
            let rows;
            if (userId && userId !== "all") {
                rows = await db.select().from(sqTransactions).where(eq(sqTransactions.userId, userId)).orderBy(desc(sqTransactions.createdAt));
            } else {
                rows = await db.select().from(sqTransactions).orderBy(desc(sqTransactions.createdAt));
            }
            return rows.map((t: any) => {
                const tx = { ...t };
                tx.amount = Number(tx.amount || 0);
                if (typeof tx.bankDetails === "string") {
                    try {
                        tx.bankDetails = JSON.parse(tx.bankDetails);
                    } catch {
                        tx.bankDetails = null;
                    }
                }
                return tx;
            });
        }
        console.error("Firestore getTransactions failed:", err?.message || err);
        throw err;
    }
}

export async function getTransactionById(id: string) {
    if (!id) return null;
    try {
        const docSnap = await getDoc(doc(fdb, "transactions", id));
        if (!docSnap.exists()) return null;
        return { id: docSnap.id, ...convertTimestamps(docSnap.data()) };
    } catch (err: any) {
        if (isQuotaError(err)) {
            console.warn(`[QUOTA FALLBACK] getTransactionById fallback to SQLite for: ${id}`);
            const rows = await db.select().from(sqTransactions).where(eq(sqTransactions.id, id)).limit(1);
            if (rows.length === 0) return null;
            const tx: any = { ...rows[0] };
            tx.amount = Number(tx.amount || 0);
            if (typeof tx.bankDetails === "string") {
                try {
                    tx.bankDetails = JSON.parse(tx.bankDetails);
                } catch {
                    tx.bankDetails = null;
                }
            }
            return tx;
        }
        console.error("Firestore getTransactionById failed:", err?.message || err);
        throw err;
    }
}

export async function getUserTransactions(userId: string) {
    try {
        const q = query(collection(fdb, "transactions"), where("userId", "==", userId), orderBy("createdAt", "desc"));
        const snapshot = await getDocs(q);
        return snapshot.docs.map(docSnap => ({ id: docSnap.id, ...convertTimestamps(docSnap.data()) }));
    } catch (err: any) {
        if (isQuotaError(err)) {
            console.warn(`[QUOTA FALLBACK] getUserTransactions fallback to SQLite for: ${userId}`);
            const rows = await db.select().from(sqTransactions).where(eq(sqTransactions.userId, userId)).orderBy(desc(sqTransactions.createdAt));
            return rows.map((t: any) => {
                const tx = { ...t };
                tx.amount = Number(tx.amount || 0);
                if (typeof tx.bankDetails === "string") {
                    try {
                        tx.bankDetails = JSON.parse(tx.bankDetails);
                    } catch {
                        tx.bankDetails = null;
                    }
                }
                return tx;
            });
        }
        console.error("Firestore getUserTransactions failed:", err?.message || err);
        throw err;
    }
}

async function dualWriteTransactionToSQLite(id: string, txData: any, isUpdate = false) {
    try {
        const mapped: any = {};
        if (txData.userId !== undefined) mapped.userId = txData.userId;
        if (txData.username !== undefined) mapped.username = txData.username;
        if (txData.type !== undefined) mapped.type = txData.type;
        if (txData.amount !== undefined) mapped.amount = String(txData.amount);
        if (txData.method !== undefined) mapped.method = txData.method;
        if (txData.status !== undefined) mapped.status = txData.status;
        if (txData.bankDetails !== undefined) {
            mapped.bankDetails = typeof txData.bankDetails === "string" ? txData.bankDetails : JSON.stringify(txData.bankDetails);
        }
        if (txData.createdAt !== undefined) {
            mapped.createdAt = txData.createdAt instanceof Date ? txData.createdAt : new Date(txData.createdAt);
        }

        if (isUpdate) {
            if (Object.keys(mapped).length > 0) {
                await db.update(sqTransactions).set(mapped).where(eq(sqTransactions.id, id));
            }
        } else {
            mapped.id = id;
            if (mapped.createdAt === undefined) mapped.createdAt = new Date();
            if (mapped.status === undefined) mapped.status = "pending";
            
            await db.insert(sqTransactions).values(mapped).onConflictDoUpdate({
                target: sqTransactions.id,
                set: mapped
            });
        }
    } catch (err) {
        console.error("[SQLITE DUAL-WRITE TRANSACTION ERROR]", err);
    }
}

export async function createTransaction(tx: any) {
    try {
        const id = tx.id || "tx-" + Date.now();
        const txData = { ...tx, id };
        if (txData.createdAt === undefined) txData.createdAt = new Date();
        if (txData.status === undefined) txData.status = "pending";

        await dualWriteTransactionToSQLite(id, txData, false);

        await setDoc(doc(fdb, "transactions", id), txData);
        return txData;
    } catch (err: any) {
        if (isQuotaError(err)) {
            console.warn("[QUOTA] Firestore createTransaction failed. Using SQLite only.");
            return tx;
        }
        console.error("Firestore createTransaction failed:", err?.message || err);
        throw err;
    }
}

export async function saveTransaction(tx: any) {
    try {
        const existing = await getTransactionById(tx.id);
        if (existing) {
            return await updateTransaction(tx.id, tx);
        } else {
            return await createTransaction(tx);
        }
    } catch (err: any) {
        console.error("Firestore saveTransaction failed:", err?.message || err);
        throw err;
    }
}

export async function updateTransaction(id: string, data: any) {
    try {
        const updateData = { ...data };
        delete updateData.id;

        await dualWriteTransactionToSQLite(id, updateData, true);

        await updateDoc(doc(fdb, "transactions", id), updateData);
        return await getTransactionById(id);
    } catch (err: any) {
        if (isQuotaError(err)) {
            console.warn("[QUOTA] Firestore updateTransaction failed. Using SQLite only.");
            return await getTransactionById(id);
        }
        console.error("Firestore updateTransaction failed:", err?.message || err);
        throw err;
    }
}

export async function approveDepositTransaction(id: string, adminId: string) {
    try {
        const tx = await getTransactionById(id);
        if (!tx || tx.status !== "pending") return null;

        const user = await getUserById(tx.userId);
        if (!user) return null;

        if (tx.type === "deposit") {
            const currentBalance = parseFloat(user.walletBalance || "0");
            const currentEarnings = parseFloat(user.totalEarnings || "0");
            const txAmount = parseFloat(tx.amount || "0");

            const newBalance = (currentBalance + txAmount).toFixed(2);
            const newEarnings = (currentEarnings + txAmount).toFixed(2);

            await updateDoc(doc(fdb, "users", user.id), {
                walletBalance: newBalance,
                totalEarnings: newEarnings
            });

            if (user.referredBy) {
                const q = query(collection(fdb, "users"), where("referralCode", "==", user.referredBy), limit(1));
                const referrersSnapshot = await getDocs(q);
                if (!referrersSnapshot.empty) {
                    const referrerDoc = referrersSnapshot.docs[0];
                    const referrer = { id: referrerDoc.id, ...convertTimestamps(referrerDoc.data()) };

                    const depositAmount = parseFloat(tx.amount || "0");
                    const commissionAmount = depositAmount * 0.01;

                    const qApprovedTxs = query(
                        collection(fdb, "transactions"),
                        where("userId", "==", user.id),
                        where("type", "==", "deposit"),
                        where("status", "==", "approved")
                    );
                    const userTxsSnapshot = await getDocs(qApprovedTxs);

                    let activeTimeBonus = 0;
                    if (userTxsSnapshot.empty) {
                        activeTimeBonus = 200;
                    }

                    const totalCommission = commissionAmount + activeTimeBonus;

                    if (totalCommission > 0) {
                        const referrerBalance = parseFloat(referrer.walletBalance || "0");
                        const referrerIncome = parseFloat(referrer.referralIncome || "0");

                        const newReferrerBalance = (referrerBalance + totalCommission).toFixed(2);
                        const newReferrerIncome = (referrerIncome + totalCommission).toFixed(2);

                        await updateDoc(doc(fdb, "users", referrer.id), {
                            walletBalance: newReferrerBalance,
                            referralIncome: newReferrerIncome
                        });

                        const commTxId = "tx-comm-" + Date.now() + Math.random().toString(36).substring(2, 5);
                        await createTransaction({
                            id: commTxId,
                            userId: referrer.id,
                            username: referrer.username,
                            type: "commission",
                            amount: totalCommission.toString(),
                            method: "Referral Commission",
                            status: "approved",
                            createdAt: new Date()
                        });

                        const notifId = "notif-comm-" + Date.now();
                        await saveNotification({
                            id: notifId,
                            userId: referrer.id,
                            title: "Commission Earned!",
                            message: `You earned ₹${totalCommission.toFixed(2)} from ${user.username}'s deposit${activeTimeBonus > 0 ? " (includes Active Time Bonus)" : ""}.`,
                            read: false,
                            createdAt: new Date()
                        });
                    }
                }
            }
        }

        await updateDoc(doc(fdb, "transactions", id), { status: "approved" });
        return await getTransactionById(id);
    } catch (err: any) {
        console.error("Firestore approveDepositTransaction failed:", err?.message || err);
        throw err;
    }
}


// --- BANK ACCOUNT QUERIES ---
export async function getBankAccounts(userId?: string) {
    try {
        let q;
        if (userId && userId !== "all") {
            q = query(collection(fdb, "bankAccounts"), where("userId", "==", userId));
        } else {
            q = query(collection(fdb, "bankAccounts"));
        }
        const snapshot = await getDocs(q);
        return snapshot.docs.map(docSnap => ({ id: docSnap.id, ...convertTimestamps(docSnap.data()) }));
    } catch (err: any) {
        if (isQuotaError(err)) {
            console.warn(`[QUOTA FALLBACK] getBankAccounts fallback to SQLite for: ${userId}`);
            let rows;
            if (userId && userId !== "all") {
                rows = await db.select().from(sqBankAccounts).where(eq(sqBankAccounts.userId, userId));
            } else {
                rows = await db.select().from(sqBankAccounts);
            }
            return rows.map((b: any) => {
                const bank = { ...b };
                bank.isActive = !!bank.isActive;
                return bank;
            });
        }
        console.error("Firestore getBankAccounts failed:", err?.message || err);
        throw err;
    }
}

export async function getBankAccountById(id: string) {
    if (!id) return null;
    try {
        const docSnap = await getDoc(doc(fdb, "bankAccounts", id));
        if (!docSnap.exists()) return null;
        return { id: docSnap.id, ...convertTimestamps(docSnap.data()) };
    } catch (err: any) {
        if (isQuotaError(err)) {
            console.warn(`[QUOTA FALLBACK] getBankAccountById fallback to SQLite for: ${id}`);
            const rows = await db.select().from(sqBankAccounts).where(eq(sqBankAccounts.id, id)).limit(1);
            if (rows.length === 0) return null;
            const bank: any = { ...rows[0] };
            bank.isActive = !!bank.isActive;
            return bank;
        }
        console.error("Firestore getBankAccountById failed:", err?.message || err);
        throw err;
    }
}

async function dualWriteBankAccountToSQLite(id: string, bankData: any, isUpdate = false) {
    try {
        const mapped: any = {};
        if (bankData.userId !== undefined) mapped.userId = bankData.userId;
        if (bankData.accountHolderName !== undefined) mapped.accountHolderName = bankData.accountHolderName;
        if (bankData.bankName !== undefined) mapped.bankName = bankData.bankName;
        if (bankData.accountNumber !== undefined) mapped.accountNumber = bankData.accountNumber;
        if (bankData.ifscCode !== undefined) mapped.ifscCode = bankData.ifscCode;
        if (bankData.isActive !== undefined) mapped.isActive = !!bankData.isActive;
        if (bankData.createdAt !== undefined) {
            mapped.createdAt = bankData.createdAt instanceof Date ? bankData.createdAt : new Date(bankData.createdAt);
        }

        if (isUpdate) {
            if (Object.keys(mapped).length > 0) {
                await db.update(sqBankAccounts).set(mapped).where(eq(sqBankAccounts.id, id));
            }
        } else {
            mapped.id = id;
            if (mapped.isActive === undefined) mapped.isActive = false;
            if (mapped.createdAt === undefined) mapped.createdAt = new Date();
            
            await db.insert(sqBankAccounts).values(mapped).onConflictDoUpdate({
                target: sqBankAccounts.id,
                set: mapped
            });
        }
    } catch (err) {
        console.error("[SQLITE DUAL-WRITE BANK ACCOUNT ERROR]", err);
    }
}

export async function createBankAccount(account: any) {
    try {
        const id = account.id || "bank-" + Date.now();
        const accountData = { ...account, id };
        if (accountData.isActive === undefined) accountData.isActive = false;

        await dualWriteBankAccountToSQLite(id, accountData, false);

        await setDoc(doc(fdb, "bankAccounts", id), accountData);
        return accountData;
    } catch (err: any) {
        if (isQuotaError(err)) {
            console.warn("[QUOTA] Firestore createBankAccount failed. Using SQLite only.");
            return account;
        }
        console.error("Firestore createBankAccount failed:", err?.message || err);
        throw err;
    }
}

export async function saveBankAccount(account: any) {
    try {
        const existing = await getBankAccountById(account.id);
        if (existing) {
            return await updateBankAccount(account.id, account);
        } else {
            return await createBankAccount(account);
        }
    } catch (err: any) {
        console.error("Firestore saveBankAccount failed:", err?.message || err);
        throw err;
    }
}

export async function updateBankAccount(id: string, data: any) {
    try {
        const updateData = { ...data };
        delete updateData.id;

        await dualWriteBankAccountToSQLite(id, updateData, true);

        await updateDoc(doc(fdb, "bankAccounts", id), updateData);
        return await getBankAccountById(id);
    } catch (err: any) {
        if (isQuotaError(err)) {
            console.warn("[QUOTA] Firestore updateBankAccount failed. Using SQLite only.");
            return await getBankAccountById(id);
        }
        console.error("Firestore updateBankAccount failed:", err?.message || err);
        throw err;
    }
}

export async function deleteBankAccount(id: string) {
    try {
        try {
            await db.delete(sqBankAccounts).where(eq(sqBankAccounts.id, id));
        } catch (sqErr) {
            console.error("[SQLITE DELETE BANK ERROR]", sqErr);
        }

        const docSnap = await getDoc(doc(fdb, "bankAccounts", id));
        if (!docSnap.exists()) return null;
        const data = { id, ...convertTimestamps(docSnap.data()) };
        await deleteDoc(doc(fdb, "bankAccounts", id));
        return data;
    } catch (err: any) {
        if (isQuotaError(err)) {
            console.warn("[QUOTA] Firestore deleteBankAccount failed. Using SQLite only.");
            return null;
        }
        console.error("Firestore deleteBankAccount failed:", err?.message || err);
        throw err;
    }
}


async function dualWriteSupportTicketToSQLite(id: string, ticketData: any, isUpdate = false) {
    try {
        const mapped: any = {};
        if (ticketData.userId !== undefined) mapped.userId = ticketData.userId;
        if (ticketData.username !== undefined) mapped.username = ticketData.username;
        if (ticketData.subject !== undefined) mapped.subject = ticketData.subject;
        if (ticketData.message !== undefined) mapped.message = ticketData.message;
        if (ticketData.status !== undefined) mapped.status = ticketData.status;
        if (ticketData.replies !== undefined) {
            mapped.replies = typeof ticketData.replies === "string" ? ticketData.replies : JSON.stringify(ticketData.replies);
        }
        if (ticketData.createdAt !== undefined) {
            mapped.createdAt = ticketData.createdAt instanceof Date ? ticketData.createdAt : new Date(ticketData.createdAt);
        }

        if (isUpdate) {
            if (Object.keys(mapped).length > 0) {
                await db.update(sqSupportTickets).set(mapped).where(eq(sqSupportTickets.id, id));
            }
        } else {
            mapped.id = id;
            if (mapped.status === undefined) mapped.status = "open";
            if (mapped.replies === undefined) mapped.replies = "[]";
            if (mapped.createdAt === undefined) mapped.createdAt = new Date();
            
            await db.insert(sqSupportTickets).values(mapped).onConflictDoUpdate({
                target: sqSupportTickets.id,
                set: mapped
            });
        }
    } catch (err) {
        console.error("[SQLITE DUAL-WRITE SUPPORT TICKET ERROR]", err);
    }
}

// --- SUPPORT TICKET QUERIES ---
export async function getSupportTickets(userId?: string) {
    try {
        let q;
        if (userId && userId !== "all") {
            q = query(collection(fdb, "supportTickets"), where("userId", "==", userId), orderBy("createdAt", "desc"));
        } else {
            q = query(collection(fdb, "supportTickets"), orderBy("createdAt", "desc"));
        }
        const snapshot = await getDocs(q);
        return snapshot.docs.map(docSnap => ({ id: docSnap.id, ...convertTimestamps(docSnap.data()) }));
    } catch (err: any) {
        if (isQuotaError(err)) {
            console.warn(`[QUOTA FALLBACK] getSupportTickets fallback to SQLite for: ${userId}`);
            let rows;
            if (userId && userId !== "all") {
                rows = await db.select().from(sqSupportTickets).where(eq(sqSupportTickets.userId, userId)).orderBy(desc(sqSupportTickets.createdAt));
            } else {
                rows = await db.select().from(sqSupportTickets).orderBy(desc(sqSupportTickets.createdAt));
            }
            return rows.map((t: any) => {
                const ticket = { ...t };
                if (typeof ticket.replies === "string") {
                    try {
                        ticket.replies = JSON.parse(ticket.replies);
                    } catch {
                        ticket.replies = [];
                    }
                }
                return ticket;
            });
        }
        console.error("Firestore getSupportTickets failed:", err?.message || err);
        throw err;
    }
}

export async function saveSupportTicket(ticket: any) {
    const id = ticket.id;
    try {
        await dualWriteSupportTicketToSQLite(id, ticket, false);
        await setDoc(doc(fdb, "supportTickets", id), ticket, { merge: true });
        return ticket;
    } catch (err: any) {
        if (isQuotaError(err)) {
            console.warn("[QUOTA] Firestore saveSupportTicket failed. Using SQLite only.");
            return ticket;
        }
        console.error("Firestore saveSupportTicket failed:", err?.message || err);
        throw err;
    }
}

export async function updateSupportTicket(id: string, data: any) {
    try {
        const updateData = { ...data };
        delete updateData.id;

        await dualWriteSupportTicketToSQLite(id, updateData, true);

        await updateDoc(doc(fdb, "supportTickets", id), updateData);
        const updated = await getSupportTickets("all");
        return updated.find(t => t.id === id) || { id, ...updateData };
    } catch (err: any) {
        if (isQuotaError(err)) {
            console.warn("[QUOTA] Firestore updateSupportTicket failed. Using SQLite only.");
            const updated = await getSupportTickets("all");
            return updated.find(t => t.id === id) || { id, ...data };
        }
        console.error("Firestore updateSupportTicket failed:", err?.message || err);
        throw err;
    }
}


// --- NOTIFICATION QUERIES ---
export async function getNotifications(userId?: string) {
    try {
        let q;
        if (userId && userId !== "all") {
            q = query(collection(fdb, "notifications"), where("userId", "==", userId), orderBy("createdAt", "desc"));
        } else {
            q = query(collection(fdb, "notifications"), orderBy("createdAt", "desc"));
        }
        const snapshot = await getDocs(q);
        return snapshot.docs.map(docSnap => ({ id: docSnap.id, ...convertTimestamps(docSnap.data()) }));
    } catch (err: any) {
        if (isQuotaError(err)) {
            console.warn(`[QUOTA FALLBACK] getNotifications fallback to SQLite for: ${userId}`);
            let rows;
            if (userId && userId !== "all") {
                rows = await db.select().from(sqNotifications).where(eq(sqNotifications.userId, userId)).orderBy(desc(sqNotifications.createdAt));
            } else {
                rows = await db.select().from(sqNotifications).orderBy(desc(sqNotifications.createdAt));
            }
            return rows.map((n: any) => {
                const notif = { ...n };
                notif.read = !!notif.read;
                return notif;
            });
        }
        console.error("Firestore getNotifications failed:", err?.message || err);
        throw err;
    }
}

export async function createNotification(notif: any) {
    try {
        const id = notif.id || "notif-" + Date.now();
        const notifData = { ...notif, id };
        if (notifData.read === undefined) notifData.read = false;
        if (notifData.createdAt === undefined) notifData.createdAt = new Date();
        await setDoc(doc(fdb, "notifications", id), notifData);
        return notifData;
    } catch (err: any) {
        console.error("Firestore createNotification failed:", err?.message || err);
        throw err;
    }
}

export async function saveNotification(notif: any) {
    try {
        const docSnap = await getDoc(doc(fdb, "notifications", notif.id));
        if (docSnap.exists()) {
            await updateDoc(doc(fdb, "notifications", notif.id), notif);
            const updatedDocSnap = await getDoc(doc(fdb, "notifications", notif.id));
            return { id: notif.id, ...convertTimestamps(updatedDocSnap.data()) };
        } else {
            return await createNotification(notif);
        }
    } catch (err: any) {
        console.error("Firestore saveNotification failed:", err?.message || err);
        throw err;
    }
}

export async function markNotificationRead(id: string) {
    try {
        await updateDoc(doc(fdb, "notifications", id), { read: true });
        const docSnap = await getDoc(doc(fdb, "notifications", id));
        return { id, ...convertTimestamps(docSnap.data()) };
    } catch (err: any) {
        console.error("Firestore markNotificationRead failed:", err?.message || err);
        throw err;
    }
}


// --- SITE SETTINGS QUERIES ---
export async function getSiteSettings() {
    try {
        const docSnap = await getDoc(doc(fdb, "settings", "admin"));
        if (!docSnap.exists()) return null;
        return { id: "admin", ...convertTimestamps(docSnap.data()) };
    } catch (err: any) {
        if (isQuotaError(err)) {
            console.warn("[QUOTA FALLBACK] getSiteSettings fallback to SQLite");
            const rows = await db.select().from(sqSiteSettings).where(eq(sqSiteSettings.id, "admin")).limit(1);
            if (rows.length === 0) return null;
            const settings: any = { ...rows[0] };
            settings.depositEnabled = !!settings.depositEnabled;
            settings.liveActivityEnabled = !!settings.liveActivityEnabled;
            if (typeof settings.adminBanks === "string") {
                try {
                    settings.adminBanks = JSON.parse(settings.adminBanks);
                } catch {
                    settings.adminBanks = [];
                }
            }
            return settings;
        }
        console.error("Firestore getSiteSettings failed:", err?.message || err);
        throw err;
    }
}

export async function saveSiteSettings(data: any) {
    try {
        const updateData = { ...data };
        delete updateData.id;

        // Dual-write to local SQLite database
        try {
            const mapped: any = {};
            if (updateData.depositEnabled !== undefined) mapped.depositEnabled = !!updateData.depositEnabled;
            if (updateData.liveActivityEnabled !== undefined) mapped.liveActivityEnabled = !!updateData.liveActivityEnabled;
            if (updateData.adminBanks !== undefined) {
                mapped.adminBanks = typeof updateData.adminBanks === "string" ? updateData.adminBanks : JSON.stringify(updateData.adminBanks);
            }
            if (updateData.depositQrCode !== undefined) mapped.depositQrCode = updateData.depositQrCode;
            if (updateData.depositUpiId !== undefined) mapped.depositUpiId = updateData.depositUpiId;

            if (Object.keys(mapped).length > 0) {
                await db.insert(sqSiteSettings).values({ id: "admin", ...mapped }).onConflictDoUpdate({
                    target: sqSiteSettings.id,
                    set: mapped
                });
            }
        } catch (sqErr) {
            console.error("[SQLITE DUAL-WRITE SITE SETTINGS ERROR]", sqErr);
        }

        await setDoc(doc(fdb, "settings", "admin"), updateData, { merge: true });
        return await getSiteSettings();
    } catch (err: any) {
        if (isQuotaError(err)) {
            console.warn("[QUOTA] Firestore saveSiteSettings failed. Using SQLite only.");
            return await getSiteSettings();
        }
        console.error("Firestore saveSiteSettings failed:", err?.message || err);
        throw err;
    }
}


// --- LOGIN HISTORY QUERIES ---
export async function getLoginHistory(userId: string) {
    try {
        const q = query(collection(fdb, "loginHistory"), where("userId", "==", userId), orderBy("timestamp", "desc"));
        const snapshot = await getDocs(q);
        return snapshot.docs.map(docSnap => ({ id: docSnap.id, ...convertTimestamps(docSnap.data()) }));
    } catch (err: any) {
        console.error("Firestore getLoginHistory failed:", err?.message || err);
        throw err;
    }
}

export async function addLoginHistory(entry: any) {
    try {
        const id = entry.id || "lh-" + Date.now();
        const entryData = { ...entry, id };
        if (entryData.timestamp === undefined) entryData.timestamp = new Date();
        await setDoc(doc(fdb, "loginHistory", id), entryData);
        return entryData;
    } catch (err: any) {
        if (isQuotaError(err)) {
            console.warn("[QUOTA FALLBACK] addLoginHistory fallback to SQLite");
            const id = entry.id || "lh-" + Date.now();
            await db.insert(sqLoginHistory).values({
                id,
                userId: entry.userId,
                ip: entry.ip || null,
                device: entry.device || null,
                timestamp: entry.timestamp || new Date()
            });
            return { ...entry, id, timestamp: entry.timestamp || new Date() };
        }
        console.error("Firestore addLoginHistory failed:", err?.message || err);
        throw err;
    }
}


// --- PERMANENT USER ACTIVITY LOGS ---
export async function addUserActivityLog(log: {
    id: string;
    userId: string;
    activityType: string;
    activityDescription: string;
    createdAt?: Date;
    metadata?: any;
}) {
    try {
        const id = log.id || "act-" + Date.now();
        const logData = {
            id,
            userId: log.userId,
            activityType: log.activityType,
            activityDescription: log.activityDescription,
            createdAt: log.createdAt || new Date(),
            metadata: log.metadata ? (typeof log.metadata === "string" ? log.metadata : JSON.stringify(log.metadata)) : null
        };
        await setDoc(doc(fdb, "userActivityLogs", id), logData);
        return logData;
    } catch (err: any) {
        if (isQuotaError(err)) {
            console.warn("[QUOTA FALLBACK] addUserActivityLog fallback to SQLite");
            const id = log.id || "act-" + Date.now();
            const logData = {
                id,
                userId: log.userId,
                activityType: log.activityType,
                activityDescription: log.activityDescription,
                createdAt: log.createdAt || new Date(),
                metadata: log.metadata ? (typeof log.metadata === "string" ? log.metadata : JSON.stringify(log.metadata)) : null
            };
            await db.insert(sqUserActivityLogs).values({
                id: logData.id,
                userId: logData.userId,
                activityType: logData.activityType,
                activityDescription: logData.activityDescription,
                createdAt: logData.createdAt,
                metadata: logData.metadata
            });
            return logData;
        }
        console.error("Firestore addUserActivityLog failed:", err?.message || err);
        throw err;
    }
}

export async function getUserActivityLogs(options: {
    page?: number;
    limit?: number;
    userId?: string;
    search?: string;
    type?: string;
    startDate?: string;
    endDate?: string;
}) {
    try {
        const page = options.page || 1;
        const limit = options.limit || 50;
        const offset = (page - 1) * limit;

        const usersList = (await getUsers()) as any[];
        const userMap = new Map<string, any>(usersList.map(u => [u.id, u]));

        const snapshot = await getDocs(collection(fdb, "userActivityLogs"));
        let logs = snapshot.docs.map(docSnap => ({ id: docSnap.id, ...convertTimestamps(docSnap.data()) }));

        logs.sort((a, b) => {
            const dateA = a.createdAt ? new Date(a.createdAt).getTime() : 0;
            const dateB = b.createdAt ? new Date(b.createdAt).getTime() : 0;
            return dateB - dateA;
        });

        if (options.userId) {
            logs = logs.filter(log => log.userId === options.userId);
        }
        if (options.type && options.type !== "all") {
            logs = logs.filter(log => log.activityType === options.type);
        }
        if (options.startDate) {
            const start = new Date(options.startDate).getTime();
            logs = logs.filter(log => log.createdAt && new Date(log.createdAt).getTime() >= start);
        }
        if (options.endDate) {
            const end = new Date(options.endDate);
            end.setDate(end.getDate() + 1);
            const endTime = end.getTime();
            logs = logs.filter(log => log.createdAt && new Date(log.createdAt).getTime() < endTime);
        }

        let joinedLogs = logs.map(log => {
            const u = userMap.get(log.userId);
            return {
                ...log,
                username: u ? u.username : "Unknown",
                email: u ? u.email : "",
                lastActive: u ? u.lastActive : null
            };
        });

        if (options.search) {
            const queryStr = options.search.trim().toLowerCase();
            joinedLogs = joinedLogs.filter(log => 
                (log.username && log.username.toLowerCase().includes(queryStr)) ||
                (log.email && log.email.toLowerCase().includes(queryStr)) ||
                (log.activityDescription && log.activityDescription.toLowerCase().includes(queryStr))
            );
        }

        const total = joinedLogs.length;
        const paginatedLogs = joinedLogs.slice(offset, offset + limit);

        return {
            logs: paginatedLogs,
            total,
            page,
            limit,
            totalPages: Math.ceil(total / limit)
        };
    } catch (err: any) {
        if (isQuotaError(err)) {
            console.warn("[QUOTA FALLBACK] getUserActivityLogs fallback to SQLite");
            const page = options.page || 1;
            const limit = options.limit || 50;
            const offset = (page - 1) * limit;

            const usersList = (await getUsers()) as any[];
            const userMap = new Map<string, any>(usersList.map(u => [u.id, u]));

            const rows = await db.select().from(sqUserActivityLogs);
            let logs = rows.map((log: any) => {
                let metadata = log.metadata;
                if (typeof metadata === "string") {
                    try {
                        metadata = JSON.parse(metadata);
                    } catch {
                        metadata = null;
                    }
                }
                return {
                    id: log.id,
                    userId: log.userId,
                    activityType: log.activityType,
                    activityDescription: log.activityDescription,
                    createdAt: log.createdAt,
                    metadata: metadata
                };
            });

            logs.sort((a, b) => {
                const dateA = a.createdAt ? new Date(a.createdAt).getTime() : 0;
                const dateB = b.createdAt ? new Date(b.createdAt).getTime() : 0;
                return dateB - dateA;
            });

            if (options.userId) {
                logs = logs.filter(log => log.userId === options.userId);
            }
            if (options.type && options.type !== "all") {
                logs = logs.filter(log => log.activityType === options.type);
            }
            if (options.startDate) {
                const start = new Date(options.startDate).getTime();
                logs = logs.filter(log => log.createdAt && new Date(log.createdAt).getTime() >= start);
            }
            if (options.endDate) {
                const end = new Date(options.endDate);
                end.setDate(end.getDate() + 1);
                const endTime = end.getTime();
                logs = logs.filter(log => log.createdAt && new Date(log.createdAt).getTime() < endTime);
            }

            let joinedLogs = logs.map(log => {
                const u = userMap.get(log.userId);
                return {
                    ...log,
                    username: u ? u.username : "Unknown",
                    email: u ? u.email : "",
                    lastActive: u ? u.lastActive : null
                };
            });

            if (options.search) {
                const queryStr = options.search.trim().toLowerCase();
                joinedLogs = joinedLogs.filter(log => 
                    (log.username && log.username.toLowerCase().includes(queryStr)) ||
                    (log.email && log.email.toLowerCase().includes(queryStr)) ||
                    (log.activityDescription && log.activityDescription.toLowerCase().includes(queryStr))
                );
            }

            const total = joinedLogs.length;
            const paginatedLogs = joinedLogs.slice(offset, offset + limit);

            return {
                logs: paginatedLogs,
                total,
                page,
                limit,
                totalPages: Math.ceil(total / limit)
            };
        }
        console.error("Firestore getUserActivityLogs failed:", err?.message || err);
        throw err;
    }
}
