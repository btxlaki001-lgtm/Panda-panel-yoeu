import { apiFetch } from "../lib/api";
import { useState, useEffect } from "react";
import { Transaction } from "../types";

interface Activity {
  id: string;
  username: string;
  type: "deposit" | "withdrawal";
  amount: number;
  status: string;
  timeAgo: string;
}

export function useLiveActivity(enabled: boolean = true) {
  const [activities, setActivities] = useState<Activity[]>([]);
  // We force isLocked to false so everyone can see the fake ticker flowing
  const [isLocked, setIsLocked] = useState(false);

  useEffect(() => {
    if (!enabled) {
      setActivities([]);
      return;
    }

    // Generate initial fake activities
    const generateFakeActivity = (): Activity => {
      const names = ["Rahul", "Vikram", "Neha", "Priya", "Amit", "Rajesh", "Sunil", "Karan", "Sonia", "Ankit", "Deepak", "Manoj"];
      const isDeposit = Math.random() > 0.4;
      const amounts = isDeposit ? [2000, 5000, 10000, 20000, 50000] : [100, 500, 1000, 2000, 5000, 10000];
      
      return {
        id: Math.random().toString(36).substring(2, 9),
        username: `${names[Math.floor(Math.random() * names.length)]}***`,
        type: isDeposit ? "deposit" : "withdrawal",
        amount: amounts[Math.floor(Math.random() * amounts.length)],
        status: "approved",
        timeAgo: "Just now"
      };
    };

    const initial: Activity[] = [];
    for (let i = 0; i < 6; i++) {
      initial.push({ ...generateFakeActivity(), timeAgo: `${i + 1} mins ago` });
    }
    setActivities(initial);

    // Update with a new transaction every 2 seconds
    const interval = setInterval(() => {
      setActivities(prev => {
        const newAct = generateFakeActivity();
        const updated = [newAct, ...prev].slice(0, 8);
        return updated.map((a, i) => {
          if (i === 0) return a;
          if (i === 1) return { ...a, timeAgo: "1 min ago" };
          return { ...a, timeAgo: `${i} mins ago` };
        });
      });
    }, 2000);

    return () => clearInterval(interval);
  }, [enabled]);

  return { activities, isLocked, refresh: () => {} };
}
