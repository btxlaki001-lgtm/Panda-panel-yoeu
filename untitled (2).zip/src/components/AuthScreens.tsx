import { apiFetch } from "../lib/api";
import React, { useState } from "react";
import { Shield, Eye, EyeOff, UserPlus, LogIn, Key, Phone, Mail, Smartphone } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";

interface AuthScreensProps {
  onLoginSuccess: (token: string, user: { id: string; username: string; role: "user" | "admin" }) => void;
  adminAutoToggle: () => void;
  showAdminGate?: boolean;
}

export default function AuthScreens({ onLoginSuccess, adminAutoToggle, showAdminGate }: AuthScreensProps) {
  const [screen, setScreen] = useState<"login" | "register" | "forgot" | "otp">("login");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);
  const [showPass, setShowPass] = useState(false);

  // Form Fields
  const [username, setUsername] = useState("");
  const [mobile, setMobile] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [referralCode, setReferralCode] = useState("");
  const [otpCode, setOtpCode] = useState("");
  const [forgotIdentifier, setForgotIdentifier] = useState("");

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setLoading(true);

    try {
      const response = await apiFetch("/api/auth/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ username, password })
      });

      const contentType = response.headers.get("content-type");
      if (contentType && !contentType.includes("application/json")) {
        const text = await response.text();
        console.error("Login response was not JSON:", text.substring(0, 200));
        throw new Error("Network error. Please refresh the page and try again.");
      }

      const data = await response.json();
      if (!response.ok) {
        if (data.error === "DEVICE_BANNED" || data.error === "ACCOUNT_BANNED" || (data.message || "").includes("banned")) {
          localStorage.setItem("panda_panel_banned", "true");
          window.location.reload();
          return;
        }
        throw new Error(data.message || data.error || "Login failed");
      }
      onLoginSuccess(data.token, data.user);
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setLoading(true);

    if (password !== confirmPassword) {
      setError("Passwords do not match");
      setLoading(false);
      return;
    }

    try {
      const response = await apiFetch("/api/auth/register", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ username, mobile, email, password, referralCode })
      });

      const contentType = response.headers.get("content-type");
      if (contentType && !contentType.includes("application/json")) {
        const text = await response.text();
        console.error("Register response was not JSON:", text.substring(0, 200));
        throw new Error("Network error. Please refresh the page and try again.");
      }

      const data = await response.json();
      if (!response.ok) {
        if (data.error === "DEVICE_BANNED" || data.error === "ACCOUNT_BANNED" || (data.message || "").includes("banned")) {
          localStorage.setItem("panda_panel_banned", "true");
          window.location.reload();
          return;
        }
        throw new Error(data.error || "Registration failed");
      }
      setSuccess("Account registered successfully! Logging you in...");
      setTimeout(() => {
        onLoginSuccess(data.token, data.user);
      }, 1500);
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  const handleForgotSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!forgotIdentifier) {
      setError("Please enter your registered Mobile Number or Email");
      return;
    }
    setError(null);
    setScreen("otp");
  };

  const handleOtpVerify = (e: React.FormEvent) => {
    e.preventDefault();
    if (otpCode.length < 4) {
      setError("Please enter a valid 4-digit code");
      return;
    }
    setError(null);
    setSuccess("OTP Verified! You can now reset your password.");
    setTimeout(() => {
      setSuccess(null);
      setScreen("login");
      setPassword("user123"); // Preset demo helper password
      setError("Demo reset helper: Password updated to 'user123'");
    }, 1500);
  };

  return (
    <div className="w-full max-w-md mx-auto p-4 flex flex-col justify-center min-h-[92vh] relative select-none">
      
      {/* Sleek Logo and Title Branding Header */}
      <div className="flex flex-col items-center justify-center mb-8 text-center">
        {/* Circle "PP" Logo matching admin panel styling */}
        <div className="w-16 h-16 rounded-full bg-gradient-to-br from-red-600 to-rose-600 border-2 border-white/20 flex items-center justify-center text-white font-black text-2xl tracking-widest shadow-[0_0_25px_rgba(239,68,68,0.4)] mb-4">
          PP
        </div>
        <h1 className="text-2xl font-black text-white tracking-widest uppercase font-sans">
          PANDA <span className="text-red-500">PANEL</span>
        </h1>
        <p className="text-xs text-slate-400 font-medium tracking-wider mt-1">
          Premium Account Run &amp; USDT Exchange
        </p>
      </div>

      <AnimatePresence mode="wait">
        {screen === "login" && (
          <motion.div
            key="login"
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -15 }}
            className="bg-[#0b0c10] border border-slate-800/80 p-6 rounded-2xl shadow-xl relative overflow-hidden"
          >
            <div className="flex items-center gap-3 mb-6">
              <div className="w-10 h-10 rounded-xl flex items-center justify-center bg-red-500/10 border border-red-500/20 text-red-500 shrink-0">
                <LogIn className="w-5 h-5" />
              </div>
              <div>
                <h2 className="text-lg font-bold text-slate-100">Sign In</h2>
                <p className="text-xs text-slate-400">Access your dashboard</p>
              </div>
            </div>

            {error && <div className="p-3 bg-red-950/40 border border-red-900/50 rounded-xl text-red-400 text-xs mb-4">{error}</div>}
            {success && <div className="p-3 bg-green-950/40 border border-green-900/50 rounded-xl text-green-400 text-xs mb-4">{success}</div>}

            <form onSubmit={handleLogin} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-400 uppercase tracking-wider mb-2">Username or Mobile</label>
                <div className="relative flex items-center bg-slate-950/60 border border-slate-800 focus-within:border-red-500/40 rounded-xl transition duration-200">
                  <div className="pl-4 pr-1 text-slate-500 shrink-0">
                    <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                      <path strokeLinecap="round" strokeLinejoin="round" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
                    </svg>
                  </div>
                  <input
                    type="text"
                    required
                    value={username}
                    onChange={(e) => setUsername(e.target.value)}
                    placeholder="Enter username"
                    className="w-full bg-transparent border-none py-3.5 px-3 text-sm text-slate-200 placeholder:text-slate-600 focus:outline-none focus:ring-0"
                  />
                </div>
              </div>

              <div>
                <div className="flex justify-between items-center mb-2">
                  <label className="block text-xs font-bold text-slate-400 uppercase tracking-wider">Password</label>
                  <button
                    type="button"
                    onClick={() => setScreen("forgot")}
                    className="text-[11px] text-red-500 hover:text-red-400 font-bold transition"
                  >
                    Forgot password?
                  </button>
                </div>
                <div className="relative flex items-center bg-slate-950/60 border border-slate-800 focus-within:border-red-500/40 rounded-xl transition duration-200">
                  <div className="pl-4 pr-1 text-slate-500 shrink-0">
                    <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                      <path strokeLinecap="round" strokeLinejoin="round" d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" />
                    </svg>
                  </div>
                  <input
                    type={showPass ? "text" : "password"}
                    required
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="Enter password"
                    className="w-full bg-transparent border-none py-3.5 px-3 text-sm text-slate-200 placeholder:text-slate-600 focus:outline-none focus:ring-0"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPass(!showPass)}
                    className="absolute right-4 text-slate-500 hover:text-slate-300 transition"
                  >
                    {showPass ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              <button
                type="submit"
                disabled={loading}
                className="w-full bg-gradient-to-r from-red-600 to-rose-600 hover:brightness-110 active:scale-[0.98] text-white font-bold py-3.5 px-4 rounded-xl shadow-lg shadow-red-500/10 transition duration-200 text-sm uppercase tracking-wider mt-2"
              >
                {loading ? "Authenticating..." : "Login"}
              </button>
            </form>

            <div className="mt-6 pt-6 border-t border-slate-900 text-center text-xs text-slate-400 font-semibold">
              New to PANDA PANEL?{" "}
              <button onClick={() => setScreen("register")} className="text-red-500 font-bold hover:underline ml-1">
                Create Account
              </button>
            </div>
          </motion.div>
        )}

        {screen === "register" && (
          <motion.div
            key="register"
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -15 }}
            className="bg-[#0b0c10] border border-slate-800/80 p-6 rounded-2xl shadow-xl"
          >
            <div className="flex items-center gap-3 mb-5">
              <div className="w-10 h-10 rounded-xl flex items-center justify-center bg-red-500/10 border border-red-500/20 text-red-500 shrink-0">
                <UserPlus className="w-5 h-5" />
              </div>
              <div>
                <h2 className="text-lg font-bold text-slate-100">Create Account</h2>
                <p className="text-xs text-slate-400">Join PANDA PANEL today</p>
              </div>
            </div>

            {error && <div className="p-3 bg-red-950/40 border border-red-900/50 rounded-xl text-red-400 text-xs mb-4">{error}</div>}
            {success && <div className="p-3 bg-green-950/40 border border-green-900/50 rounded-xl text-green-400 text-xs mb-4">{success}</div>}

            <form onSubmit={handleRegister} className="space-y-3.5">
              <div>
                <label className="block text-[11px] font-bold text-slate-400 uppercase tracking-wider mb-1.5">Username</label>
                <div className="relative flex items-center bg-slate-950/60 border border-slate-800 focus-within:border-red-500/40 rounded-xl transition duration-200">
                  <div className="pl-4 pr-1 text-slate-500 shrink-0">
                    <UserPlus className="w-4 h-4" />
                  </div>
                  <input
                    type="text"
                    required
                    value={username}
                    onChange={(e) => setUsername(e.target.value)}
                    placeholder="Enter username"
                    className="w-full bg-transparent border-none py-2.5 px-3 text-sm text-slate-200 placeholder:text-slate-600 focus:outline-none focus:ring-0"
                  />
                </div>
              </div>

              <div>
                <label className="block text-[11px] font-bold text-slate-400 uppercase tracking-wider mb-1.5">Mobile Number</label>
                <div className="relative flex items-center bg-slate-950/60 border border-slate-800 focus-within:border-red-500/40 rounded-xl transition duration-200">
                  <div className="pl-4 pr-1 text-slate-500 shrink-0">
                    <Smartphone className="w-4 h-4" />
                  </div>
                  <input
                    type="tel"
                    required
                    value={mobile}
                    onChange={(e) => setMobile(e.target.value)}
                    placeholder="Enter 10-digit number"
                    className="w-full bg-transparent border-none py-2.5 px-3 text-sm text-slate-200 placeholder:text-slate-600 focus:outline-none focus:ring-0"
                  />
                </div>
              </div>

              <div>
                <label className="block text-[11px] font-bold text-slate-400 uppercase tracking-wider mb-1.5">Email Address (Optional)</label>
                <div className="relative flex items-center bg-slate-950/60 border border-slate-800 focus-within:border-red-500/40 rounded-xl transition duration-200">
                  <div className="pl-4 pr-1 text-slate-500 shrink-0">
                    <Mail className="w-4 h-4" />
                  </div>
                  <input
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="Enter email address"
                    className="w-full bg-transparent border-none py-2.5 px-3 text-sm text-slate-200 placeholder:text-slate-600 focus:outline-none focus:ring-0"
                  />
                </div>
              </div>

              <div>
                <label className="block text-[11px] font-bold text-slate-400 uppercase tracking-wider mb-1.5">Password</label>
                <div className="relative flex items-center bg-slate-950/60 border border-slate-800 focus-within:border-red-500/40 rounded-xl transition duration-200">
                  <div className="pl-4 pr-1 text-slate-500 shrink-0">
                    <Key className="w-4 h-4" />
                  </div>
                  <input
                    type="password"
                    required
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="Create password"
                    className="w-full bg-transparent border-none py-2.5 px-3 text-sm text-slate-200 placeholder:text-slate-600 focus:outline-none focus:ring-0"
                  />
                </div>
              </div>

              <div>
                <label className="block text-[11px] font-bold text-slate-400 uppercase tracking-wider mb-1.5">Confirm Password</label>
                <div className="relative flex items-center bg-slate-950/60 border border-slate-800 focus-within:border-red-500/40 rounded-xl transition duration-200">
                  <div className="pl-4 pr-1 text-slate-500 shrink-0">
                    <Key className="w-4 h-4" />
                  </div>
                  <input
                    type="password"
                    required
                    value={confirmPassword}
                    onChange={(e) => setConfirmPassword(e.target.value)}
                    placeholder="Confirm password"
                    className="w-full bg-transparent border-none py-2.5 px-3 text-sm text-slate-200 placeholder:text-slate-600 focus:outline-none focus:ring-0"
                  />
                </div>
              </div>

              <div>
                <label className="block text-[11px] font-bold text-slate-400 uppercase tracking-wider mb-1.5">Referral Code (Optional)</label>
                <div className="relative flex items-center bg-slate-950/60 border border-slate-800 focus-within:border-red-500/40 rounded-xl transition duration-200">
                  <div className="pl-4 pr-1 text-slate-500 shrink-0">
                    <span className="text-xs font-bold text-slate-500">#</span>
                  </div>
                  <input
                    type="text"
                    value={referralCode}
                    onChange={(e) => setReferralCode(e.target.value)}
                    placeholder="Enter referral code"
                    className="w-full bg-transparent border-none py-2.5 px-3 text-sm text-slate-200 placeholder:text-slate-600 focus:outline-none focus:ring-0 uppercase font-mono tracking-widest font-bold text-red-500"
                  />
                </div>
              </div>

              <button
                type="submit"
                disabled={loading}
                className="w-full bg-gradient-to-r from-red-600 to-rose-600 hover:brightness-110 active:scale-[0.98] text-white font-bold py-3 px-4 rounded-xl shadow-lg shadow-red-500/10 transition duration-200 text-sm uppercase tracking-wider"
              >
                {loading ? "Registering account..." : "Create Account"}
              </button>
            </form>

            <div className="mt-4 pt-4 border-t border-slate-900 text-center text-xs text-slate-400 font-semibold">
              Already have an account?{" "}
              <button onClick={() => setScreen("login")} className="text-red-500 font-bold hover:underline ml-1">
                Sign In
              </button>
            </div>
          </motion.div>
        )}

        {screen === "forgot" && (
          <motion.div
            key="forgot"
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -15 }}
            className="bg-[#0b0c10] border border-slate-800/80 p-6 rounded-2xl shadow-xl"
          >
            <div className="flex items-center gap-3 mb-3">
              <div className="w-10 h-10 rounded-xl flex items-center justify-center bg-red-500/10 border border-red-500/20 text-red-500 shrink-0">
                <Key className="w-5 h-5" />
              </div>
              <h2 className="text-lg font-bold text-slate-100">Reset Password</h2>
            </div>
            <p className="text-xs text-slate-400 mb-4 leading-relaxed">
              Enter your registered mobile number or email address, and we will trigger an OTP code for reset validation.
            </p>

            {error && <div className="p-3 bg-red-950/40 border border-red-900/50 rounded-xl text-red-400 text-xs mb-4">{error}</div>}

            <form onSubmit={handleForgotSubmit} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-400 uppercase tracking-wider mb-2">Registered Mobile / Email</label>
                <div className="relative flex items-center bg-slate-950/60 border border-slate-800 focus-within:border-red-500/40 rounded-xl transition duration-200">
                  <div className="pl-4 pr-1 text-slate-500 shrink-0">
                    <Smartphone className="w-4 h-4" />
                  </div>
                  <input
                    type="text"
                    required
                    value={forgotIdentifier}
                    onChange={(e) => setForgotIdentifier(e.target.value)}
                    placeholder="Enter mobile or email"
                    className="w-full bg-transparent border-none py-3.5 px-3 text-sm text-slate-200 placeholder:text-slate-600 focus:outline-none focus:ring-0"
                  />
                </div>
              </div>

              <button
                type="submit"
                className="w-full bg-gradient-to-r from-red-600 to-rose-600 hover:brightness-110 active:scale-[0.98] text-white font-bold py-3.5 px-4 rounded-xl shadow-lg transition duration-200 text-xs uppercase tracking-wider"
              >
                Send OTP
              </button>
            </form>

            <div className="mt-4 text-center">
              <button onClick={() => setScreen("login")} className="text-xs text-slate-400 hover:text-red-500 font-bold transition">
                Back to Sign In
              </button>
            </div>
          </motion.div>
        )}

        {screen === "otp" && (
          <motion.div
            key="otp"
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -15 }}
            className="bg-[#0b0c10] border border-slate-800/80 p-6 rounded-2xl shadow-xl"
          >
            <div className="flex items-center gap-3 mb-3">
              <div className="w-10 h-10 rounded-xl flex items-center justify-center bg-red-500/10 border border-red-500/20 text-red-500 shrink-0">
                <Phone className="w-5 h-5" />
              </div>
              <h2 className="text-lg font-bold text-slate-100">OTP Verification</h2>
            </div>
            <p className="text-xs text-slate-400 mb-4 leading-relaxed">
              We have sent a 4-digit code to your registered contact channel. Enter it below to proceed.
            </p>

            {error && <div className="p-3 bg-red-950/40 border border-red-900/50 rounded-xl text-red-400 text-xs mb-4">{error}</div>}
            {success && <div className="p-3 bg-green-950/40 border border-green-900/50 rounded-xl text-green-400 text-xs mb-4">{success}</div>}

            <form onSubmit={handleOtpVerify} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-400 uppercase tracking-wider mb-2 text-center">Verification Code</label>
                <div className="flex justify-center">
                  <input
                    type="text"
                    required
                    maxLength={4}
                    value={otpCode}
                    onChange={(e) => setOtpCode(e.target.value.replace(/\D/g, ""))}
                    placeholder="1234"
                    className="w-32 bg-slate-950/80 border-2 border-red-500/30 focus:border-red-500 rounded-xl text-center px-4 py-3 text-lg tracking-[12px] font-bold text-red-500 outline-none transition"
                  />
                </div>
              </div>

              <button
                type="submit"
                className="w-full bg-gradient-to-r from-red-600 to-rose-600 hover:brightness-110 active:scale-[0.98] text-white font-bold py-3.5 px-4 rounded-xl shadow-lg transition duration-200 text-xs uppercase tracking-wider"
              >
                Verify Code
              </button>
            </form>

            <div className="flex items-center justify-between mt-4 px-1">
              <button
                type="button"
                onClick={() => {
                  setError("Code resent successfully! (Demo helper: enter any 4 digits)");
                }}
                className="text-xs text-red-500 hover:text-red-400 font-bold transition"
              >
                Resend Code
              </button>
              <button onClick={() => setScreen("login")} className="text-xs text-slate-400 hover:text-slate-300 font-bold transition">
                Cancel
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
