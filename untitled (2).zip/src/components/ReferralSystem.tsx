import { apiFetch } from "../lib/api";
import React, { useState, useEffect } from "react";
import { 
  ArrowLeft, Users, Gift, Share2, Copy, Trophy, CheckCircle2, History
} from "lucide-react";
import { Transaction } from "../types";

interface ReferralSystemProps {
  onBack: () => void;
  token: string;
}

interface ReferredUser {
  username: string;
  kycStatus: string;
  createdAt: string;
}

export default function ReferralSystem({ onBack, token }: ReferralSystemProps) {
  const [referralCode, setReferralCode] = useState("");
  const [referredUsers, setReferredUsers] = useState<ReferredUser[]>([]);
  const [commissions, setCommissions] = useState<Transaction[]>([]);
  const [referralIncome, setReferralIncome] = useState(0);
  const [copied, setCopied] = useState(false);

  const fetchReferralDetails = async () => {
    try {
      const response = await apiFetch("/api/referrals", {
        headers: { "Authorization": `Bearer ${token}` }
      });
      const data = await response.json();
      if (response.ok) {
        setReferralCode(data.referralCode);
        setReferredUsers(data.referredUsers || []);
        setCommissions(data.commissions || []);
        setReferralIncome(data.referralIncome || 0);
      }
    } catch (err) {
      console.error("Error loading referral details", err);
    }
  };

  useEffect(() => {
    fetchReferralDetails();
  }, []);

  const getInviteLink = () => {
    return `${window.location.origin}/?ref=${referralCode}`;
  };

  const handleCopy = () => {
    navigator.clipboard.writeText(getInviteLink());
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const shareViaWhatsApp = () => {
    const text = `Join PANDA PANEL, the premium investment & earning hub! Register using my link & start earning 1% direct commissions plus ₹200 Active Bonus! 💰📈\n\n${getInviteLink()}`;
    window.open(`https://api.whatsapp.com/send?text=${encodeURIComponent(text)}`, "_blank");
  };

  const shareViaTelegram = () => {
    const text = `Join PANDA PANEL, the premium investment & earning hub! Register using my link & start earning 1% direct commissions plus ₹200 Active Bonus! 💰📈`;
    window.open(`https://t.me/share/url?url=${encodeURIComponent(getInviteLink())}&text=${encodeURIComponent(text)}`, "_blank");
  };

  return (
    <div className="space-y-5">
      {/* Page Title Panel */}
      <div className="flex items-center gap-3 bg-[#0D1425] border border-slate-800/50 p-4 rounded-[20px]">
        <button 
          onClick={onBack}
          className="p-2 bg-[#05070D] hover:bg-slate-850 border border-slate-800 rounded-xl text-slate-300 hover:text-white transition active:scale-95"
        >
          <ArrowLeft className="w-4 h-4" />
        </button>
        <div className="w-9 h-9 rounded-full flex items-center justify-center bg-gradient-to-br from-red-600 to-rose-600 border border-red-500/30 text-white font-black text-xs tracking-wider shrink-0 shadow-md">PP</div>
        <div>
          <h2 className="text-sm font-black text-slate-100 uppercase tracking-wide">REFERRAL SYSTEM</h2>
          <p className="text-[10px] text-slate-400 font-bold uppercase">Earn commissions and elite rewards</p>
        </div>
      </div>

      {/* Stats and Code Overview */}
      <div className="bg-[#0D1425] border border-slate-800/50 rounded-[24px] p-5 shadow-xl space-y-5 relative overflow-hidden">
        <div className="absolute top-0 right-0 w-24 h-24 bg-red-500/5 rounded-full blur-2xl pointer-events-none" />
        
        <div className="flex justify-between items-center bg-[#05070D] border border-slate-800/60 p-4 rounded-2xl">
          <div>
            <span className="text-[9px] uppercase font-black text-slate-500 tracking-wider block">My Invite Commissions</span>
            <span className="text-xl font-black text-red-400 font-mono block mt-1">₹{referralIncome.toLocaleString()}</span>
          </div>
          <div className="p-2.5 bg-red-500/10 border border-red-500/20 text-red-400 rounded-xl">
            <Trophy className="w-4 h-4" />
          </div>
        </div>

        <div className="space-y-2">
          <label className="block text-[10px] uppercase text-slate-400 font-black tracking-wider">Your Unique Invite Code</label>
          <div className="flex items-center gap-2 bg-[#05070D] border border-slate-800/80 rounded-2xl p-2 pl-4">
            <span className="font-mono text-sm font-black text-slate-200 tracking-widest uppercase select-all">{referralCode || "LOADING..."}</span>
            <button
              onClick={handleCopy}
              className="ml-auto bg-[#0D1425] hover:bg-slate-850 border border-slate-800 text-[10px] font-black uppercase text-red-500 px-3.5 py-1.5 rounded-xl transition flex items-center gap-1.5"
            >
              <Copy className="w-3.5 h-3.5" />
              <span>{copied ? "Copied" : "Copy"}</span>
            </button>
          </div>
        </div>

        {/* Share buttons */}
        <div className="grid grid-cols-2 gap-3 text-[10px] font-black uppercase">
          <button
            onClick={shareViaWhatsApp}
            className="w-full bg-emerald-600/10 hover:bg-emerald-600/20 border border-emerald-500/20 text-emerald-400 py-3 rounded-2xl flex items-center justify-center gap-2 transition"
          >
            <Gift className="w-4 h-4 text-emerald-500" />
            <span>WhatsApp Invite</span>
          </button>
          <button
            onClick={shareViaTelegram}
            className="w-full bg-red-600/10 hover:bg-red-600/20 border border-red-500/20 text-red-400 py-3 rounded-2xl flex items-center justify-center gap-2 transition"
          >
            <Share2 className="w-4 h-4 text-red-400" />
            <span>Telegram Invite</span>
          </button>
        </div>
      </div>

      {/* Network Members Logs */}
      <div className="bg-[#0D1425] border border-slate-800/50 rounded-[24px] p-5 shadow-xl">
        <h3 className="text-[10px] uppercase font-black tracking-wider text-slate-300 flex items-center gap-1.5 mb-4">
          <Users className="w-4 h-4 text-red-500" /> Team Network List ({referredUsers.length})
        </h3>

        <div className="space-y-3 max-h-[250px] overflow-y-auto custom-scrollbar">
          {referredUsers.length === 0 ? (
            <p className="text-[10px] text-slate-500 uppercase font-bold text-center py-6 bg-[#05070D] rounded-2xl border border-slate-800/60">
              No network members referred yet.
            </p>
          ) : (
            referredUsers.map((member, idx) => (
              <div 
                key={idx}
                className="bg-[#05070D] border border-slate-800/70 rounded-2xl p-3 flex justify-between items-center text-xs"
              >
                <div>
                  <div className="font-black text-slate-200">{member.username}</div>
                  <div className="text-[9px] text-slate-500 mt-1 font-mono">Joined: {new Date(member.createdAt).toLocaleDateString()}</div>
                </div>

                <div>
                  <span className={`text-[9px] px-2.5 py-1 rounded-xl border font-black uppercase tracking-wider ${
                    member.kycStatus === "Approved" 
                      ? "bg-green-500/10 text-green-400 border-green-500/20" 
                      : member.kycStatus === "Pending"
                      ? "bg-red-500/10 text-red-400 border-red-500/20 animate-pulse"
                      : "bg-[#0D1425] text-slate-500 border-slate-800"
                  }`}>
                    KYC: {member.kycStatus}
                  </span>
                </div>
              </div>
            ))
          )}
        </div>
      </div>

      {/* Commission Earning Logs */}
      <div className="bg-[#0D1425] border border-slate-800/50 rounded-[24px] p-5 shadow-xl">
        <h3 className="text-[10px] uppercase font-black tracking-wider text-slate-300 flex items-center gap-1.5 mb-4">
          <History className="w-4 h-4 text-red-500" /> Invite Commission Earnings
        </h3>

        <div className="space-y-3">
          {commissions.length === 0 ? (
            <p className="text-[10px] text-slate-500 uppercase font-bold text-center py-6 bg-[#05070D] rounded-2xl border border-slate-800/60">
              No direct commission transactions logged yet.
            </p>
          ) : (
            commissions.map((tx) => (
              <div 
                key={tx.id}
                className="bg-[#05070D] border border-slate-800/70 rounded-2xl p-3.5 flex justify-between items-center text-xs"
              >
                <div>
                  <div className="font-black text-slate-200">₹{tx.amount.toLocaleString()} Earned</div>
                  <div className="text-[9px] text-slate-500 mt-1 font-mono">Approved: {new Date(tx.createdAt).toLocaleDateString()}</div>
                </div>

                <div className="text-right">
                  <span className="text-[9px] font-mono text-green-400 font-black uppercase tracking-wider bg-green-500/10 border border-green-500/20 px-2 py-1 rounded-xl">
                    1% + Bonus
                  </span>
                </div>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
}
