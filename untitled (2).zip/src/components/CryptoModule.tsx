import { apiFetch } from "../lib/api";
import React, { useState } from "react";
import { 
  ArrowLeft, Bitcoin, RefreshCw, Copy, CheckCircle2, 
  Wallet, TrendingUp, TrendingDown, Send, ShieldCheck
} from "lucide-react";
import { User, SiteSettings } from "../types";

interface CryptoModuleProps {
  user: User;
  settings: SiteSettings;
  onBack: () => void;
  token: string;
  onRefresh: () => void;
}

export default function CryptoModule({ user, settings, onBack, token, onRefresh }: CryptoModuleProps) {
  const [usdtAmount, setUsdtAmount] = useState("");
  const [utr, setUtr] = useState("");
  const [receivedHolderName, setReceivedHolderName] = useState("");
  const [receivedBankName, setReceivedBankName] = useState("");
  const [receivedAccountNumber, setReceivedAccountNumber] = useState("");
  const [receivedIfsc, setReceivedIfsc] = useState("");
  const [fundType, setFundType] = useState("Clean Fund Rate");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);
  const [copied, setCopied] = useState(false);

  const sellRate = fundType === "Clean Fund Rate" ? (settings.cleanFundRate || 92.5) :
                   fundType === "Stock Fund Rate" ? (settings.stockFundRate || 88.0) :
                   fundType === "Rat Fund Rate" ? (settings.ratFundRate || 85.0) :
                   (settings.usdtSellRate || 88.0);

  const inrAmount = usdtAmount ? (Number(usdtAmount) * sellRate).toFixed(2) : "0.00";

  const handleCopy = () => {
    navigator.clipboard.writeText(settings.usdtWalletAddress);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setSuccess(null);

    const amount = Number(usdtAmount);
    if (!amount || amount < 10) {
      setError("Minimum 10 USDT required for exchange");
      return;
    }

    if (!receivedHolderName || !receivedBankName || !receivedAccountNumber || !receivedIfsc) {
      setError("Please enter all bank details for receiving money");
      return;
    }

    setLoading(true);
    try {
      const response = await apiFetch("/api/usdt/sell", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Authorization": `Bearer ${token}`
        },
        body: JSON.stringify({
          usdtAmount: amount,
          inrAmount: Number(inrAmount),
          utr,
          fundType,
          bankDetails: {
            holderName: receivedHolderName,
            bankName: receivedBankName,
            accountNumber: receivedAccountNumber,
            ifsc: receivedIfsc
          }
        })
      });

      const data = await response.json();
      if (!response.ok) throw new Error(data.error || "Transaction failed");

      setSuccess("Sell request submitted! Admin will process your payout soon.");
      setUsdtAmount("");
      setReceivedHolderName("");
      setReceivedBankName("");
      setReceivedAccountNumber("");
      setReceivedIfsc("");
      onRefresh();
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-5">
      {/* Page Header */}
      <div className="flex items-center gap-3 bg-[#0D1425] border border-slate-800/50 p-4 rounded-[20px]">
        <button 
          onClick={onBack}
          className="p-2 bg-[#05070D] hover:bg-slate-850 border border-slate-800 rounded-xl text-slate-300 hover:text-white transition active:scale-95"
        >
          <ArrowLeft className="w-4 h-4" />
        </button>
        <div className="w-9 h-9 rounded-full flex items-center justify-center bg-gradient-to-br from-red-600 to-rose-600 border border-red-500/30 text-white font-black text-xs tracking-wider shrink-0 shadow-md">PP</div>
        <div>
          <h2 className="text-sm font-black text-slate-100 uppercase tracking-wide">USDT EXCHANGE</h2>
          <p className="text-[10px] text-slate-400 font-bold uppercase">Liquidity and Payout Desk</p>
        </div>
      </div>

      <div className="p-1 bg-[#05070D] border border-slate-800/60 rounded-2xl">
        <div className="py-2.5 rounded-xl text-xs font-black transition flex items-center justify-center gap-2 bg-[#0D1425] text-red-500 border border-slate-800/40 shadow-inner">
          <TrendingDown className="w-3.5 h-3.5" />
          <span className="uppercase tracking-wider">SELL USDT (TRC20)</span>
        </div>
      </div>

      <div className="bg-[#0D1425] border border-slate-800/50 rounded-[24px] p-5 shadow-xl space-y-5">
        {/* Rates Display */}
        <div className="flex justify-between items-center bg-[#05070D] p-4 rounded-2xl border border-slate-800/60">
          <div>
            <span className="text-[9px] font-black text-slate-500 uppercase tracking-wider">CURRENT EXCHANGE RATE</span>
            <div className="text-xl font-black text-red-500 mt-0.5">₹{sellRate} <span className="text-[10px] text-slate-400">/ USDT</span></div>
          </div>
          <div className="text-right">
            <span className="text-[9px] font-black text-slate-500 uppercase tracking-wider">WALLET BALANCE</span>
            <div className="text-sm font-mono font-black text-slate-200 mt-0.5">₹{user.walletBalance.toLocaleString()}</div>
          </div>
        </div>

        {error && <div className="p-3 bg-red-500/10 border border-red-500/20 text-red-400 text-xs rounded-xl font-bold">{error}</div>}
        {success && <div className="p-3 bg-green-500/10 border border-green-500/20 text-green-300 text-xs rounded-xl font-bold">{success}</div>}

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-[10px] font-black text-slate-400 uppercase tracking-wider mb-2">Select Liquidity Fund Type</label>
            <select
              value={fundType}
              onChange={(e) => setFundType(e.target.value)}
              className="w-full bg-[#05070D] border border-slate-800 focus:border-red-500/40 rounded-xl px-4 py-3 text-xs font-black text-slate-200 outline-none transition"
            >
              <option value="Clean Fund Rate">Clean Fund (₹{settings.cleanFundRate || 92.5})</option>
              <option value="Stock Fund Rate">Stock Fund (₹{settings.stockFundRate || 88.0})</option>
              <option value="Rat Fund Rate">Rat Fund (₹{settings.ratFundRate || 85.0})</option>
            </select>
          </div>

          <div>
            <label className="block text-[10px] font-black text-slate-400 uppercase tracking-wider mb-2">Amount to Exchange (USDT)</label>
            <div className="relative">
              <input
                type="number"
                step="0.01"
                required
                value={usdtAmount}
                onChange={(e) => setUsdtAmount(e.target.value)}
                placeholder="Min 10 USDT"
                className="w-full bg-[#05070D] border border-slate-800 focus:border-red-500/40 rounded-2xl px-5 py-3.5 text-base font-black text-slate-100 outline-none transition font-mono"
              />
              <span className="absolute right-5 top-3.5 font-black text-xs text-slate-500 uppercase tracking-wider">USDT</span>
            </div>
            <p className="text-[9px] text-slate-500 font-bold uppercase tracking-tight mt-1.5">Minimum transaction size: 10.00 USDT.</p>
          </div>

          <div className="bg-[#05070D] p-4 rounded-2xl border border-slate-800/60 flex justify-between items-center">
            <span className="text-[10px] font-black text-slate-400 uppercase tracking-wider">Total INR Receivable</span>
            <span className="text-lg font-black text-red-500">₹{inrAmount}</span>
          </div>

          <div className="space-y-4 pt-4 border-t border-slate-800/60">
            <div className="space-y-3">
              <span className="text-[10px] font-black text-red-500 uppercase tracking-wider block">Target Bank Account details</span>
              
              <div className="grid grid-cols-1 gap-3.5">
                <div>
                  <label className="block text-[9px] font-black text-slate-500 uppercase tracking-wider mb-1">Holder Name</label>
                  <input
                    type="text"
                    required
                    value={receivedHolderName}
                    onChange={(e) => setReceivedHolderName(e.target.value)}
                    placeholder="Payee full name"
                    className="w-full bg-[#05070D] border border-slate-800 focus:border-red-500/40 rounded-xl px-4 py-2.5 text-xs text-slate-200 outline-none transition"
                  />
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-[9px] font-black text-slate-500 uppercase tracking-wider mb-1">Bank Name</label>
                    <input
                      type="text"
                      required
                      value={receivedBankName}
                      onChange={(e) => setReceivedBankName(e.target.value)}
                      placeholder="e.g. ICICI"
                      className="w-full bg-[#05070D] border border-slate-800 focus:border-red-500/40 rounded-xl px-4 py-2.5 text-xs text-slate-200 outline-none transition"
                    />
                  </div>
                  <div>
                    <label className="block text-[9px] font-black text-slate-500 uppercase tracking-wider mb-1">IFSC Code</label>
                    <input
                      type="text"
                      required
                      value={receivedIfsc}
                      onChange={(e) => setReceivedIfsc(e.target.value)}
                      placeholder="IFSC"
                      className="w-full bg-[#05070D] border border-slate-800 focus:border-red-500/40 rounded-xl px-4 py-2.5 text-xs text-slate-200 outline-none transition uppercase"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-[9px] font-black text-slate-500 uppercase tracking-wider mb-1">Account Number</label>
                  <input
                    type="text"
                    required
                    value={receivedAccountNumber}
                    onChange={(e) => setReceivedAccountNumber(e.target.value)}
                    placeholder="Bank Account Number"
                    className="w-full bg-[#05070D] border border-slate-800 focus:border-red-500/40 rounded-xl px-4 py-2.5 text-xs text-slate-200 outline-none transition"
                  />
                </div>
              </div>
            </div>

            <div className="space-y-2 pt-2 border-t border-slate-800/40">
              <span className="text-[10px] font-black text-red-500 uppercase tracking-wider block">Escrow TRC20 Wallet Address</span>
              <p className="text-[9px] text-slate-500 font-bold uppercase tracking-tight">Send USDT to this verified company address only</p>
              <div className="flex items-center justify-between bg-[#05070D] border border-slate-800/60 rounded-xl p-3">
                <span className="font-mono text-[10px] font-bold text-slate-200 truncate pr-4 select-all">{settings.usdtWalletAddress}</span>
                <button
                  type="button"
                  onClick={handleCopy}
                  className="text-[10px] text-red-500 hover:text-red-400 font-black flex items-center gap-1 shrink-0 uppercase tracking-wider"
                >
                  <Copy className="w-3.5 h-3.5" />
                  <span>{copied ? "Copied" : "Copy"}</span>
                </button>
              </div>
            </div>

            <div>
              <label className="block text-[10px] font-black text-slate-400 uppercase tracking-wider mb-2">Enter Transaction ID / TXID Hash</label>
              <input
                type="text"
                required
                value={utr}
                onChange={(e) => setUtr(e.target.value)}
                placeholder="Paste TRC20 blockchain transfer hash"
                className="w-full bg-[#05070D] border border-slate-800 focus:border-red-500/40 rounded-xl px-4 py-2.5 text-xs text-slate-200 outline-none transition font-mono"
              />
            </div>
          </div>

          <button
            type="submit"
            disabled={loading}
            className="w-full bg-gradient-to-r from-red-500 to-rose-600 hover:from-red-400 text-white font-black py-4 rounded-2xl shadow-xl transition active:scale-95 flex items-center justify-center gap-2 uppercase text-xs tracking-wider mt-4"
          >
            {loading ? <RefreshCw className="w-4 h-4 animate-spin" /> : <TrendingDown className="w-4 h-4" />}
            <span>Confirm Sell Request</span>
          </button>
        </form>

        <div className="pt-4 border-t border-slate-800/60 flex items-center gap-3">
          <div className="w-9 h-9 rounded-xl bg-green-500/10 border border-green-500/20 flex items-center justify-center">
            <ShieldCheck className="w-4 h-4 text-green-500" />
          </div>
          <div className="flex-1">
            <h4 className="text-[10px] font-black text-slate-300 uppercase tracking-wide">SECURE ESCROW GUARANTEE</h4>
            <p className="text-[9px] text-slate-500 font-bold uppercase tracking-tight mt-0.5">Settlements require strict TXID verification. Standard dispatch time: 10-15 mins.</p>
          </div>
        </div>
      </div>
    </div>
  );
}
