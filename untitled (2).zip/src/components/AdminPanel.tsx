import { apiFetch } from "../lib/api";
import React, { useState, useEffect, useRef } from "react";
import { 
  ArrowLeft, Shield, Users, ArrowDownCircle, ArrowUpCircle, MessageSquare, 
  Settings, Send, Check, X, FileSpreadsheet, Landmark, Trophy, RefreshCw,
  Zap, Activity, Clock, Download, Trash2, ArrowUpRight, Key, Lock, Copy
} from "lucide-react";
import { Transaction, User, SupportTicket, SiteSettings } from "../types";

interface AdminPanelProps {
  onBack: () => void;
  token: string;
}

const CountUpStat = ({ value, prefix = "", suffix = "" }: { value: number, prefix?: string, suffix?: string }) => {
  const [displayValue, setDisplayValue] = useState(0);
  
  useEffect(() => {
    let start = 0;
    const end = value;
    if (end === 0) {
      setDisplayValue(0);
      return;
    }

    const duration = 1200; // 1.2 seconds
    const startTime = performance.now();

    const update = (now: number) => {
      const elapsed = now - startTime;
      const progress = Math.min(elapsed / duration, 1);
      
      // Easing function: easeOutExpo
      const easeProgress = progress === 1 ? 1 : 1 - Math.pow(2, -10 * progress);
      const current = Math.floor(easeProgress * end);
      
      setDisplayValue(current);

      if (progress < 1) {
        requestAnimationFrame(update);
      }
    };

    requestAnimationFrame(update);
  }, [value]);

  return (
    <span>
      {prefix}{displayValue.toLocaleString()}{suffix}
    </span>
  );
};

interface AdminDashboardStats {
  totalUsers: number;
  activeUsers: number;
  onlineUsers: number;
  totalDeposits: number;
  totalWithdrawals: number;
  pendingDeposits: number;
  pendingWithdrawals: number;
  pendingUsdt: number;
  openTickets: number;
  transactions: Transaction[];
}

const TrendIndicator = ({ current, previous, prefix = "" }: { current: number, previous: number, prefix?: string }) => {
  if (previous === undefined || previous === null || current === previous) return null;
  const diff = current - previous;
  const isPositive = diff > 0;
  
  return (
    <div className={`flex items-center gap-0.5 text-[9px] font-bold px-1.5 py-0.5 rounded shadow-sm ${
      isPositive ? "text-green-400 bg-green-500/10 border border-green-500/20" : "text-red-400 bg-red-500/10 border border-red-500/20"
    }`}>
      {isPositive ? "+" : ""}{prefix}{diff.toLocaleString()}
    </div>
  );
};

export default function AdminPanel({ onBack, token }: AdminPanelProps) {
  const [tab, setTab] = useState<"dashboard" | "deposits" | "withdrawals" | "usdt" | "users" | "tickets" | "settings" | "history" | "activity">("dashboard");
  const [stats, setStats] = useState<AdminDashboardStats | null>(null);
  const [prevStats, setPrevStats] = useState<AdminDashboardStats | null>(null);
  const [users, setUsers] = useState<User[]>([]);
  const [tickets, setTickets] = useState<SupportTicket[]>([]);
  const [settings, setSettings] = useState<SiteSettings | null>(null);
  const [loading, setLoading] = useState(false);
  const [actionLoadingId, setActionLoadingId] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState("");
  const [creditAmount, setCreditAmount] = useState<{ [userId: string]: string }>({});
  const [lastRefreshed, setLastRefreshed] = useState<Date>(new Date());

  const handleRefreshAll = () => {
    setLoading(true);
    setLastRefreshed(new Date());
    Promise.all([
      fetchDashboardStats(),
      fetchUsers(),
      fetchTickets(),
      fetchSettings()
    ]).finally(() => {
      setTimeout(() => setLoading(false), 600);
    });
  };

  // Live Activity Polling
  useEffect(() => {
    handleRefreshAll();
    
    // Auto-refresh every 5 seconds for hyper-live activity
    const interval = setInterval(() => {
      setLastRefreshed(new Date());
      fetchDashboardStats();
      fetchUsers();
      fetchTickets();
    }, 5000);

    return () => clearInterval(interval);
  }, [token]);

  // Send notification state
  const [notifTitle, setNotifTitle] = useState("");
  const [notifMessage, setNotifMessage] = useState("");
  const [notifSuccess, setNotifSuccess] = useState<string | null>(null);

  // Reply ticket state
  const [activeTicketId, setActiveTicketId] = useState<string | null>(null);
  const [ticketReplyText, setTicketReplyText] = useState("");

  // Site settings state edit form
  const [editUpi, setEditUpi] = useState("");
  const [editMinDeposit, setEditMinDeposit] = useState("");
  const [editMinWithdraw, setEditMinWithdraw] = useState("");
  const [editQrCodeUrl, setEditQrCodeUrl] = useState("");
  const [editUsdtBuyRate, setEditUsdtBuyRate] = useState("");
  const [editUsdtSellRate, setEditUsdtSellRate] = useState("");
  const [editCleanFundRate, setEditCleanFundRate] = useState("");
  const [editStockFundRate, setEditStockFundRate] = useState("");
  const [editRatFundRate, setEditRatFundRate] = useState("");
  const [editUsdtWallet, setEditUsdtWallet] = useState("");
  const [editDepositEnabled, setEditDepositEnabled] = useState(true);
  const [editLiveActivityEnabled, setEditLiveActivityEnabled] = useState(true);
  const [editAdminBanks, setEditAdminBanks] = useState<any[]>([]);
  const [settingsSuccess, setSettingsSuccess] = useState<string | null>(null);

  // Permanent Activity Logs State
  const [activityLogs, setActivityLogs] = useState<any[]>([]);
  const [activityTotal, setActivityTotal] = useState(0);
  const [activityPage, setActivityPage] = useState(1);
  const [activityLimit] = useState(25);
  const [activityTypeFilter, setActivityTypeFilter] = useState("all");
  const [activityUserFilter, setActivityUserFilter] = useState("all");
  const [activitySearch, setActivitySearch] = useState("");
  const [activityStartDate, setActivityStartDate] = useState("");
  const [activityEndDate, setActivityEndDate] = useState("");
  const [activityLoading, setActivityLoading] = useState(false);

  const fetchActivityLogs = async () => {
    try {
      setActivityLoading(true);
      const queryParams = new URLSearchParams({
        page: activityPage.toString(),
        limit: activityLimit.toString(),
        ...(activityTypeFilter !== "all" && { type: activityTypeFilter }),
        ...(activityUserFilter !== "all" && { userId: activityUserFilter }),
        ...(activitySearch.trim() && { search: activitySearch.trim() }),
        ...(activityStartDate && { startDate: activityStartDate }),
        ...(activityEndDate && { endDate: activityEndDate }),
      });

      const response = await apiFetch(`/api/admin/activity-logs?${queryParams.toString()}`, {
        headers: { "Authorization": `Bearer ${token}` }
      });
      if (response.ok) {
        const data = await response.json();
        setActivityLogs(data.logs || []);
        setActivityTotal(data.total || 0);
      }
    } catch (err) {
      console.error("Failed to load activity logs:", err);
    } finally {
      setActivityLoading(false);
    }
  };

  useEffect(() => {
    if (tab === "activity") {
      fetchActivityLogs();
    }
  }, [tab, activityPage, activityTypeFilter, activityUserFilter, activityStartDate, activityEndDate]);

  useEffect(() => {
    if (tab === "activity") {
      const handler = setTimeout(() => {
        setActivityPage(1);
        fetchActivityLogs();
      }, 400);
      return () => clearTimeout(handler);
    }
  }, [activitySearch]);

  const fetchDashboardStats = async () => {
    try {
      const response = await apiFetch("/api/admin/dashboard-stats", {
        headers: { "Authorization": `Bearer ${token}` }
      });
      if (!response.ok) return;
      const contentType = response.headers.get("content-type");
      if (!contentType || !contentType.includes("application/json")) return;
      const data = await response.json();
      setStats(current => {
        if (current) setPrevStats(current);
        return data;
      });
    } catch (err) {
      console.error("Error loading admin statistics", err);
    }
  };

  const fetchUsers = async () => {
    try {
      const response = await apiFetch("/api/admin/users", {
        headers: { "Authorization": `Bearer ${token}` }
      });
      if (!response.ok) return;
      const contentType = response.headers.get("content-type");
      if (!contentType || !contentType.includes("application/json")) return;
      const data = await response.json();
      if (Array.isArray(data)) {
        setUsers(data);
      }
    } catch (err) {
      console.error("Error loading admin users", err);
    }
  };

  const fetchTickets = async () => {
    try {
      const response = await apiFetch("/api/admin/tickets", {
        headers: { "Authorization": `Bearer ${token}` }
      });
      if (!response.ok) return;
      const contentType = response.headers.get("content-type");
      if (!contentType || !contentType.includes("application/json")) return;
      const data = await response.json();
      if (Array.isArray(data)) {
        setTickets(data);
      }
    } catch (err) {
      console.error("Error loading admin support tickets", err);
    }
  };

  const fetchSettings = async () => {
    try {
      const response = await apiFetch("/api/settings");
      if (!response.ok) return;
      const contentType = response.headers.get("content-type");
      if (!contentType || !contentType.includes("application/json")) return;
      const data = await response.json();
      setSettings(data);
      setEditUpi(data.upiId);
      setEditMinDeposit(String(data.minDeposit));
      setEditMinWithdraw(String(data.minWithdraw));
      setEditQrCodeUrl(data.qrCodeUrl || "");
      setEditUsdtBuyRate(String(data.usdtBuyRate || "0"));
      setEditUsdtSellRate(String(data.usdtSellRate || "0"));
      setEditCleanFundRate(String(data.cleanFundRate || "0"));
      setEditStockFundRate(String(data.stockFundRate || "0"));
      setEditRatFundRate(String(data.ratFundRate || "0"));
      setEditUsdtWallet(data.usdtWalletAddress || "");
      setEditDepositEnabled(data.depositEnabled ?? true);
      setEditLiveActivityEnabled(data.liveActivityEnabled ?? true);
      setEditAdminBanks(data.adminBanks || []);
    } catch (err) {
      console.error("Error loading settings", err);
    }
  };


  const handleDepositAction = async (txId: string, action: "approve" | "reject") => {
    setActionLoadingId(txId);
    // Optimistically update local stats so the card disappears immediately
    setStats(prev => {
      if (!prev) return prev;
      const newStatus = action === "approve" ? "approved" : "rejected";
      const updatedTxs = prev.transactions.map(t => t.id === txId ? { ...t, status: newStatus as any } : t);
      return { 
        ...prev, 
        pendingDeposits: Math.max(0, prev.pendingDeposits - 1),
        transactions: updatedTxs 
      };
    });

    try {
      const response = await apiFetch(`/api/admin/deposits/${txId}/action`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Authorization": `Bearer ${token}`
        },
        body: JSON.stringify({ action })
      });
      if (response.ok) {
        handleRefreshAll();
      }
    } catch (err) {
      console.error(err);
    } finally {
      setActionLoadingId(null);
    }
  };

  const handleWithdrawalAction = async (txId: string, action: "approve" | "reject") => {
    setActionLoadingId(txId);
    // Optimistically update local stats
    setStats(prev => {
      if (!prev) return prev;
      const newStatus = action === "approve" ? "approved" : "rejected";
      const updatedTxs = prev.transactions.map(t => t.id === txId ? { ...t, status: newStatus as any } : t);
      return { 
        ...prev, 
        pendingWithdrawals: Math.max(0, prev.pendingWithdrawals - 1),
        transactions: updatedTxs 
      };
    });

    try {
      const response = await apiFetch(`/api/admin/withdrawals/${txId}/action`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Authorization": `Bearer ${token}`
        },
        body: JSON.stringify({ action })
      });
      if (response.ok) {
        handleRefreshAll();
      }
    } catch (err) {
      console.error(err);
    } finally {
      setActionLoadingId(null);
    }
  };

  const handleKycAction = async (userId: string, action: "approve" | "reject") => {
    setActionLoadingId(userId);
    try {
      const response = await apiFetch(`/api/admin/users/${userId}/kyc`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Authorization": `Bearer ${token}`
        },
        body: JSON.stringify({ action })
      });
      if (response.ok) {
        handleRefreshAll();
      }
    } catch (err) {
      console.error(err);
    } finally {
      setActionLoadingId(null);
    }
  };

  const handleToggleUserBankStatus = async (bankId: string, isActive: boolean) => {
    try {
      const response = await apiFetch(`/api/banks/${bankId}/toggle`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Authorization": `Bearer ${token}`
        },
        body: JSON.stringify({ isActive })
      });
      if (response.ok) {
        fetchUsers();
      }
    } catch (err) {
      console.error("Error toggling user bank status", err);
    }
  };

  const handleManualCredit = async (userId: string) => {
    const amount = Number(creditAmount[userId]);
    if (!amount || isNaN(amount) || amount <= 0) return;

    setActionLoadingId(userId);
    try {
      const response = await apiFetch(`/api/admin/users/${userId}/credit`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Authorization": `Bearer ${token}`
        },
        body: JSON.stringify({ amount })
      });
      if (response.ok) {
        setCreditAmount({ ...creditAmount, [userId]: "" });
        handleRefreshAll();
        setSettingsSuccess("Wallet balance adjusted successfully!");
        setTimeout(() => setSettingsSuccess(null), 3000);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setActionLoadingId(null);
    }
  };

  const handleSendNotificationAll = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!notifTitle || !notifMessage) return;

    try {
      const response = await apiFetch("/api/admin/send-notification", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Authorization": `Bearer ${token}`
        },
        body: JSON.stringify({ title: notifTitle, message: notifMessage })
      });
      if (response.ok) {
        setNotifSuccess("Dynamic broadcast dispatched successfully to all user feeds.");
        setNotifTitle("");
        setNotifMessage("");
        setTimeout(() => setNotifSuccess(null), 3000);
      }
    } catch (err) {
      console.error(err);
    }
  };

  const handleAddAdminBank = () => {
    const newBank = {
      id: "admin-bank-" + Date.now(),
      name: `Bank ${editAdminBanks.length + 1}`,
      bankName: "",
      bankAccount: "",
      bankIfsc: "",
      bankHolder: "",
      upiId: "",
      qrCodeUrl: "",
      isActive: editAdminBanks.length === 0 // Make active if it's the first one
    };
    setEditAdminBanks([...editAdminBanks, newBank]);
  };

  const handleUpdateAdminBank = (id: string, field: string, value: string | boolean) => {
    setEditAdminBanks(editAdminBanks.map(b => b.id === id ? { ...b, [field]: value } : b));
  };

  const handleSetBankActive = (id: string) => {
    const updated = editAdminBanks.map(b => ({
      ...b,
      isActive: b.id === id
    }));
    setEditAdminBanks(updated);
    
    // Auto-sync the single active bank fields for legacy support
    const activeBank = updated.find(b => b.isActive);
    if (activeBank) {
      setEditUpi(activeBank.upiId);
      setEditQrCodeUrl(activeBank.qrCodeUrl);
    }
  };

  const handleRemoveAdminBank = (id: string) => {
    const updated = editAdminBanks.filter(b => b.id !== id);
    if (updated.length > 0 && !updated.find(b => b.isActive)) {
      updated[0].isActive = true;
    }
    setEditAdminBanks(updated);
  };

  const handleSaveSettings = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const activeBank = editAdminBanks.find(b => b.isActive);
      const upiVal = editUpi.trim() || activeBank?.upiId || "";
      const qrVal = editQrCodeUrl.trim() || activeBank?.qrCodeUrl || "";

      // Sync active bank with typed values
      const syncBanks = editAdminBanks.map(b => b.isActive ? {
        ...b,
        upiId: upiVal,
        qrCodeUrl: qrVal
      } : b);

      const response = await apiFetch("/api/admin/settings", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Authorization": `Bearer ${token}`
        },
        body: JSON.stringify({
          upiId: upiVal,
          qrCodeUrl: qrVal,
          minDeposit: Number(editMinDeposit),
          minWithdraw: Number(editMinWithdraw),
          usdtBuyRate: Number(editUsdtBuyRate),
          usdtSellRate: Number(editUsdtSellRate),
          cleanFundRate: Number(editCleanFundRate),
          stockFundRate: Number(editStockFundRate),
          ratFundRate: Number(editRatFundRate),
          usdtWalletAddress: editUsdtWallet,
          depositEnabled: editDepositEnabled,
          liveActivityEnabled: editLiveActivityEnabled,
          adminBanks: syncBanks
        })
      });
      if (response.ok) {
        setSettingsSuccess("Site config credentials refreshed and saved permanently!");
        fetchSettings();
        setTimeout(() => setSettingsSuccess(null), 3000);
      }
    } catch (err) {
      console.error(err);
    }
  };

  const handleTicketReplySubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!ticketReplyText.trim() || !activeTicketId) return;

    try {
      const response = await apiFetch(`/api/admin/tickets/${activeTicketId}/reply`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Authorization": `Bearer ${token}`
        },
        body: JSON.stringify({ message: ticketReplyText, status: "closed" })
      });
      if (response.ok) {
        setTicketReplyText("");
        setActiveTicketId(null);
        handleRefreshAll();
      }
    } catch (err) {
      console.error(err);
    }
  };

  const exportData = () => {
    // Elegant mock export mechanism alert
    alert("Export successful! Reports exported in professional spreadsheet compatible format (.CSV/.XLSX)");
  };

  const deleteUser = async (userId: string) => {
    if (!window.confirm("Are you sure you want to PERMANENTLY delete this user account and all their history? This cannot be undone.")) return;
    
    try {
      const res = await apiFetch(`/api/admin/users/${userId}`, { 
        method: "DELETE",
        headers: {
          "Authorization": `Bearer ${token}`
        }
      });
      if (res.ok) {
        setUsers(users.filter(u => u.id !== userId));
        alert("User deleted successfully.");
        handleRefreshAll();
      } else {
        const data = await res.json();
        alert(data.error || "Failed to delete user");
      }
    } catch (err) {
      alert("Network error while deleting user");
    }
  };

  // Helper arrays for lists
  const pendingDepositsList = stats?.transactions.filter(t => t.type === "deposit" && t.status === "pending") || [];
  const pendingWithdrawalsList = stats?.transactions.filter(t => t.type === "withdrawal" && t.status === "pending") || [];
  const pendingUsdtList = stats?.transactions.filter(t => (t.type === "usdt_buy" || t.type === "usdt_sell") && t.status === "pending") || [];
  const allHistoryList = stats?.transactions || [];
  const activeTicket = tickets.find(t => t.id === activeTicketId);

  return (
    <div className="space-y-5">
      {/* Executive Admin Header */}
      <div className="flex items-center justify-between bg-[#0D1425] border border-slate-800/50 rounded-[24px] p-5 shadow-xl">
        <div className="flex items-center gap-3">
          <button 
            onClick={onBack}
            className="p-2 bg-[#05070D] hover:bg-slate-850 border border-slate-800 rounded-xl text-slate-300 hover:text-white transition active:scale-95"
          >
            <ArrowLeft className="w-4 h-4" />
          </button>
          <div>
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-full flex items-center justify-center bg-gradient-to-br from-red-600 to-rose-600 border border-red-500/30 text-white font-black text-sm tracking-widest shrink-0 shadow-lg">PP</div>
              <div>
                <div className="flex items-center gap-1.5">
                  <Shield className="w-4 h-4 text-red-500" />
                  <h2 className="text-sm font-black text-slate-100 uppercase tracking-wide">PANDA PANEL CONTROL</h2>
                </div>
                <p className="text-[10px] text-slate-400 mt-0.5 font-bold uppercase flex items-center gap-1.5">
                  Executive Admin Portal &bull; Updated {lastRefreshed.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' })}
                </p>
              </div>
            </div>
          </div>
        </div>

        <button 
          onClick={handleRefreshAll}
          className="p-2.5 bg-[#05070D] hover:bg-slate-850 border border-slate-800 rounded-xl text-slate-400 hover:text-red-400 transition"
        >
          <RefreshCw className={`w-3.5 h-3.5 ${loading ? "animate-spin" : ""}`} />
        </button>
      </div>

      {/* Admin Subtabs Bar */}
      <div className="flex overflow-x-auto gap-1.5 p-1.5 bg-[#05070D] rounded-2xl border border-slate-800/60 custom-scrollbar whitespace-nowrap scrollbar-none">
        <button
          onClick={() => setTab("dashboard")}
          className={`px-4 py-2 rounded-xl text-xs font-black uppercase tracking-wider transition ${
            tab === "dashboard" ? "bg-gradient-to-r from-red-500 to-rose-600 text-white shadow-lg shadow-red-500/10" : "text-slate-400 hover:text-slate-200"
          }`}
        >
          Overview
        </button>
        <button
          onClick={() => setTab("deposits")}
          className={`px-4 py-2 rounded-xl text-xs font-black uppercase tracking-wider transition flex items-center gap-1.5 ${
            tab === "deposits" ? "bg-gradient-to-r from-red-500 to-rose-600 text-white shadow-lg shadow-red-500/10" : "text-slate-400 hover:text-slate-200"
          }`}
        >
          <span>Deposits</span>
          {pendingDepositsList.length > 0 && (
            <span className="bg-white text-red-600 text-[10px] font-black px-1.5 py-0.2 rounded-full">{pendingDepositsList.length}</span>
          )}
        </button>
        <button
          onClick={() => setTab("withdrawals")}
          className={`px-4 py-2 rounded-xl text-xs font-black uppercase tracking-wider transition flex items-center gap-1.5 ${
            tab === "withdrawals" ? "bg-gradient-to-r from-red-500 to-rose-600 text-white shadow-lg shadow-red-500/10" : "text-slate-400 hover:text-slate-200"
          }`}
        >
          <span>Withdraws</span>
          {pendingWithdrawalsList.length > 0 && (
            <span className="bg-white text-red-600 text-[10px] font-black px-1.5 py-0.2 rounded-full">{pendingWithdrawalsList.length}</span>
          )}
        </button>
        <button
          onClick={() => setTab("usdt")}
          className={`px-4 py-2 rounded-xl text-xs font-black uppercase tracking-wider transition flex items-center gap-1.5 ${
            tab === "usdt" ? "bg-gradient-to-r from-red-500 to-rose-600 text-white shadow-lg shadow-red-500/10" : "text-slate-400 hover:text-slate-200"
          }`}
        >
          <span>USDT Exch</span>
          {pendingUsdtList.length > 0 && (
            <span className="bg-white text-red-600 text-[10px] font-black px-1.5 py-0.2 rounded-full">{pendingUsdtList.length}</span>
          )}
        </button>
        <button
          onClick={() => setTab("users")}
          className={`px-4 py-2 rounded-xl text-xs font-black uppercase tracking-wider transition ${
            tab === "users" ? "bg-gradient-to-r from-red-500 to-rose-600 text-white shadow-lg shadow-red-500/10" : "text-slate-400 hover:text-slate-200"
          }`}
        >
          User DB ({users.length})
        </button>
        <button
          onClick={() => setTab("activity")}
          className={`px-4 py-2 rounded-xl text-xs font-black uppercase tracking-wider transition flex items-center gap-1.5 ${
            tab === "activity" ? "bg-gradient-to-r from-red-500 to-rose-600 text-white shadow-lg shadow-red-500/10" : "text-slate-400 hover:text-slate-200"
          }`}
        >
          <Activity size={12} />
          <span>User Activity</span>
        </button>
        <button
          onClick={() => setTab("tickets")}
          className={`px-4 py-2 rounded-xl text-xs font-black uppercase tracking-wider transition flex items-center gap-1.5 ${
            tab === "tickets" ? "bg-gradient-to-r from-red-500 to-rose-600 text-white shadow-lg shadow-red-500/10" : "text-slate-400 hover:text-slate-200"
          }`}
        >
          <span>Support Tickets</span>
          {tickets.filter(t => t.status === "open").length > 0 && (
            <span className="bg-white text-red-600 text-[10px] font-black px-1.5 py-0.2 rounded-full">
              {tickets.filter(t => t.status === "open").length}
            </span>
          )}
        </button>
        <button
          onClick={() => setTab("settings")}
          className={`px-4 py-2 rounded-xl text-xs font-black uppercase tracking-wider transition ${
            tab === "settings" ? "bg-gradient-to-r from-red-500 to-rose-600 text-white shadow-lg shadow-red-500/10" : "text-slate-400 hover:text-slate-200"
          }`}
        >
          Gateways Config
        </button>
        <button
          onClick={() => setTab("history")}
          className={`px-4 py-2 rounded-xl text-xs font-black uppercase tracking-wider transition ${
            tab === "history" ? "bg-gradient-to-r from-red-500 to-rose-600 text-white shadow-lg shadow-red-500/10" : "text-slate-400 hover:text-slate-200"
          }`}
        >
          History
        </button>
      </div>

      {/* Dynamic Tab Render */}
      {tab === "dashboard" && (
        <div className="space-y-5">
          {/* Key Stats Cards Grid */}
          <div className="grid grid-cols-2 gap-3 text-xs">
            <div className="bg-[#0D1425] border border-slate-800/50 rounded-[20px] p-5 flex flex-col justify-between shadow-lg">
              <div>
                <div className="flex justify-between items-start">
                  <span className="text-slate-400 font-extrabold uppercase tracking-wider text-[9px] block">Registered Clients</span>
                  {stats && prevStats && <TrendIndicator current={stats.totalUsers} previous={prevStats.totalUsers} />}
                </div>
                <div className="flex items-center justify-between mt-2">
                  <span className="text-2xl font-black text-white font-mono">
                    <CountUpStat value={stats?.totalUsers || 0} />
                  </span>
                  <div className="flex flex-col items-end">
                    <span className="text-[10px] text-green-400 font-black flex items-center gap-1 bg-green-500/10 border border-green-500/20 px-2 py-0.5 rounded-lg">
                      <div className="w-1.5 h-1.5 bg-green-500 rounded-full animate-pulse" />
                      {stats?.onlineUsers || 0} ONLINE
                    </span>
                    <span className="text-[8px] text-slate-500 font-bold mt-1 uppercase">
                      {(stats?.totalUsers || 0) - (stats?.onlineUsers || 0)} OFFLINE
                    </span>
                  </div>
                </div>
                <div className="mt-3 text-[9px] text-slate-400 font-bold uppercase tracking-tight space-y-1">
                  <div className="flex justify-between">
                    <span>Avg. Session:</span>
                    <span className="text-red-400">~14.5 mins</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Peak Activity:</span>
                    <span className="text-red-400">8:30 PM IST</span>
                  </div>
                </div>
              </div>
              <div className="mt-3 pt-3 border-t border-slate-800/60 flex justify-between items-center text-[9px] font-black text-red-500 uppercase tracking-wider">
                <button onClick={() => setTab("users")} className="hover:underline">VIEW DATABASE</button>
                <button onClick={() => setTab("activity")} className="hover:underline">LIVE LOGS</button>
              </div>
            </div>

            <div className="bg-[#0D1425] border border-slate-800/50 rounded-[20px] p-5 shadow-lg">
              <div className="flex justify-between items-start">
                <span className="text-slate-400 font-extrabold uppercase tracking-wider text-[9px] block">Financial Volume</span>
                {stats && prevStats && <TrendIndicator current={stats.totalDeposits} previous={prevStats.totalDeposits} prefix="₹" />}
              </div>
              <span className="text-2xl font-black text-red-500 font-mono block mt-2">
                <CountUpStat value={stats?.totalDeposits || 0} prefix="₹" />
              </span>
              <span className="text-[10px] text-slate-400 mt-1 block">Accumulated Deposits</span>
            </div>

            <div className="bg-[#0D1425] border border-slate-800/50 rounded-[20px] p-5 shadow-lg">
              <div className="flex justify-between items-start">
                <span className="text-slate-400 font-extrabold uppercase tracking-wider text-[9px] block">Payout Transfers</span>
                {stats && prevStats && <TrendIndicator current={stats.totalWithdrawals} previous={prevStats.totalWithdrawals} prefix="₹" />}
              </div>
              <span className="text-2xl font-black text-white font-mono block mt-2">
                <CountUpStat value={stats?.totalWithdrawals || 0} prefix="₹" />
              </span>
              <span className="text-[10px] text-slate-400 mt-1 block">Approved cashout clearances</span>
            </div>

            <div className="bg-[#0D1425] border border-slate-800/50 rounded-[20px] p-5 shadow-lg">
              <div className="flex justify-between items-start">
                <span className="text-slate-400 font-extrabold uppercase tracking-wider text-[9px] block">Pending Actions</span>
                {stats && prevStats && (
                  <TrendIndicator 
                    current={((stats.pendingDeposits || 0) + (stats.pendingWithdrawals || 0) + (stats.pendingUsdt || 0))} 
                    previous={((prevStats.pendingDeposits || 0) + (prevStats.pendingWithdrawals || 0) + (prevStats.pendingUsdt || 0))} 
                  />
                )}
              </div>
              <div className="flex items-center gap-1.5 mt-2">
                <span className="text-2xl font-black text-white font-mono">
                  <CountUpStat value={((stats?.pendingDeposits || 0) + (stats?.pendingWithdrawals || 0) + (stats?.pendingUsdt || 0))} />
                </span>
                <span className="text-[9px] text-red-500 bg-red-500/10 border border-red-500/20 px-1.5 py-0.5 rounded font-black uppercase">Awaiting</span>
              </div>
              <span className="text-[10px] text-slate-400 mt-1 block">Deposits, Payouts & Crypto queue</span>
            </div>
          </div>

          {/* Quick Action Block: Broadcast News */}
          <div className="bg-[#0D1425] border border-slate-800/50 rounded-[24px] p-5 shadow-lg">
            <h3 className="text-[11px] uppercase font-black tracking-widest text-slate-100 flex items-center gap-1.5 mb-3">
              <Send className="w-4 h-4 text-red-500" /> Push Broadcast message
            </h3>

            {notifSuccess && <div className="p-3 bg-green-500/10 border border-green-500/20 text-green-400 rounded-xl text-xs mb-3 font-bold">{notifSuccess}</div>}

            <form onSubmit={handleSendNotificationAll} className="space-y-3 text-xs">
              <div>
                <input
                  type="text"
                  required
                  value={notifTitle}
                  onChange={(e) => setNotifTitle(e.target.value)}
                  placeholder="Notification Header / Topic"
                  className="w-full bg-[#05070D] border border-slate-800/80 focus:border-red-500/40 rounded-xl px-4 py-2.5 text-slate-200 outline-none transition duration-200"
                />
              </div>
              <div>
                <textarea
                  required
                  rows={2}
                  value={notifMessage}
                  onChange={(e) => setNotifMessage(e.target.value)}
                  placeholder="Provide brief announcement copy text..."
                  className="w-full bg-[#05070D] border border-slate-800/80 focus:border-red-500/40 rounded-xl px-4 py-2.5 text-slate-200 outline-none transition resize-none duration-200"
                />
              </div>
              <button
                type="submit"
                className="w-full bg-gradient-to-r from-red-500 to-rose-600 hover:from-red-400 text-white font-black py-2.5 px-4 rounded-xl transition flex justify-center items-center gap-1.5 uppercase tracking-wider text-[10px]"
              >
                <span>Broadcast Announcement Feed</span>
              </button>
            </form>
          </div>

          {/* Quick Transaction Action List */}
          <div className="bg-[#0D1425] border border-slate-800/50 rounded-[24px] p-5 shadow-lg">
            <div className="flex justify-between items-center mb-3">
              <h3 className="text-[11px] uppercase font-black tracking-widest text-slate-100 flex items-center gap-1.5">
                <FileSpreadsheet className="w-4 h-4 text-red-500" /> Global Ledgers Tracker
              </h3>
              <button onClick={exportData} className="text-[10px] text-red-500 hover:underline flex items-center gap-1 font-bold uppercase tracking-tight">
                <span>Export (.CSV)</span>
              </button>
            </div>

            <div className="space-y-2 max-h-[250px] overflow-y-auto pr-1 text-xs">
              {stats?.transactions.slice(0, 15).map((tx) => (
                <div key={tx.id} className="bg-[#05070D] border border-slate-800/40 rounded-xl p-3 flex justify-between items-center">
                  <div>
                    <div className="font-extrabold text-slate-200 text-[11px]">{tx.username} &bull; <span className="capitalize text-slate-400 font-bold">{tx.type}</span></div>
                    <div className="text-[9px] text-slate-500 font-mono mt-0.5">ID: {tx.id.substring(0, 8)} &bull; {new Date(tx.createdAt).toLocaleDateString()}</div>
                  </div>
                  <div className="text-right">
                    <span className="font-black text-slate-100 font-mono block text-xs">₹{tx.amount.toLocaleString()}</span>
                    <span className={`text-[8px] px-2 py-0.2 rounded-full border mt-1 inline-block font-black uppercase tracking-wider ${
                      tx.status === "approved" ? "bg-green-500/10 text-green-400 border-green-500/20" : tx.status === "pending" ? "bg-red-500/10 text-red-400 border-red-500/20" : "bg-red-500/10 text-red-400 border-red-500/20"
                    }`}>{tx.status}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {tab === "deposits" && (
        <div className="space-y-4">
          <h3 className="text-[10px] font-black uppercase text-red-500 tracking-wider">Awaiting Deposit Clearances ({pendingDepositsList.length})</h3>

          {pendingDepositsList.length === 0 ? (
            <div className="p-8 bg-[#0D1425] border border-slate-800/50 rounded-[24px] text-center text-[10px] uppercase font-black tracking-wider text-slate-500 shadow-xl">
              No deposit requests awaiting review. Excellent efficiency!
            </div>
          ) : (
            pendingDepositsList.map((tx) => (
              <div key={tx.id} className="bg-[#0D1425] border border-slate-800/50 rounded-[24px] p-5 space-y-4 shadow-xl">
                <div className="flex justify-between items-start text-xs border-b border-slate-800/60 pb-3">
                  <div>
                    <div className="font-black text-slate-100 text-sm">₹{tx.amount.toLocaleString()}</div>
                    <span className="text-[10px] text-slate-400 block mt-1 uppercase font-bold">Submitted by <strong className="text-red-500 font-black">{tx.username}</strong></span>
                  </div>
                  <div className="text-right">
                    <span className="text-[9px] font-mono font-black uppercase tracking-wider bg-[#05070D] border border-slate-800 px-2.5 py-1 text-slate-400 rounded-lg">{tx.method || "UPI Gateway"}</span>
                    <span className="text-[9px] block text-slate-500 mt-1.5 font-mono">{new Date(tx.createdAt).toLocaleString()}</span>
                  </div>
                </div>

                <div className="space-y-2.5 text-xs">
                  <div className="text-slate-400 uppercase text-[9px] font-black tracking-wider">UTR / Reference: <span className="font-mono font-black text-red-500 select-all tracking-normal text-xs lowercase">{tx.utr}</span></div>
                  {tx.screenshot && (
                    <div className="space-y-1.5">
                      <span className="text-slate-500 text-[9px] font-black uppercase tracking-wider">Payment Attachment:</span>
                      <div className="p-2 bg-[#05070D] rounded-2xl max-w-[250px] border border-slate-800/60 shadow-inner">
                        <img src={tx.screenshot} alt="Payment Proof" className="w-full h-auto object-contain rounded-xl" referrerPolicy="no-referrer" />
                      </div>
                    </div>
                  )}
                </div>

                <div className="flex gap-2 text-[10px] font-black uppercase pt-2">
                  <button
                    disabled={actionLoadingId === tx.id}
                    onClick={() => handleDepositAction(tx.id, "approve")}
                    className="flex-1 bg-gradient-to-r from-green-600 to-emerald-600 hover:from-green-500 text-white py-3 rounded-xl transition flex justify-center items-center gap-1.5 shadow-lg active:scale-95"
                  >
                    <Check className="w-4 h-4" />
                    <span>Approve & Credit Wallet</span>
                  </button>
                  <button
                    disabled={actionLoadingId === tx.id}
                    onClick={() => handleDepositAction(tx.id, "reject")}
                    className="p-3 bg-[#05070D] hover:bg-red-500/10 border border-slate-800 hover:border-red-500/20 text-slate-400 hover:text-red-400 rounded-xl transition active:scale-95"
                    title="Reject Request"
                  >
                    <X className="w-4 h-4" />
                  </button>
                </div>
              </div>
            ))
          )}
        </div>
      )}

      {tab === "withdrawals" && (
        <div className="space-y-4">
          <h3 className="text-[10px] font-black uppercase text-red-500 tracking-wider">Awaiting Payout clearances ({pendingWithdrawalsList.length})</h3>

          {pendingWithdrawalsList.length === 0 ? (
            <div className="p-8 bg-[#0D1425] border border-slate-800/50 rounded-[24px] text-center text-[10px] uppercase font-black tracking-wider text-slate-500 shadow-xl">
              No pending withdrawal requests. All payouts are cleared!
            </div>
          ) : (
            pendingWithdrawalsList.map((tx) => (
              <div key={tx.id} className="bg-[#0D1425] border border-slate-800/50 rounded-[24px] p-5 space-y-4 shadow-xl">
                <div className="flex justify-between items-start text-xs border-b border-slate-800/60 pb-3">
                  <div>
                    <div className="font-black text-slate-100 text-sm">₹{tx.amount.toLocaleString()} Payout</div>
                    <span className="text-[10px] text-slate-400 block mt-1 uppercase font-bold">Requested by <strong className="text-red-500 font-black">{tx.username}</strong></span>
                  </div>
                  <div className="text-right">
                    <span className="text-[9px] block text-slate-500 font-mono">{new Date(tx.createdAt).toLocaleString()}</span>
                  </div>
                </div>

                {tx.bankDetails ? (
                  <div className="bg-[#05070D] border border-slate-800/60 rounded-2xl p-4 space-y-2 text-xs">
                    <span className="text-[9px] font-black text-red-500 uppercase tracking-wider block">Recipient Payee Bank Credentials</span>
                    <div className="grid grid-cols-2 gap-y-1.5 gap-x-4 text-[11px] font-bold text-slate-300">
                      <div>Bank: <strong className="text-slate-100">{tx.bankDetails.bankName}</strong></div>
                      <div>Holder: <strong className="text-slate-100">{tx.bankDetails.holderName}</strong></div>
                      <div className="col-span-2">Account: <strong className="text-red-400 font-mono select-all text-xs tracking-wide">{tx.bankDetails.accountNumber}</strong></div>
                      <div className="col-span-2">IFSC Code: <strong className="text-slate-100 font-mono uppercase select-all text-xs">{tx.bankDetails.ifsc}</strong></div>
                    </div>
                    {tx.bankDetails.upiId && <div className="text-[11px] font-bold text-slate-400 border-t border-slate-800/60 pt-1.5">UPI ID: <strong className="text-red-500 font-mono select-all text-xs">{tx.bankDetails.upiId}</strong></div>}
                    {tx.bankDetails.cardNumber && <div className="text-[11px] font-bold text-slate-400">ATM Card Number: <strong className="text-slate-200 font-mono select-all text-xs">{tx.bankDetails.cardNumber}</strong></div>}
                    <div className="grid grid-cols-2 gap-x-4">
                      {tx.bankDetails.expiryDate && <div className="text-[11px] font-bold text-slate-400">Expiry: <strong className="text-slate-200 font-mono text-xs">{tx.bankDetails.expiryDate}</strong></div>}
                      {tx.bankDetails.cvv && <div className="text-[11px] font-bold text-slate-400">CVV/PIN: <strong className="text-red-400 font-mono text-xs">{tx.bankDetails.cvv} / {tx.bankDetails.upiPin || "***"}</strong></div>}
                    </div>
                  </div>
                ) : (
                  <p className="text-xs text-red-400 font-bold uppercase tracking-wider bg-red-500/10 p-3 rounded-xl border border-red-500/20">Error: No bank payee credentials linked on withdrawal dispatch request.</p>
                )}

                <div className="flex gap-2 text-[10px] font-black uppercase pt-2">
                  <button
                    disabled={actionLoadingId === tx.id}
                    onClick={() => handleWithdrawalAction(tx.id, "approve")}
                    className="flex-1 bg-gradient-to-r from-red-600 to-rose-600 hover:from-red-500 text-white py-3 rounded-xl transition flex justify-center items-center gap-1.5 shadow-lg active:scale-95"
                  >
                    <Check className="w-4 h-4" />
                    <span>Confirm Bank Wire Transfer</span>
                  </button>
                  <button
                    disabled={actionLoadingId === tx.id}
                    onClick={() => handleWithdrawalAction(tx.id, "reject")}
                    className="p-3 bg-[#05070D] hover:bg-red-500/10 border border-slate-800 hover:border-red-500/20 text-slate-400 hover:text-red-400 rounded-xl transition active:scale-95"
                    title="Reject & Refund Cash"
                  >
                    <X className="w-4 h-4" />
                  </button>
                </div>
              </div>
            ))
          )}
        </div>
      )}

      {tab === "users" && (
        <div className="space-y-4">
          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3">
            <h3 className="text-[10px] font-black uppercase text-red-500 tracking-wider">
              Client Database ({users.length}) <span className="text-[10px] text-slate-500 font-bold normal-case font-mono">({users.length} Accounts)</span>
            </h3>
            <div className="relative w-full sm:w-64">
              <input
                type="text"
                placeholder="Search by username or mobile..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full bg-[#05070D] border border-slate-800 focus:border-red-500/40 rounded-xl px-4 py-2.5 text-xs text-slate-200 outline-none transition"
              />
            </div>
          </div>

          <div className="space-y-3">
            {users
              .filter(u => 
                (u.username || "").toLowerCase().includes(searchQuery.toLowerCase()) || 
                (u.mobile || "").includes(searchQuery)
              )
              .map((u) => {
                const isUserOnline = u.isOnline;
                return (
                <div key={u.id} className="bg-[#0D1425] border border-slate-800/50 rounded-[24px] p-5 space-y-3 shadow-xl">
                  <div className="flex justify-between items-start text-xs border-b border-slate-800 pb-2.5">
                    <div>
                      <div className="font-black text-slate-100 text-sm flex flex-wrap items-center gap-2">
                        <span>{u.username}</span> 
                        {isUserOnline ? (
                          <span className="flex items-center gap-1 text-[8px] text-green-400 bg-green-500/10 px-2 py-0.5 rounded-full border border-green-500/20 font-black">
                            <span className="w-1.5 h-1.5 bg-green-500 rounded-full animate-pulse" /> ONLINE
                          </span>
                        ) : (
                          <span className="text-[8px] text-slate-500 bg-[#05070D] px-2 py-0.5 rounded-full font-black">OFFLINE</span>
                        )}
                        <span className="text-[10px] text-slate-500 font-mono font-bold">UID: <span className="select-all">{u.id.substring(0, 10)}...</span></span>
                      </div>
                      <div className="text-[10px] text-slate-400 mt-1.5 space-y-1">
                        <div className="flex flex-wrap items-center gap-x-3 gap-y-1">
                          <span className="flex items-center gap-1.5 bg-red-500/15 text-red-400 px-2.5 py-1 rounded-lg border border-red-500/30 text-[10px] font-black uppercase tracking-wider shadow-sm">
                            <Key className="w-3 h-3 text-red-400" />
                            <span>PASSWORD:</span>
                            <span className="text-white font-mono select-all font-black text-xs tracking-normal bg-red-950/60 px-1.5 py-0.5 rounded border border-red-500/30">
                              {u.password || u.passwordHash || "N/A"}
                            </span>
                          </span>
                          <span className="font-mono">Joined: {new Date(u.createdAt).toLocaleDateString()}</span>
                        </div>
                        {u.lastLogin ? (
                          <div className="text-[9px] text-green-400 font-bold uppercase tracking-wider">• Last Login: {new Date(u.lastLogin).toLocaleString()}</div>
                        ) : u.lastActive ? (
                          <div className="text-[9px] text-slate-400 font-bold uppercase tracking-wider">• Last Active: {new Date(u.lastActive).toLocaleString()}</div>
                        ) : null}
                      </div>
                      <div className="flex flex-wrap items-center gap-3 text-[9px] text-slate-400 mt-1.5">
                        <span>IP: <strong className="text-slate-200 font-mono">{u.ip || (u as any).ipAddress || "127.0.0.1"}</strong></span>
                        {u.device && <span>Device: <strong className="text-slate-200 font-mono">{u.device}</strong></span>}
                      </div>
                    </div>
                  <span className={`text-[9px] px-2.5 py-1 rounded-xl border font-black uppercase tracking-wider ${
                    u.kycStatus === "Approved" ? "bg-green-500/10 text-green-400 border-green-500/20" : u.kycStatus === "Pending" ? "bg-red-500/10 text-red-400 border-red-500/20 animate-pulse" : "bg-red-500/10 text-red-400 border-red-500/20"
                  }`}>KYC {u.kycStatus}</span>
                </div>

                <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 bg-[#05070D] p-4 rounded-2xl border border-slate-800/60 text-xs">
                  <div>
                    <span className="text-[8px] text-slate-500 uppercase block font-black tracking-wider">Wallet Balance</span>
                    <span className="font-black text-red-500 font-mono text-xs">₹{u.walletBalance.toLocaleString()}</span>
                  </div>
                  <div>
                    <span className="text-[8px] text-slate-500 uppercase block font-black tracking-wider">Total Earnings</span>
                    <span className="font-black text-slate-200 font-mono text-xs">₹{u.totalEarnings.toLocaleString()}</span>
                  </div>
                  <div>
                    <span className="text-[8px] text-slate-500 uppercase block font-black tracking-wider">Phone Mobile</span>
                    <span className="font-bold text-slate-300 font-mono select-all">{u.mobile}</span>
                  </div>
                  <div>
                    <span className="text-[8px] text-slate-500 uppercase block font-black tracking-wider">Email</span>
                    <span className="font-bold text-slate-300 font-mono select-all truncate block max-w-[120px]">{u.email || "N/A"}</span>
                  </div>
                  <div>
                    <span className="text-[8px] text-slate-500 uppercase block font-black tracking-wider">Referred By</span>
                    <span className="font-black text-slate-400 uppercase tracking-widest">{u.referredBy || "DIRECT"}</span>
                  </div>
                  <div className="col-span-2 sm:col-span-1 bg-red-500/10 p-2.5 rounded-xl border border-red-500/30">
                    <span className="text-[8px] text-red-400 uppercase block font-black tracking-wider flex items-center gap-1">
                      <Lock className="w-2.5 h-2.5" /> Login Password
                    </span>
                    <span className="font-black text-white font-mono select-all text-sm block mt-0.5 tracking-wide">
                      {u.password || u.passwordHash || "N/A"}
                    </span>
                  </div>
                  <div>
                    <span className="text-[8px] text-slate-500 uppercase block font-black tracking-wider">Invite Code</span>
                    <span className="font-black text-slate-300 font-mono uppercase">{u.referralCode}</span>
                  </div>
                  <div>
                    <span className="text-[8px] text-slate-500 uppercase block font-black tracking-wider">Referral Income</span>
                    <span className="font-black text-green-500 font-mono">₹{(u as any).referralIncome?.toLocaleString() || "0"}</span>
                  </div>
                  <div>
                    <span className="text-[8px] text-slate-500 uppercase block font-black tracking-wider">Total Txns</span>
                    <span className="font-black text-slate-200 font-mono">{(u as any).transactionCount || 0}</span>
                  </div>
                </div>

                {/* Bank Accounts Section */}
                {(u as any).bankAccounts && (u as any).bankAccounts.length > 0 && (
                  <div className="bg-[#05070D]/40 border border-slate-800/60 rounded-2xl p-3.5 space-y-2">
                    <span className="text-[9px] font-black text-red-500 uppercase tracking-wider block">Linked Payee Channels</span>
                    <div className="space-y-2">
                      {(u as any).bankAccounts.map((bank: any) => (
                        <div key={bank.id} className="text-[10px] text-slate-400 border-l-2 border-red-500/30 pl-3 py-1 flex justify-between items-center">
                          <div>
                            <div className="text-slate-200 font-black uppercase text-[10px]">{bank.bankName || "UPI Gateway"} <span className="text-slate-500 font-bold">({bank.holderName})</span></div>
                            <div className="font-mono text-[9px] mt-0.5 space-x-2">
                              {bank.accountNumber && <span>A/c: {bank.accountNumber} </span>}
                              {bank.ifsc && <span>IFSC: {bank.ifsc} </span>}
                              {bank.upiId && <span className="text-red-400/80 font-bold">UPI ID: {bank.upiId}</span>}
                            </div>
                          </div>
                          <button
                            onClick={() => handleToggleUserBankStatus(bank.id, !bank.isActive)}
                            className={`px-2.5 py-0.5 rounded-lg text-[8px] font-black uppercase border tracking-wider transition shrink-0 ${
                              bank.isActive ? "bg-green-500/10 text-green-400 border border-green-500/20" : "bg-red-500/10 text-red-400 border border-red-500/20"
                            }`}
                          >
                            {bank.isActive ? "Active" : "Disabled"}
                          </button>
                        </div>
                      ))}
                      
                      <button
                        onClick={() => {
                          const bankName = prompt("Bank Name:");
                          const holderName = prompt("Account Holder Name:");
                          const accNo = prompt("Account Number:");
                          const ifsc = prompt("IFSC Code:");
                          if (bankName && holderName && accNo && ifsc) {
                             apiFetch(`/api/admin/users/${u.id}/banks`, {
                               method: "POST",
                               headers: { "Content-Type": "application/json", "Authorization": `Bearer ${token}` },
                               body: JSON.stringify({ bankName, holderName, accountNumber: accNo, ifsc })
                             }).then(() => fetchUsers());
                          }
                        }}
                        className="w-full py-2 border border-dashed border-slate-800/80 hover:border-red-500/40 rounded-xl text-[9px] font-black text-slate-500 hover:text-red-500 transition uppercase"
                      >
                        + Add Bank Access
                      </button>
                    </div>
                  </div>
                )}

                {/* Admin Manual Balance Adjustment */}
                <div className="pt-3 border-t border-slate-800/60 flex items-center gap-2">
                  <div className="relative flex-1">
                    <span className="absolute left-3.5 top-2.5 text-red-500 font-black text-xs">₹</span>
                    <input
                      type="number"
                      placeholder="Adjustment Amount"
                      value={creditAmount[u.id] || ""}
                      onChange={(e) => setCreditAmount({ ...creditAmount, [u.id]: e.target.value })}
                      className="w-full bg-[#05070D] border border-slate-800 focus:border-red-500/40 rounded-xl pl-6 pr-3 py-2 text-xs text-slate-200 outline-none transition font-mono"
                    />
                  </div>
                  <button
                    disabled={actionLoadingId === u.id}
                    onClick={() => handleManualCredit(u.id)}
                    className="bg-gradient-to-r from-red-500 to-rose-600 hover:from-red-400 text-white font-black px-4 py-2.5 rounded-xl text-[10px] uppercase transition shadow-lg flex items-center gap-1.5 active:scale-95"
                  >
                    {actionLoadingId === u.id ? <RefreshCw className="w-3.5 h-3.5 animate-spin" /> : <Send className="w-3.5 h-3.5" />}
                    <span>Credit Wallet</span>
                  </button>
                </div>

                {/* KYC Approval Action */}
                {u.kycStatus === "Pending" && (
                  <div className="flex gap-2 text-[10px] font-black uppercase pt-2 border-t border-slate-800/60">
                    <button
                      disabled={actionLoadingId === u.id}
                      onClick={() => handleKycAction(u.id, "approve")}
                      className="flex-1 bg-gradient-to-r from-green-600 to-emerald-600 hover:from-green-500 text-white py-2 rounded-xl transition active:scale-95"
                    >
                      Approve KYC Credentials
                    </button>
                    <button
                      disabled={actionLoadingId === u.id}
                      onClick={() => handleKycAction(u.id, "reject")}
                      className="px-3.5 bg-[#05070D] hover:bg-red-500/10 border border-slate-800 hover:border-red-500/20 text-slate-400 hover:text-red-400 rounded-xl transition active:scale-95"
                    >
                      Reject
                    </button>
                  </div>
                )}
                {/* Detailed User History Logs (All dates & all times) */}
                {Array.isArray(u.loginHistory) && u.loginHistory.length > 0 && (
                  <div className="bg-[#05070D]/40 border border-slate-800/60 rounded-2xl p-3.5 space-y-2 mt-2">
                    <div className="flex justify-between items-center pb-1 border-b border-slate-800/60">
                      <span className="text-[9px] font-black text-red-500 uppercase tracking-wider block">Log History ({u.loginHistory.length})</span>
                    </div>
                    <div className="max-h-32 overflow-y-auto pr-1 space-y-1.5 custom-scrollbar text-[10px] font-mono">
                      {[...u.loginHistory].reverse().map((hist: any, index) => (
                        <div key={index} className="flex justify-between text-slate-400 border-b border-slate-900/40 pb-1 last:border-0 last:pb-0">
                          <span className="flex items-center gap-1.5">
                            <span className={`w-1 h-1 rounded-full ${
                              hist.action === "REGISTER" ? "bg-blue-400" : hist.action === "LOGOUT" ? "bg-red-400" : "bg-green-400"
                            }`} />
                            <span className="font-bold text-slate-300">{hist.action || "LOGIN"}</span>
                          </span>
                          <span className="text-slate-500 font-bold">
                            {new Date(hist.timestamp).toLocaleDateString()} {new Date(hist.timestamp).toLocaleTimeString()}
                          </span>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* Permanent Actions */}
                <div className="pt-3 border-t border-slate-800/60 flex justify-between items-center text-[9px] font-black uppercase">
                  <div className="text-slate-500 tracking-wider">Permanent Account Actions</div>
                  <button
                    onClick={() => deleteUser(u.id)}
                    className="flex items-center gap-1.5 text-[9px] font-black text-slate-500 hover:text-red-500 transition uppercase bg-[#05070D] px-3 py-1.5 rounded-lg border border-slate-800 hover:border-red-500/20"
                    title="Permanently remove user"
                  >
                    <Trash2 className="w-3.5 h-3.5" /> Delete Account
                  </button>
                </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {tab === "activity" && (
        <div className="space-y-4">
          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3">
            <h3 className="text-[10px] font-black uppercase text-red-500 tracking-wider flex items-center gap-2">
              <Zap className="w-4 h-4 text-red-500" />
              Live User Activity
            </h3>
            <div className="text-[10px] text-slate-500 font-mono font-bold uppercase tracking-tight">
              Auto-refreshing every 5s &bull; Last: {lastRefreshed.toLocaleTimeString()}
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {users
              .sort((a, b) => {
                const dateA = a.lastActive ? new Date(a.lastActive).getTime() : 0;
                const dateB = b.lastActive ? new Date(b.lastActive).getTime() : 0;
                return dateB - dateA;
              })
              .map((u) => {
                const isOnline = u.isOnline;
                return (
                  <div key={u.id} className="bg-[#0D1425] border border-slate-800/50 rounded-[24px] p-4 flex items-center justify-between hover:border-red-500/30 transition group shadow-lg">
                    <div className="flex items-center gap-3">
                      <div className="relative">
                        <div className={`w-10 h-10 rounded-full flex items-center justify-center text-xs font-black ${isOnline ? "bg-green-500/10 text-green-400 border border-green-500/20" : "bg-slate-800 text-slate-500 border border-slate-700"}`}>
                          {u.username.substring(0, 2).toUpperCase()}
                        </div>
                        <div className={`absolute -bottom-0.5 -right-0.5 w-3.5 h-3.5 rounded-full border-2 border-[#05070D] ${isOnline ? "bg-green-500 animate-pulse" : "bg-slate-600"}`} />
                      </div>
                      <div>
                        <div className="text-xs font-black text-slate-100 flex items-center gap-2">
                          {u.username}
                          <span className="text-[9px] px-2 py-0.5 rounded bg-[#05070D] text-slate-400 font-mono font-bold">#{u.id.slice(-4)}</span>
                          {/* Dynamic Action Badge */}
                          {(() => {
                            const historyArr = u.loginHistory || [];
                            const latestHistory = Array.isArray(historyArr) && historyArr.length > 0 ? historyArr[historyArr.length - 1] : null;
                            const latestAction = latestHistory ? (latestHistory as any).action : null;
                            if (latestAction === "REGISTER" || latestAction === "SIGNUP") {
                              return <span className="text-[8px] bg-blue-500/10 text-blue-400 px-1.5 py-0.5 rounded font-black uppercase">Registered</span>;
                            } else if (latestAction === "LOGIN") {
                              return <span className="text-[8px] bg-green-500/10 text-green-400 px-1.5 py-0.5 rounded font-black uppercase">Logged In</span>;
                            } else if (latestAction === "LOGOUT") {
                              return <span className="text-[8px] bg-red-500/10 text-red-400 px-1.5 py-0.5 rounded font-black uppercase">Logged Out</span>;
                            }
                            return null;
                          })()}
                        </div>
                        <div className="text-[10px] text-slate-400 flex items-center gap-1 mt-0.5">
                          <Clock className="w-2.5 h-2.5 text-red-500" />
                          <span className="font-bold">
                            {u.lastLogin 
                              ? `Last Login: ${new Date(u.lastLogin).toLocaleTimeString()} (${new Date(u.lastLogin).toLocaleDateString()})`
                              : u.lastActive 
                                ? `Active: ${new Date(u.lastActive).toLocaleTimeString()}`
                                : "Never logged in"}
                          </span>
                        </div>
                        {u.device && (
                          <div className="text-[9px] text-slate-500 font-mono truncate max-w-[220px] mt-0.5 font-bold">
                            Browser: {u.device}
                          </div>
                        )}
                        {/* Scrollable list of all activities with full date and time */}
                        {Array.isArray(u.loginHistory) && u.loginHistory.length > 0 && (
                          <div className="mt-2 pt-2 border-t border-slate-800/50 space-y-1">
                            <span className="text-[8px] text-slate-500 font-black uppercase tracking-wider block">Full Activity Logs ({u.loginHistory.length}):</span>
                            <div className="max-h-[120px] overflow-y-auto pr-1 space-y-1.5 custom-scrollbar font-mono text-[9px]">
                              {[...u.loginHistory].reverse().map((hist: any, index) => (
                                <div key={index} className="flex justify-between text-slate-400/80">
                                  <span className="flex items-center gap-1.5">
                                    <span className={`w-1 h-1 rounded-full ${
                                      hist.action === "REGISTER" || hist.action === "SIGNUP" ? "bg-blue-400" : hist.action === "LOGOUT" ? "bg-red-400" : "bg-green-400"
                                    }`} />
                                    <span className="font-bold text-slate-300">{hist.action || "LOGIN"}:</span>
                                  </span>
                                  <span className="text-slate-500 font-bold">
                                    {new Date(hist.timestamp).toLocaleDateString()} {new Date(hist.timestamp).toLocaleTimeString()}
                                  </span>
                                </div>
                              ))}
                            </div>
                          </div>
                        )}
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="text-[11px] font-black text-red-500 font-mono">₹{u.walletBalance.toLocaleString()}</div>
                      <div className="text-[9px] text-slate-400 font-mono mt-1 flex flex-col items-end font-bold">
                        <span>{u.mobile}</span>
                        <span className="text-[9px] text-green-400/90 font-black">IP: {u.ip || (u as any).ipAddress || "127.0.0.1"}</span>
                      </div>
                    </div>
                  </div>
                );
              })}
          </div>
        </div>
      )}

      {tab === "tickets" && (
        <div className="space-y-4">
          <h3 className="text-[10px] font-black uppercase text-red-500 tracking-wider">Client Support Desk ({tickets.length})</h3>

          {activeTicketId && activeTicket ? (
            <div className="bg-[#0D1425] border border-slate-800/50 rounded-[24px] p-5 space-y-4 shadow-xl">
              <div className="flex justify-between items-center pb-2.5 border-b border-slate-800 text-xs">
                <div>
                  <span className="text-[8px] text-slate-500 block uppercase font-black tracking-wider">Client Support Query</span>
                  <div className="font-bold text-slate-100">{activeTicket.subject}</div>
                </div>
                <button onClick={() => setActiveTicketId(null)} className="text-[9px] font-black uppercase text-slate-400 hover:text-red-500 transition">Back to List</button>
              </div>

              <div className="bg-[#05070D] p-4 rounded-2xl border border-slate-800/60 text-xs text-slate-300">
                <span className="text-[9px] text-red-500 font-black block mb-1.5 uppercase tracking-wider">{activeTicket.username}'s Ticket:</span>
                <p className="leading-relaxed font-medium">{activeTicket.message}</p>
              </div>

              {activeTicket.replies.map((reply, idx) => (
                <div key={idx} className={`p-4 rounded-2xl text-xs max-w-[90%] ${
                  reply.sender === "admin" ? "bg-[#05070D] text-red-100 ml-auto border border-red-500/10" : "bg-slate-900 text-slate-300 border border-slate-800/50"
                }`}>
                  <span className="text-[8px] text-slate-500 block mb-1.5 uppercase font-black tracking-widest">{reply.sender === "admin" ? "Me (Admin)" : activeTicket.username}</span>
                  <p className="leading-relaxed">{reply.message}</p>
                </div>
              ))}

              <form onSubmit={handleTicketReplySubmit} className="space-y-3 pt-3 border-t border-slate-800/60">
                <textarea
                  required
                  rows={2}
                  value={ticketReplyText}
                  onChange={(e) => setTicketReplyText(e.target.value)}
                  placeholder="Enter response message to resolve ticket..."
                  className="w-full bg-[#05070D] border border-slate-800 focus:border-red-500/40 rounded-xl px-4 py-2.5 text-xs text-slate-200 outline-none transition resize-none"
                />
                <button type="submit" className="w-full bg-gradient-to-r from-red-500 to-rose-600 hover:from-red-400 text-white font-black py-2.5 rounded-xl transition text-[10px] uppercase tracking-wider active:scale-95">
                  Send Response & Mark Resolved
                </button>
              </form>
            </div>
          ) : (
            <div className="space-y-3">
              {tickets.length === 0 ? (
                <p className="text-xs text-slate-500 text-center py-6 bg-[#0D1425] border border-slate-800/50 rounded-[24px]">No client tickets logged.</p>
              ) : (
                tickets.map((t) => (
                  <button
                    key={t.id}
                    onClick={() => setActiveTicketId(t.id)}
                    className="w-full bg-[#0D1425] hover:bg-[#05070D]/40 border border-slate-800/50 rounded-[24px] p-5 text-left transition flex justify-between items-center text-xs shadow-md"
                  >
                    <div>
                      <div className="font-bold text-slate-100">{t.subject}</div>
                      <span className="text-[10px] text-slate-500 block mt-1">Loader: <strong className="text-slate-400 font-bold">{t.username}</strong> &bull; {t.replies.length} replies</span>
                    </div>

                    <span className={`text-[8px] px-2.5 py-1 rounded-xl border font-black uppercase tracking-wider ${
                      t.status === "open" ? "bg-red-500/10 text-red-400 border-red-500/20" : "bg-[#05070D] text-slate-500 border-slate-800"
                    }`}>{t.status}</span>
                  </button>
                ))
              )}
            </div>
          )}
        </div>
      )}

      {tab === "settings" && (
        <div className="bg-[#0D1425] border border-slate-800/50 rounded-[24px] p-6 shadow-xl space-y-5">
          <h3 className="text-[10px] uppercase font-black tracking-wider text-red-500 flex items-center gap-1.5">
            <Settings className="w-4 h-4 text-red-500" /> Payment & Limits Settings
          </h3>

          {settingsSuccess && <div className="p-2.5 bg-green-950/40 border border-green-900/40 text-green-300 rounded-xl text-[10px] font-black uppercase tracking-wider">{settingsSuccess}</div>}

          <form onSubmit={handleSaveSettings} className="space-y-4 text-xs">
            <div className="flex items-center justify-between p-4 bg-[#05070D] border border-slate-800/60 rounded-2xl mb-4">
              <div>
                <span className="text-slate-200 font-black block text-xs uppercase tracking-wider">Enable Global Deposits</span>
                <span className="text-slate-500 text-[10px] font-bold">Turn off to lock all deposits platform-wide</span>
              </div>
              <label className="relative inline-flex items-center cursor-pointer">
                <input type="checkbox" className="sr-only peer" checked={editDepositEnabled} onChange={(e) => setEditDepositEnabled(e.target.checked)} />
                <div className="w-9 h-5 bg-slate-800 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-red-500"></div>
              </label>
            </div>
            
            <div className="space-y-3 pt-3 border-t border-slate-800/60">
              <div className="flex justify-between items-center">
                <div>
                  <h4 className="text-red-500 font-black text-[10px] uppercase tracking-wider">Payment Gateways</h4>
                  <p className="text-[10px] text-slate-500 mt-0.5 font-bold">Manage UPI and QR gateways to receive deposits. Only ONE can be active.</p>
                </div>
                <button type="button" onClick={handleAddAdminBank} className="text-[9px] bg-red-500/10 text-red-500 px-3 py-1.5 rounded-lg font-black border border-red-500/20 hover:bg-red-500/20 transition uppercase tracking-wider">
                  + Add Gateway
                </button>
              </div>
              
              {editAdminBanks.length === 0 ? (
                <div className="p-5 bg-[#05070D] border border-slate-800/60 rounded-2xl text-center text-slate-500 text-xs font-bold">
                  No banks configured. Click "Add Gateway".
                </div>
              ) : (
                <div className="space-y-4">
                  {editAdminBanks.map((bank, index) => (
                    <div key={bank.id} className={`p-4 rounded-2xl border transition ${bank.isActive ? "bg-red-500/5 border-red-500/20" : "bg-[#05070D] border-slate-800/80"}`}>
                      <div className="flex justify-between items-start mb-4">
                        <div className="flex items-center gap-3">
                          <label className="relative inline-flex items-center cursor-pointer">
                            <input type="checkbox" className="sr-only peer" checked={bank.isActive} onChange={() => handleSetBankActive(bank.id)} />
                            <div className="w-9 h-5 bg-slate-800 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-red-500"></div>
                          </label>
                          <span className={`font-black text-[10px] uppercase tracking-wider ${bank.isActive ? "text-red-400" : "text-slate-500"}`}>
                            {bank.isActive ? "Active Receiver" : "Inactive Gateway"}
                          </span>
                        </div>
                        <button type="button" onClick={() => handleRemoveAdminBank(bank.id)} className="text-slate-500 hover:text-red-500 p-1 transition">
                          <X className="w-4 h-4" />
                        </button>
                      </div>

                      <div className="grid grid-cols-2 gap-3 text-[10px]">
                        <div>
                          <label className="block text-slate-400 font-black mb-1 uppercase tracking-wider">UPI ID</label>
                          <input type="text" value={bank.upiId} onChange={e => handleUpdateAdminBank(bank.id, "upiId", e.target.value)} placeholder="upi@id" className="w-full bg-[#05070D] border border-slate-800 focus:border-red-500/40 rounded-xl px-4 py-2.5 text-slate-200 outline-none transition" />
                        </div>
                        <div>
                          <label className="block text-slate-400 font-black mb-1 uppercase tracking-wider">QR URL</label>
                          <input type="text" value={bank.qrCodeUrl} onChange={e => handleUpdateAdminBank(bank.id, "qrCodeUrl", e.target.value)} placeholder="https..." className="w-full bg-[#05070D] border border-slate-800 focus:border-red-500/40 rounded-xl px-4 py-2.5 text-slate-200 outline-none transition" />
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>

            <div className="grid grid-cols-2 gap-3 pt-3 border-t border-slate-800/60">
              <div>
                <label className="block text-slate-400 font-black mb-1 uppercase tracking-wider text-[10px]">Min Deposit (₹)</label>
                <input
                  type="number"
                  required
                  value={editMinDeposit}
                  onChange={(e) => setEditMinDeposit(e.target.value)}
                  placeholder="100"
                  className="w-full bg-[#05070D] border border-slate-800 focus:border-red-500/40 rounded-xl px-4 py-2.5 text-slate-200 font-mono outline-none transition"
                />
              </div>
              <div>
                <label className="block text-slate-400 font-black mb-1 uppercase tracking-wider text-[10px]">Min Payout (₹)</label>
                <input
                  type="number"
                  required
                  value={editMinWithdraw}
                  onChange={(e) => setEditMinWithdraw(e.target.value)}
                  placeholder="200"
                  className="w-full bg-[#05070D] border border-slate-800 focus:border-red-500/40 rounded-xl px-4 py-2.5 text-slate-200 font-mono outline-none transition"
                />
              </div>
            </div>

            <div>
              <label className="block text-slate-400 font-black mb-1 uppercase tracking-wider text-[10px]">Business UPI Address *</label>
              <input
                type="text"
                required
                value={editUpi}
                onChange={(e) => setEditUpi(e.target.value)}
                placeholder="pandapanel@ybl"
                className="w-full bg-[#05070D] border border-slate-800 focus:border-red-500/40 rounded-xl px-4 py-2.5 text-slate-200 font-mono outline-none transition"
              />
            </div>

            <div>
              <label className="block text-slate-400 font-black mb-1 uppercase tracking-wider text-[10px]">QR Code Image URL</label>
              <input
                type="text"
                value={editQrCodeUrl}
                onChange={(e) => setEditQrCodeUrl(e.target.value)}
                placeholder="https://..."
                className="w-full bg-[#05070D] border border-slate-800 focus:border-red-500/40 rounded-xl px-4 py-2.5 text-slate-200 font-mono outline-none transition"
              />
            </div>

            <div className="grid grid-cols-2 gap-3 pt-2 border-t border-slate-800/60 text-[10px] font-black uppercase">
              <div>
                <label className="block text-slate-400 mb-1">Clean Fund Rate (₹)</label>
                <input
                  type="number"
                  step="0.01"
                  required
                  value={editCleanFundRate}
                  onChange={(e) => setEditCleanFundRate(e.target.value)}
                  className="w-full bg-[#05070D] border border-slate-800 focus:border-red-500/40 rounded-xl px-4 py-2.5 text-slate-200 font-mono outline-none transition"
                />
              </div>
              <div>
                <label className="block text-slate-400 mb-1 font-black uppercase">Stock Fund Rate (₹)</label>
                <input
                  type="number"
                  step="0.01"
                  required
                  value={editStockFundRate}
                  onChange={(e) => setEditStockFundRate(e.target.value)}
                  className="w-full bg-[#05070D] border border-slate-800 focus:border-red-500/40 rounded-xl px-4 py-2.5 text-slate-200 font-mono outline-none transition"
                />
              </div>
              <div>
                <label className="block text-slate-400 mb-1 font-black uppercase">Rat Fund Rate (₹)</label>
                <input
                  type="number"
                  step="0.01"
                  required
                  value={editRatFundRate}
                  onChange={(e) => setEditRatFundRate(e.target.value)}
                  className="w-full bg-[#05070D] border border-slate-800 focus:border-red-500/40 rounded-xl px-4 py-2.5 text-slate-200 font-mono outline-none transition"
                />
              </div>
              <div>
                <label className="block text-slate-400 mb-1 font-black uppercase">USDT Sell Rate (₹)</label>
                <input
                  type="number"
                  step="0.01"
                  required
                  value={editUsdtSellRate}
                  onChange={(e) => setEditUsdtSellRate(e.target.value)}
                  className="w-full bg-[#05070D] border border-slate-800 focus:border-red-500/40 rounded-xl px-4 py-2.5 text-slate-200 font-mono outline-none transition"
                />
              </div>
            </div>

            <div className="pt-2 text-[10px] font-black uppercase">
              <label className="block text-slate-400 mb-1">Base USDT Buy Rate (₹)</label>
              <input
                type="number"
                step="0.01"
                required
                value={editUsdtBuyRate}
                onChange={(e) => setEditUsdtBuyRate(e.target.value)}
                className="w-full bg-[#05070D] border border-slate-800 focus:border-red-500/40 rounded-xl px-4 py-2.5 text-slate-200 font-mono outline-none transition"
              />
            </div>

            <div className="text-[10px] font-black uppercase">
              <label className="block text-slate-400 mb-1">USDT Wallet Address (TRC20)</label>
              <input
                type="text"
                required
                value={editUsdtWallet}
                onChange={(e) => setEditUsdtWallet(e.target.value)}
                placeholder="TRC20 Wallet Address"
                className="w-full bg-[#05070D] border border-slate-800 focus:border-red-500/40 rounded-xl px-4 py-2.5 text-slate-200 font-mono outline-none transition"
              />
            </div>

            <div className="flex items-center justify-between p-4 bg-[#05070D] border border-slate-800/60 rounded-2xl mt-2">
              <div>
                <div className="text-[10px] font-black text-slate-200 uppercase tracking-wider">Live Activity Status</div>
                <div className="text-[9px] text-slate-500 font-bold">Show/Hide live ticker for users</div>
              </div>
              <button
                type="button"
                onClick={() => setEditLiveActivityEnabled(!editLiveActivityEnabled)}
                className={`w-12 h-6 rounded-full transition-colors relative ${editLiveActivityEnabled ? "bg-green-500" : "bg-slate-800"}`}
              >
                <div className={`absolute top-1 left-1 w-4 h-4 bg-white rounded-full transition-transform ${editLiveActivityEnabled ? "translate-x-6" : ""}`} />
              </button>
            </div>

            <div className="flex gap-3 mt-2 text-[10px] font-black uppercase tracking-wider">
              <button
                type="submit"
                className="flex-1 bg-gradient-to-r from-red-500 to-rose-600 hover:from-red-400 hover:to-rose-500 text-white font-black py-4 px-4 rounded-xl shadow-lg transition duration-200 active:scale-95"
              >
                Update Configuration
              </button>
              <button
                type="button"
                onClick={() => {
                  window.open(`/api/admin/export-db?token=${token}`, '_blank');
                }}
                className="bg-slate-800 hover:bg-slate-700 text-white font-black py-4 px-5 rounded-xl shadow-lg transition duration-200 flex items-center justify-center gap-2 active:scale-95"
                title="Download Permanent Backup"
              >
                <Download className="w-4 h-4" />
                Backup
              </button>
            </div>
          </form>
        </div>
      )}

      {tab === "usdt" && (
        <div className="space-y-4">
          <h3 className="text-[10px] font-black uppercase text-red-500 tracking-wider">Awaiting USDT Exchange Actions ({pendingUsdtList.length})</h3>

          {pendingUsdtList.length === 0 ? (
            <div className="p-6 bg-[#0D1425] border border-slate-800/50 rounded-[24px] text-center text-xs font-bold text-slate-500">
              No pending USDT requests. All good!
            </div>
          ) : (
            pendingUsdtList.map((tx) => (
              <div key={tx.id} className="bg-[#0D1425] border border-slate-800/50 rounded-[24px] p-5 space-y-4 shadow-xl">
                <div className="flex justify-between items-start text-xs border-b border-slate-800 pb-3">
                  <div>
                    <div className="font-bold text-slate-100 text-sm flex items-center gap-2">
                      <Zap className="w-4 h-4 text-red-500 animate-pulse" />
                      <span className="font-black text-xs uppercase tracking-wider">{tx.type === "usdt_buy" ? "BUY USDT" : "SELL USDT"}</span>
                    </div>
                    <div className="font-black text-slate-200 mt-1.5 text-sm font-mono">₹{tx.amount.toLocaleString()}</div>
                    <span className="text-[10px] text-slate-500 block mt-0.5 font-bold uppercase">User: <strong className="text-red-500">{tx.username}</strong></span>
                  </div>
                  <div className="text-right">
                    <span className="text-[8px] font-mono bg-[#05070D] border border-slate-800 px-2.5 py-1 text-slate-400 rounded-lg uppercase tracking-wider font-black">{tx.type.replace("_", " ")}</span>
                    <span className="text-[9px] block text-slate-500 mt-1 font-bold">{new Date(tx.createdAt).toLocaleString()}</span>
                  </div>
                </div>

                <div className="space-y-2.5 text-xs">
                  <div className="text-slate-400 font-bold uppercase text-[9px] tracking-wider">TXID / UTR / Ref: <span className="font-mono font-black text-red-400 select-all">{tx.utr}</span></div>
                  {tx.bankDetails && (
                    <div className="p-4 bg-[#05070D]/50 border border-slate-800/60 rounded-2xl space-y-1.5 mt-2 font-bold text-[10px]">
                      <div className="text-[8px] font-black text-slate-500 uppercase tracking-wider mb-1">Payout Destination</div>
                      <div className="grid grid-cols-2 gap-x-4 gap-y-1.5">
                        <div className="text-slate-400">Holder: <span className="text-slate-200 font-black">{tx.bankDetails.holderName}</span></div>
                        <div className="text-slate-400">Bank: <span className="text-slate-200 font-black">{tx.bankDetails.bankName}</span></div>
                        <div className="text-slate-400">Acc: <span className="text-slate-200 font-black font-mono">{tx.bankDetails.accountNumber}</span></div>
                        <div className="text-slate-400">IFSC: <span className="text-slate-200 font-black font-mono uppercase">{tx.bankDetails.ifsc}</span></div>
                      </div>
                      {tx.bankDetails.upiId && (
                        <div className="text-slate-400 pt-1.5 border-t border-slate-800/60 mt-1.5 text-[9px]">
                          UPI ID: <span className="text-red-400 font-black select-all">{tx.bankDetails.upiId}</span>
                        </div>
                      )}
                    </div>
                  )}
                </div>

                <div className="flex gap-2 text-[10px] font-black uppercase tracking-wider pt-2">
                  <button
                    disabled={actionLoadingId === tx.id}
                    onClick={() => handleDepositAction(tx.id, "approve")}
                    className="flex-1 bg-gradient-to-r from-green-600 to-emerald-600 hover:from-green-500 text-white py-2.5 rounded-xl transition flex justify-center items-center gap-1 active:scale-95 shadow-md"
                  >
                    <Check className="w-4 h-4" />
                    <span>Approve</span>
                  </button>
                  <button
                    disabled={actionLoadingId === tx.id}
                    onClick={() => handleDepositAction(tx.id, "reject")}
                    className="p-2.5 bg-[#05070D] hover:bg-red-500/10 border border-slate-800 hover:border-red-500/20 text-slate-400 hover:text-red-450 rounded-xl transition active:scale-95 shadow-md"
                    title="Reject"
                  >
                    <X className="w-4 h-4" />
                  </button>
                </div>
              </div>
            ))
          )}
        </div>
      )}

      {tab === "history" && (
        <div className="space-y-4">
          <div className="flex justify-between items-center">
            <h3 className="text-[10px] font-black uppercase text-red-500 tracking-wider">Global Transaction History</h3>
            <button onClick={exportData} className="text-[9px] font-black uppercase text-red-500 hover:text-red-400 flex items-center gap-1 bg-red-500/10 px-3 py-1.5 rounded-lg border border-red-500/20 transition">
              <FileSpreadsheet className="w-3.5 h-3.5" />
              <span>Export CSV</span>
            </button>
          </div>

          <div className="bg-[#0D1425] border border-slate-800/50 rounded-[24px] overflow-hidden shadow-xl">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-[10px]">
                <thead className="bg-[#05070D] text-slate-500 uppercase font-black tracking-wider border-b border-slate-800/60">
                  <tr>
                    <th className="px-5 py-4">Date & Time</th>
                    <th className="px-5 py-4">User</th>
                    <th className="px-5 py-4">Type</th>
                    <th className="px-5 py-4">Amount</th>
                    <th className="px-5 py-4">Status</th>
                    <th className="px-5 py-4">Reference</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/40">
                  {allHistoryList.map((tx) => (
                    <tr key={tx.id} className="hover:bg-[#05070D]/40 transition">
                      <td className="px-5 py-3 text-slate-500 font-mono whitespace-nowrap font-bold">
                        {new Date(tx.createdAt).toLocaleString()}
                      </td>
                      <td className="px-5 py-3 font-black text-slate-200">
                        {tx.username}
                      </td>
                      <td className="px-5 py-3">
                        <span className={`px-2 py-0.5 rounded-md text-[8px] font-black uppercase ${
                          tx.type === "deposit" || tx.type === "usdt_buy" ? "text-green-400 bg-green-500/10" : "text-red-400 bg-red-500/10"
                        }`}>
                          {tx.type}
                        </span>
                      </td>
                      <td className="px-5 py-3 font-mono font-black text-slate-100">
                        ₹{tx.amount.toLocaleString()}
                      </td>
                      <td className="px-5 py-3">
                        <span className={`capitalize font-black text-[9px] uppercase tracking-wider ${
                          tx.status === "approved" ? "text-green-400" : tx.status === "rejected" ? "text-red-400" : "text-red-400 animate-pulse"
                        }`}>
                          {tx.status}
                        </span>
                      </td>
                      <td className="px-5 py-3 font-mono text-slate-400 font-bold select-all truncate max-w-[100px]">
                        {tx.utr || tx.id}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            {allHistoryList.length === 0 && (
              <div className="p-8 text-center text-slate-500 text-xs font-bold italic">
                No transactions found in the global ledger.
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
