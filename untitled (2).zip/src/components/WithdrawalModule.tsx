import { apiFetch } from "../lib/api";
import React, { useState, useEffect } from "react";
import { 
  ArrowLeft, CheckCircle2, AlertCircle, RefreshCw, Landmark, Trash2, ArrowUpRight, AlertOctagon
} from "lucide-react";
import { SiteSettings, BankAccount, Transaction } from "../types";

interface WithdrawalModuleProps {
  settings: SiteSettings;
  walletBalance: number;
  onBack: () => void;
  token: string;
  onRefresh: () => void;
  transactions: Transaction[];
}

export default function WithdrawalModule({ 
  settings, 
  walletBalance, 
  onBack, 
  token, 
  onRefresh, 
  transactions 
}: WithdrawalModuleProps) {
  const [amount, setAmount] = useState<string>("");
  const [banks, setBanks] = useState<BankAccount[]>([]);
  const [selectedBankId, setSelectedBankId] = useState<string>("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);

  // Filter withdrawal transactions for local history display
  const withdrawalHistory = transactions.filter(t => t.type === "withdrawal");

  const fetchBanks = async () => {
    try {
      const response = await apiFetch("/api/banks", {
        headers: { "Authorization": `Bearer ${token}` }
      });
      const data = await response.json();
      if (Array.isArray(data)) {
        const activeBanks = data.filter(b => b.isActive);
        setBanks(activeBanks);
        if (activeBanks.length > 0) {
          setSelectedBankId(activeBanks[0].id);
        }
      }
    } catch (err) {
      console.error("Error loading bank accounts", err);
    }
  };

  useEffect(() => {
    fetchBanks();
  }, []);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setSuccess(null);

    const amtNum = Number(amount);
    if (!amount || isNaN(amtNum) || amtNum <= 0) {
      setError("Please enter a valid withdrawal amount");
      return;
    }

    if (amtNum < settings.minWithdraw) {
      setError(`Minimum withdrawal limit is ₹${settings.minWithdraw}`);
      return;
    }

    if (amtNum > walletBalance) {
      setError("Insufficient balance in your PANDA PANEL wallet");
      return;
    }

    if (!selectedBankId) {
      setError("Please link a bank account from Bank Accounts tab first");
      return;
    }

    setLoading(true);

    try {
      const response = await apiFetch("/api/withdrawals", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Authorization": `Bearer ${token}`
        },
        body: JSON.stringify({
          amount: amtNum,
          bankAccountId: selectedBankId
        })
      });

      const data = await response.json();
      if (!response.ok) {
        throw new Error(data.error || "Withdrawal failed");
      }

      setSuccess("Your payout request has been generated! Balance was updated and placed in pending queue.");
      setAmount("");
      onRefresh();
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-5">
      {/* Header Panel */}
      <div className="flex items-center gap-3 bg-[#0D1425] border border-slate-800/50 p-4 rounded-[20px]">
        <button 
          onClick={onBack}
          className="p-2 bg-[#05070D] hover:bg-slate-850 border border-slate-800 rounded-xl text-slate-300 hover:text-white transition active:scale-95"
        >
          <ArrowLeft className="w-4 h-4" />
        </button>
        <div className="w-9 h-9 rounded-full flex items-center justify-center bg-gradient-to-br from-red-600 to-rose-600 border border-red-500/30 text-white font-black text-xs tracking-wider shrink-0 shadow-md">PP</div>
        <div>
          <h2 className="text-sm font-black text-slate-100 uppercase tracking-wide">SECURE CASHOUT</h2>
          <p className="text-[10px] text-slate-400 font-bold uppercase">Linked Bank Payout Queue</p>
        </div>
      </div>

      {error && (
        <div className="p-3.5 bg-red-500/10 border border-red-500/20 rounded-[16px] text-red-400 text-xs font-bold flex items-center gap-2">
          <AlertCircle className="w-4 h-4 text-red-500 shrink-0" />
          <span>{error}</span>
        </div>
      )}

      {success && (
        <div className="p-4 bg-green-500/10 border border-green-500/20 rounded-[20px] text-green-300 text-xs flex items-start gap-3">
          <CheckCircle2 className="w-5 h-5 text-green-400 shrink-0 mt-0.5" />
          <div>
            <span className="font-black uppercase tracking-wider block text-green-400">Cashout Registered</span>
            <p className="mt-1 leading-relaxed text-[11px] text-slate-300">{success}</p>
          </div>
        </div>
      )}

      {/* Main Form */}
      <div className="bg-[#0D1425] border border-slate-800/50 rounded-[24px] p-5 shadow-xl space-y-5">
        <div className="flex justify-between items-center bg-[#05070D] p-4 rounded-2xl border border-slate-800/60">
          <div>
            <span className="text-[9px] text-slate-500 uppercase font-black tracking-wider block">Available Wallet Balance</span>
            <span className="text-xl font-black text-white font-mono block mt-1">₹{walletBalance.toLocaleString()}</span>
          </div>
          <span className="text-[9px] text-red-500 font-black bg-red-500/10 px-2.5 py-1 rounded-xl uppercase tracking-widest border border-red-500/10">
            Premium Elite
          </span>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-[10px] uppercase text-slate-400 font-black tracking-wider mb-2">Enter Cashout Amount (₹)</label>
            <div className="relative">
              <span className="absolute left-4 top-3 text-red-500 font-black text-lg">₹</span>
              <input
                type="number"
                required
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                placeholder={`Min. ₹${settings.minWithdraw}`}
                className="w-full bg-[#05070D] border border-slate-800 focus:border-red-500/40 rounded-2xl pl-8 pr-4 py-3 text-base font-black text-red-400 outline-none transition font-mono"
              />
            </div>
            <p className="text-[9px] text-slate-500 font-bold uppercase tracking-tight mt-1.5">Minimum payout limit: ₹{settings.minWithdraw}. Speed processing active.</p>
          </div>

          <div>
            <label className="block text-[10px] uppercase text-slate-400 font-black tracking-wider mb-2">Select Verified Payout Channel</label>
            {banks.length === 0 ? (
              <div className="bg-[#05070D] border border-slate-800/60 rounded-2xl p-5 text-center space-y-2">
                <p className="text-xs text-slate-400">No active verified payout accounts linked.</p>
                <span className="text-[9px] text-red-400 font-black uppercase tracking-wider block">Add payee details inside "Payees" tab first to proceed.</span>
              </div>
            ) : (
              <div className="space-y-2.5">
                {banks.map((bank) => (
                  <label 
                    key={bank.id}
                    className={`flex items-center justify-between p-3.5 rounded-2xl border cursor-pointer transition-all duration-200 ${
                      selectedBankId === bank.id 
                        ? "bg-[#05070D] border-red-500/40 text-slate-100" 
                        : "bg-[#05070D]/40 border-slate-800/70 text-slate-400 hover:border-slate-800"
                    }`}
                  >
                    <div className="flex items-center gap-3">
                      <input 
                        type="radio" 
                        name="withdrawal_bank"
                        checked={selectedBankId === bank.id}
                        onChange={() => setSelectedBankId(bank.id)}
                        className="accent-red-500"
                      />
                      <div className="text-left">
                        <div className="text-xs font-black text-slate-200">{bank.bankName}</div>
                        <div className="text-[9px] font-mono text-slate-500 mt-1 uppercase">A/C: ****{bank.accountNumber.substring(bank.accountNumber.length - 4)}</div>
                      </div>
                    </div>
                    {bank.upiId && <span className="text-[9px] font-mono bg-[#05070D] border border-slate-800 text-slate-400 px-2 py-0.5 rounded-lg select-all">{bank.upiId}</span>}
                  </label>
                ))}
              </div>
            )}
          </div>

          <button
            type="submit"
            disabled={loading || banks.length === 0}
            className="w-full bg-gradient-to-r from-red-500 to-rose-600 hover:from-red-400 text-white font-black py-3.5 px-4 rounded-xl shadow-lg transition duration-200 text-xs uppercase tracking-wider disabled:opacity-50 disabled:cursor-not-allowed"
          >
            {loading ? "Generating payout transfer..." : "Confirm Payout Transfer"}
          </button>
        </form>
      </div>

      {/* Payout History */}
      <div className="bg-[#0D1425] border border-slate-800/50 rounded-[24px] p-5 shadow-xl">
        <h3 className="text-[10px] uppercase font-black tracking-wider text-slate-300 flex items-center gap-1.5 mb-4">
          <ArrowUpRight className="w-4 h-4 text-red-500" /> Payout cashout logs
        </h3>

        <div className="space-y-3">
          {withdrawalHistory.length === 0 ? (
            <p className="text-[10px] text-slate-500 uppercase font-bold text-center py-4">No recent payout records found.</p>
          ) : (
            withdrawalHistory.map((tx) => (
              <div 
                key={tx.id}
                className="bg-[#05070D] border border-slate-800/60 rounded-2xl p-3.5 flex justify-between items-center text-xs"
              >
                <div>
                  <div className="font-black text-slate-200">₹{tx.amount.toLocaleString()}</div>
                  <div className="text-[9px] text-slate-500 mt-1 font-mono">
                    {new Date(tx.createdAt).toLocaleDateString()} • {new Date(tx.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                  </div>
                  {tx.bankDetails && (
                    <div className="text-[9px] font-mono text-red-400/80 mt-1 uppercase">
                      {tx.bankDetails.bankName} (A/C: ****{tx.bankDetails.accountNumber.substring(tx.bankDetails.accountNumber.length - 4)})
                    </div>
                  )}
                </div>

                <div className="text-right">
                  <span className={`text-[9px] px-2.5 py-1 rounded-xl border inline-block font-black uppercase tracking-wider ${
                    tx.status === "approved" 
                      ? "bg-green-500/10 text-green-400 border-green-500/20" 
                      : tx.status === "pending"
                      ? "bg-red-500/10 text-red-400 border-red-500/20"
                      : "bg-red-500/10 text-red-400 border-red-500/20"
                  }`}>
                    {tx.status}
                  </span>
                </div>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
}
