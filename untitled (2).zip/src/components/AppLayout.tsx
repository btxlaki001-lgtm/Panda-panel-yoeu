import { ReactNode } from "react";
import { Link, useLocation } from "react-router-dom";
import { useAuth } from "../lib/AuthContext";
import { Home, Landmark, Users, Monitor, User as UserIcon, HelpCircle, Bell } from "lucide-react";
import { cn } from "../lib/utils";

export default function AppLayout({ children }: { children: ReactNode }) {
  const { user } = useAuth();
  const location = useLocation();

  const navItems = [
    { name: "Home", href: "/dashboard", icon: Home },
    { name: "Payees", href: "/bank-accounts", icon: Landmark },
    { name: "Referrals", href: "/dashboard", icon: Users },
    { name: "Control", href: "/admin", icon: Monitor, hide: user?.role !== "admin" },
    { name: "Profile", href: "/dashboard", icon: UserIcon },
  ].filter(i => !i.hide);

  return (
    <div className="min-h-screen bg-[#050505] flex justify-center text-white font-sans selection:bg-[#ff204e]/30">
      <div className="w-full max-w-[420px] bg-black min-h-screen relative shadow-2xl flex flex-col border-x border-white/5">
        {/* Header */}
        <header className="flex items-center justify-between p-4 pb-3 border-b border-white/5 z-10 bg-black sticky top-0">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-full border border-red-500/30 flex items-center justify-center bg-gradient-to-br from-red-600 to-rose-600 text-white font-black text-xs tracking-widest shrink-0 shadow-lg">PP</div>
            <span className="text-[#ff204e] font-black text-lg tracking-wider">PANDA PANEL™</span>
          </div>
          <div className="flex items-center gap-4">
            <button className="flex flex-col items-center gap-1 group">
              <HelpCircle className="w-5 h-5 text-[#ff204e] group-hover:scale-110 transition-transform" />
              <span className="text-[8px] text-gray-500 font-bold uppercase tracking-wider">Help</span>
            </button>
            <button className="flex flex-col items-center gap-1 group relative">
              <Bell className="w-5 h-5 text-[#ff204e] group-hover:scale-110 transition-transform" />
              <span className="absolute top-0 right-1 w-2 h-2 bg-blue-500 rounded-full border border-black"></span>
              <span className="text-[8px] text-gray-500 font-bold uppercase tracking-wider">Notifications</span>
            </button>
            <button className="flex flex-col items-center gap-1 group">
              <UserIcon className="w-5 h-5 text-[#ff204e] group-hover:scale-110 transition-transform" />
              <span className="text-[8px] text-gray-500 font-bold uppercase tracking-wider">Account</span>
            </button>
          </div>
        </header>

        <main className="flex-1 overflow-y-auto pb-24 hide-scrollbar">
          {children}
        </main>

        {/* Bottom Nav */}
        <nav className="absolute bottom-0 w-full bg-[#0a0c10] border-t border-white/5 flex justify-around items-center py-3 px-2 z-50">
          {navItems.map((item) => {
            const isActive = location.pathname === item.href;
            return (
              <Link key={item.name} to={item.href} className="flex flex-col items-center gap-1.5 w-16 group">
                <item.icon className={cn("w-5 h-5 transition-all group-hover:scale-110", isActive ? "text-[#ff204e]" : "text-gray-500")} />
                <span className={cn("text-[9px] font-bold transition-colors tracking-wider", isActive ? "text-[#ff204e]" : "text-gray-500")}>
                  {item.name}
                </span>
              </Link>
            );
          })}
        </nav>
      </div>
    </div>
  );
}
