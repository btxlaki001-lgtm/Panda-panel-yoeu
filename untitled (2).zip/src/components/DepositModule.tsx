import { apiFetch } from "../lib/api";
import React, { useState } from "react";
import { 
  ArrowLeft, Copy, Upload, ShieldCheck, CheckCircle2, QrCode, CreditCard, ExternalLink, Lock, AlertCircle
} from "lucide-react";
import { SiteSettings } from "../types";
import LiveActivityTicker from "./LiveActivityTicker";

interface DepositModuleProps {
  settings: SiteSettings;
  onBack: () => void;
  token: string;
  onRefresh: () => void;
  tickerActivities?: any[];
  tickerLocked?: boolean;
}

export default function DepositModule({ 
  settings, 
  onBack, 
  token, 
  onRefresh,
  tickerActivities,
  tickerLocked
}: DepositModuleProps) {
  const [method] = useState<"upi" | "qr" | "bank">("upi");
  const [utr, setUtr] = useState("");
  const [screenshot, setScreenshot] = useState("");
  const [copiedText, setCopiedText] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);

  const handleCopy = (text: string, type: string) => {
    navigator.clipboard.writeText(text);
    setCopiedText(type);
    setTimeout(() => setCopiedText(null), 1500);
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setScreenshot(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setSuccess(null);

    const amtNum = settings.minDeposit;

    if (!utr || utr.trim().length < 8) {
      setError("Please enter a valid Transaction UTR reference (min 8 digits)");
      return;
    }

    setLoading(true);

    try {
      const response = await apiFetch("/api/deposits", {
        method: "POST",
        headers: { 
          "Content-Type": "application/json",
          "Authorization": `Bearer ${token}`
        },
        body: JSON.stringify({
          amount: amtNum,
          method: "UPI ID Payment",
          utr,
          screenshot
        })
      });

      const data = await response.json();
      if (!response.ok) {
        throw new Error(data.error || "Deposit submission failed");
      }

      setSuccess("Your deposit request was submitted! Admin approval is required. Expect updates within 15-30 mins.");
      onRefresh();
      
      setUtr("");
      setScreenshot("");
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-5">
      {/* Title Header */}
      <div className="flex items-center gap-3 bg-[#0D1425] border border-slate-800/50 p-4 rounded-[20px]">
        <button 
          onClick={onBack}
          className="p-2 bg-[#05070D] hover:bg-slate-850 border border-slate-800 rounded-xl text-slate-300 hover:text-white transition active:scale-95"
        >
          <ArrowLeft className="w-4 h-4" />
        </button>
        <div className="w-9 h-9 rounded-full flex items-center justify-center bg-gradient-to-br from-red-600 to-rose-600 border border-red-500/30 text-white font-black text-xs tracking-wider shrink-0 shadow-md">PP</div>
        <div>
          <h2 className="text-sm font-black text-slate-100 uppercase tracking-wide">ADD SECURE CASH</h2>
          <p className="text-[10px] text-slate-400 font-bold uppercase">Instant Bank Top Up Gateway</p>
        </div>
      </div>

      {settings.depositEnabled === false ? (
        <div className="bg-[#0D1425] border border-red-500/20 text-red-400 p-6 rounded-[24px] flex flex-col items-center justify-center text-center space-y-3">
          <div className="bg-red-500/10 p-3.5 rounded-full border border-red-500/20">
            <Lock className="w-6 h-6 text-red-500" />
          </div>
          <div>
            <h3 className="font-extrabold text-xs uppercase tracking-wider text-slate-200">Deposits Temporarily Locked</h3>
            <p className="text-[10px] text-slate-400 mt-2 leading-relaxed">
              New secure deposits are temporarily suspended platform-wide. Please check back later or reach out to our active Telegram support desk.
            </p>
          </div>
        </div>
      ) : (
        <>
          {error && (
            <div className="p-3.5 bg-red-500/10 border border-red-500/20 rounded-[16px] text-red-400 text-xs font-bold flex items-center gap-2">
              <AlertCircle className="w-4 h-4 text-red-500 shrink-0" />
              <span>{error}</span>
            </div>
          )}

          {success && (
            <div className="p-4 bg-green-500/10 border border-green-500/20 rounded-[20px] text-green-300 text-xs flex items-start gap-3">
              <CheckCircle2 className="w-5 h-5 text-green-400 shrink-0 mt-0.5" />
              <div>
                <span className="font-black uppercase tracking-wider block text-green-400">Submission Registered</span>
                <p className="mt-1 leading-relaxed text-[11px] text-slate-300">{success}</p>
              </div>
            </div>
          )}

          <div className="bg-[#0D1425] border border-slate-800/50 rounded-[24px] p-5 shadow-xl space-y-5">
            <div>
              <label className="block text-[10px] uppercase text-slate-400 font-black tracking-wider mb-2">Deposit Amount (Fixed Activation)</label>
              <div className="relative">
                <span className="absolute left-4 top-3 text-red-500 font-black text-lg">₹</span>
                <input
                  type="number"
                  readOnly
                  value={settings.minDeposit}
                  className="w-full bg-[#05070D] border border-slate-800 focus:border-red-500/40 rounded-2xl pl-8 pr-4 py-3 text-lg font-black text-red-400 outline-none transition font-mono cursor-not-allowed"
                />
              </div>
              <p className="text-[9px] text-slate-500 font-bold uppercase tracking-tight mt-1.5">Fixed activation ledger deposit. Zero convenience processing fees.</p>
            </div>

            {/* Dynamic Payment Details */}
            <div className="bg-[#05070D] border border-slate-800/60 rounded-2xl p-4 space-y-4">
              <div className="space-y-2">
                <span className="text-[10px] uppercase font-black text-red-500 tracking-wider block">Official UPI Details</span>
                <p className="text-[10px] text-slate-400 leading-relaxed">
                  Send your payment of ₹{settings.minDeposit} directly to the verified company UPI ID below from any secure application (GPay, PhonePe, Paytm).
                </p>
                <div className="flex items-center justify-between bg-[#0D1425] border border-slate-800/40 rounded-xl p-3">
                  <span className="font-mono text-[11px] font-black text-slate-200 select-all">{settings.upiId}</span>
                  <button
                    type="button"
                    onClick={() => handleCopy(settings.upiId, "upi")}
                    className="text-[10px] text-red-500 hover:text-red-400 font-black flex items-center gap-1 uppercase tracking-wider"
                  >
                    <Copy className="w-3.5 h-3.5" />
                    <span>{copiedText === "upi" ? "Copied" : "Copy"}</span>
                  </button>
                </div>
              </div>
            </div>

            {/* Telegram Support Button */}
            <a 
              href="https://t.me/pandapenalsupport" 
              target="_blank" 
              rel="noopener noreferrer"
              className="flex items-center justify-center gap-2 w-full bg-[#2AABEE]/10 border border-[#2AABEE]/30 hover:bg-[#2AABEE]/20 transition p-3 rounded-xl text-[#2AABEE] text-xs font-black uppercase tracking-wider"
            >
              <ExternalLink className="w-4 h-4" />
              Contact Telegram Customer Care
            </a>

            {/* Transaction Proof Details input form */}
            <form onSubmit={handleSubmit} className="space-y-4 pt-4 border-t border-slate-800/60">
              <div>
                <label className="block text-[10px] uppercase text-slate-400 font-black tracking-wider mb-2">
                  Enter 12-Digit UTR / Transaction ID
                </label>
                <input
                  type="text"
                  required
                  value={utr}
                  onChange={(e) => setUtr(e.target.value.replace(/[^a-zA-Z0-9]/g, ""))}
                  placeholder="e.g. 123456789012"
                  className="w-full bg-[#05070D] border border-slate-800 focus:border-red-500/40 rounded-xl px-4 py-3 text-slate-200 font-mono outline-none transition text-sm duration-200"
                />
                <span className="text-[9px] text-slate-500 font-bold uppercase tracking-tight block mt-1.5">Provide exact transaction reference to ensure instant matching of banking ledger.</span>
              </div>

              <div>
                <label className="block text-[10px] uppercase text-slate-400 font-black tracking-wider mb-2">
                  Upload Payment Screenshot (Optional)
                </label>
                <div className="flex items-center justify-center w-full">
                  <label className="flex flex-col items-center justify-center w-full h-28 border-2 border-slate-800/80 border-dashed rounded-2xl cursor-pointer bg-[#05070D] hover:bg-[#05070D]/50 transition relative overflow-hidden duration-200">
                    {screenshot ? (
                      <div className="absolute inset-0 flex items-center justify-center bg-[#05070D]">
                        <img src={screenshot} alt="Screenshot proof" className="h-full w-auto object-contain p-2" />
                        <button 
                          type="button" 
                          onClick={(e) => { e.preventDefault(); setScreenshot(""); }} 
                          className="absolute right-2 top-2 bg-red-600/90 hover:bg-red-500 text-white font-black text-[9px] px-2 py-1 rounded-lg uppercase tracking-wider"
                        >
                          Clear
                        </button>
                      </div>
                    ) : (
                      <div className="flex flex-col items-center justify-center pt-4 pb-4">
                        <Upload className="w-5 h-5 text-slate-500 mb-1.5" />
                        <p className="text-[10px] text-slate-400 font-black uppercase tracking-wider">Click to upload screenshot</p>
                        <p className="text-[8px] text-slate-500 mt-1 uppercase">PNG, JPG formats</p>
                      </div>
                    )}
                    <input type="file" accept="image/*" onChange={handleFileChange} className="hidden" />
                  </label>
                </div>
              </div>

              <div className="p-3 bg-red-500/5 rounded-2xl border border-red-500/10 flex items-center gap-3">
                <ShieldCheck className="w-5 h-5 text-red-500 shrink-0" />
                <p className="text-[9px] text-slate-400 leading-relaxed font-bold uppercase tracking-tight">
                  Security notice: Credits require strict matching of UTR with banking record logs. Intentional fake submissions are blocked instantly.
                </p>
              </div>

              <button
                type="submit"
                disabled={loading}
                className="w-full bg-gradient-to-r from-red-500 to-rose-600 hover:from-red-400 text-white font-black py-3.5 px-4 rounded-xl shadow-lg transition duration-200 text-xs uppercase tracking-wider"
              >
                {loading ? "Verifying submission details..." : "Confirm Deposit Cash"}
              </button>
            </form>
          </div>
        </>
      )}
      
      {/* Live Activity ticker shown under deposits */}
      <div className="mt-4">
        <LiveActivityTicker activities={tickerActivities} isLocked={tickerLocked} />
      </div>
    </div>
  );
}
