import { apiFetch } from "../lib/api";
import React, { useState, useEffect } from "react";
import { 
  ArrowLeft, MessageSquare, Plus, CheckCircle2, AlertCircle, RefreshCw, MessageSquarePlus, Send, MessageCircle
} from "lucide-react";
import { SupportTicket, SiteSettings } from "../types";

interface SupportCenterProps {
  settings: SiteSettings;
  onBack: () => void;
  token: string;
}

export default function SupportCenter({ settings, onBack, token }: SupportCenterProps) {
  const [tickets, setTickets] = useState<SupportTicket[]>([]);
  const [subject, setSubject] = useState("");
  const [message, setMessage] = useState("");
  const [replyText, setReplyText] = useState("");
  const [activeTicketId, setActiveTicketId] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);

  const fetchTickets = async () => {
    try {
      const response = await apiFetch("/api/tickets", {
        headers: { "Authorization": `Bearer ${token}` }
      });
      const data = await response.json();
      if (Array.isArray(data)) {
        setTickets(data);
      }
    } catch (err) {
      console.error("Error fetching support tickets", err);
    }
  };

  useEffect(() => {
    fetchTickets();
  }, []);

  const handleCreateTicket = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setSuccess(null);

    if (!subject || !message) {
      setError("Please fill out both subject and message");
      return;
    }

    setLoading(true);

    try {
      const response = await apiFetch("/api/tickets", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Authorization": `Bearer ${token}`
        },
        body: JSON.stringify({ subject, message })
      });

      const data = await response.json();
      if (!response.ok) {
        throw new Error(data.error || "Failed to create support ticket");
      }

      setSuccess("Support ticket registered successfully!");
      setSubject("");
      setMessage("");
      fetchTickets();
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  const handleSendReply = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!replyText.trim() || !activeTicketId) return;

    try {
      const response = await apiFetch(`/api/tickets/${activeTicketId}/reply`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Authorization": `Bearer ${token}`
        },
        body: JSON.stringify({ message: replyText })
      });

      if (response.ok) {
        setReplyText("");
        await fetchTickets();
      }
    } catch (err) {
      console.error("Error sending reply", err);
    }
  };

  const activeTicket = tickets.find(t => t.id === activeTicketId);

  return (
    <div className="space-y-5">
      {/* Title Header */}
      <div className="flex items-center gap-3 bg-[#0D1425] border border-slate-800/50 p-4 rounded-[20px]">
        <button 
          onClick={onBack}
          className="p-2 bg-[#05070D] hover:bg-slate-850 border border-slate-800 rounded-xl text-slate-300 hover:text-white transition active:scale-95"
        >
          <ArrowLeft className="w-4 h-4" />
        </button>
        <div className="w-9 h-9 rounded-full flex items-center justify-center bg-gradient-to-br from-red-600 to-rose-600 border border-red-500/30 text-white font-black text-xs tracking-wider shrink-0 shadow-md">PP</div>
        <div>
          <h2 className="text-sm font-black text-slate-100 uppercase tracking-wide">SUPPORT DESK</h2>
          <p className="text-[10px] text-slate-400 font-bold uppercase">24/7 Priority Resolution Channels</p>
        </div>
      </div>

      {error && (
        <div className="p-3.5 bg-red-500/10 border border-red-500/20 rounded-[16px] text-red-400 text-xs font-bold flex items-center gap-2">
          <AlertCircle className="w-4 h-4 text-red-500 shrink-0" />
          <span>{error}</span>
        </div>
      )}

      {success && (
        <div className="p-3.5 bg-green-500/10 border border-green-500/20 rounded-[16px] text-green-300 text-xs font-bold">
          <span>{success}</span>
        </div>
      )}

      {/* Social Support Channels */}
      <div className="bg-[#0D1425] border border-slate-800/50 rounded-[24px] p-5 shadow-xl space-y-4">
        <h3 className="text-[10px] uppercase font-black tracking-wider text-slate-300 flex items-center gap-1.5">
          <MessageCircle className="w-4 h-4 text-red-500" /> Direct Support Lines
        </h3>

        <div className="flex justify-center text-xs font-bold">
          <a
            href={settings.telegramSupport}
            target="_blank"
            rel="noopener noreferrer"
            className="w-full bg-[#05070D] hover:bg-[#05070D]/50 border border-slate-850 text-red-400 py-4 rounded-2xl flex flex-col items-center justify-center gap-2 transition text-center shadow-inner"
          >
            <span className="font-black text-xs uppercase tracking-wider block">Official Telegram HelpDesk</span>
            <span className="text-[9px] text-slate-400 font-bold uppercase tracking-tight">Active Officer Response • Tap to chat</span>
          </a>
        </div>
      </div>

      {activeTicketId && activeTicket ? (
        /* Conversation View */
        <div className="bg-[#0D1425] border border-slate-800/50 rounded-[24px] p-5 shadow-xl space-y-4">
          <div className="flex justify-between items-center pb-3 border-b border-slate-800/60">
            <div>
              <span className="text-[9px] uppercase font-black text-red-500 tracking-wider block">Subject Topic</span>
              <h4 className="font-black text-slate-200 text-xs mt-1 uppercase tracking-wide">{activeTicket.subject}</h4>
            </div>
            <button
              onClick={() => setActiveTicketId(null)}
              className="text-[10px] font-black uppercase text-slate-400 hover:text-white bg-[#05070D] border border-slate-800/60 px-3 py-1.5 rounded-lg"
            >
              Back
            </button>
          </div>

          {/* Messages Flow */}
          <div className="space-y-3.5 max-h-[250px] overflow-y-auto pr-1 text-xs custom-scrollbar">
            {/* User message */}
            <div className="bg-[#05070D] border border-slate-800/60 rounded-2xl p-3.5 max-w-[85%] text-slate-300">
              <span className="text-[9px] text-red-500 font-black uppercase tracking-wider block mb-1">My Inquiry</span>
              <p className="leading-relaxed text-[11px] font-bold text-slate-300">{activeTicket.message}</p>
              <span className="text-[9px] text-slate-500 block mt-2 font-mono">
                {new Date(activeTicket.createdAt).toLocaleDateString()}
              </span>
            </div>

            {/* Replies */}
            {activeTicket.replies.map((reply, index) => (
              <div 
                key={index}
                className={`p-3.5 rounded-2xl max-w-[85%] text-xs ${
                  reply.sender === "admin"
                    ? "bg-slate-800/40 text-slate-200 ml-auto border border-slate-700/50"
                    : "bg-[#05070D] text-slate-300 border border-slate-800/60"
                }`}
              >
                <span className={`text-[9px] font-black uppercase tracking-wider block mb-1.5 ${reply.sender === "admin" ? "text-green-400" : "text-red-500"}`}>
                  {reply.sender === "admin" ? "Financial Officer" : "My Response"}
                </span>
                <p className="leading-relaxed text-[11px]">{reply.message}</p>
                <span className="text-[9px] text-slate-500 block mt-2 font-mono">
                  {new Date(reply.createdAt).toLocaleDateString()}
                </span>
              </div>
            ))}
          </div>

          {/* Reply Form */}
          <form onSubmit={handleSendReply} className="flex gap-2 pt-2 border-t border-slate-800/60">
            <input
              type="text"
              required
              value={replyText}
              onChange={(e) => setReplyText(e.target.value)}
              placeholder="Enter message text..."
              className="flex-1 bg-[#05070D] border border-slate-800 focus:border-red-500/40 rounded-xl px-4 py-2.5 text-xs text-slate-200 outline-none transition"
            />
            <button
              type="submit"
              className="p-3 bg-red-600 hover:bg-red-500 text-white rounded-xl transition shrink-0 active:scale-95"
            >
              <Send className="w-3.5 h-3.5" />
            </button>
          </form>
        </div>
      ) : (
        /* Support Tickets List and Register Form */
        <div className="space-y-5">
          <div className="bg-[#0D1425] border border-slate-800/50 rounded-[24px] p-5 shadow-xl space-y-4">
            <h3 className="text-[10px] uppercase font-black tracking-wider text-slate-300 flex items-center gap-1.5">
              <MessageSquarePlus className="w-4 h-4 text-red-500" /> Lodge a Support Ticket
            </h3>

            <form onSubmit={handleCreateTicket} className="space-y-3.5 text-xs">
              <div>
                <label className="block text-slate-400 font-bold uppercase text-[9px] tracking-wider mb-1.5">Subject / Issue Topic *</label>
                <input
                  type="text"
                  required
                  value={subject}
                  onChange={(e) => setSubject(e.target.value)}
                  placeholder="e.g. Deposit Delayed / KYC Approval update"
                  className="w-full bg-[#05070D] border border-slate-800 focus:border-red-500/40 rounded-xl px-4 py-3 text-slate-200 outline-none transition"
                />
              </div>

              <div>
                <label className="block text-slate-400 font-bold uppercase text-[9px] tracking-wider mb-1.5">Detailed Message *</label>
                <textarea
                  required
                  rows={3}
                  value={message}
                  onChange={(e) => setMessage(e.target.value)}
                  placeholder="Include your registered username, transaction details (UTR/Account details, time) for fast processing."
                  className="w-full bg-[#05070D] border border-slate-800 focus:border-red-500/40 rounded-xl px-4 py-3 text-slate-200 outline-none transition resize-none text-[11px]"
                />
              </div>

              <button
                type="submit"
                disabled={loading}
                className="w-full bg-gradient-to-r from-red-500 to-rose-600 hover:from-red-400 text-white font-black py-3.5 px-4 rounded-xl shadow-lg transition duration-200 text-xs uppercase tracking-wider mt-2 active:scale-95"
              >
                {loading ? "Lodging ticket..." : "Register Support Ticket"}
              </button>
            </form>
          </div>

          <div className="bg-[#0D1425] border border-slate-800/50 rounded-[24px] p-5 shadow-xl">
            <h3 className="text-[10px] uppercase font-black tracking-wider text-slate-300 flex items-center gap-1.5 mb-4">
              <MessageSquare className="w-4 h-4 text-red-500" /> Active Tickets history ({tickets.length})
            </h3>

            <div className="space-y-3">
              {tickets.length === 0 ? (
                <p className="text-[10px] text-slate-500 uppercase font-bold text-center py-5 bg-[#05070D] rounded-2xl border border-slate-800/60">
                  No previous tickets logged.
                </p>
              ) : (
                tickets.map((t) => (
                  <button
                    key={t.id}
                    onClick={() => setActiveTicketId(t.id)}
                    className="w-full bg-[#05070D]/60 hover:bg-[#05070D] border border-slate-800/80 rounded-2xl p-4 text-left transition flex justify-between items-center"
                  >
                    <div className="space-y-1.5 pr-3">
                      <div className="font-black text-slate-200 text-xs uppercase tracking-wide">{t.subject}</div>
                      <p className="text-[10px] text-slate-400 truncate max-w-[200px] font-bold">{t.message}</p>
                      <div className="text-[9px] text-slate-500 font-mono">{new Date(t.createdAt).toLocaleDateString()}</div>
                    </div>

                    <div className="text-right shrink-0">
                      <span className={`text-[9px] px-2.5 py-1 rounded-xl border font-black uppercase tracking-wider ${
                        t.status === "open"
                          ? "bg-red-500/10 text-red-400 border-red-500/20"
                          : "bg-[#0D1425] text-slate-500 border-slate-800"
                      }`}>
                        {t.status}
                      </span>
                    </div>
                  </button>
                ))
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
