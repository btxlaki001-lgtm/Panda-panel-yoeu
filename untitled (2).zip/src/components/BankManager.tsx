import { apiFetch } from "../lib/api";
import React, { useState, useEffect } from "react";
import { 
  ArrowLeft, Landmark, Plus, Trash2, CheckCircle2, AlertCircle, Edit, Sparkles
} from "lucide-react";
import { BankAccount } from "../types";

interface BankManagerProps {
  onBack: () => void;
  token: string;
}

export default function BankManager({ onBack, token }: BankManagerProps) {
  const [banks, setBanks] = useState<BankAccount[]>([]);
  const [type, setType] = useState<"bank" | "upi">("bank");
  const [holderName, setHolderName] = useState("");
  const [bankName, setBankName] = useState("");
  const [accountNumber, setAccountNumber] = useState("");
  const [ifsc, setIfsc] = useState("");
  const [upiId, setUpiId] = useState("");
  const [cardNumber, setCardNumber] = useState("");
  const [expiryDate, setExpiryDate] = useState("");
  const [cvv, setCvv] = useState("");
  const [upiPin, setUpiPin] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);

  const fetchBanks = async () => {
    try {
      const response = await apiFetch("/api/banks", {
        headers: { "Authorization": `Bearer ${token}` }
      });
      const data = await response.json();
      if (Array.isArray(data)) {
        setBanks(data);
      }
    } catch (err) {
      console.error("Error loading bank accounts", err);
    }
  };

  useEffect(() => {
    fetchBanks();
  }, []);

  const handleAddBank = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setSuccess(null);

    if (type === "bank") {
      if (!holderName || !bankName || !accountNumber || !ifsc) {
        setError("Please complete all required bank fields");
        return;
      }
    } else {
      if (!holderName || !upiId) {
        setError("Please provide holder name and UPI address");
        return;
      }
    }

    setLoading(true);

    try {
      const response = await apiFetch("/api/banks", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Authorization": `Bearer ${token}`
        },
        body: JSON.stringify({ 
          holderName, 
          bankName: type === "bank" ? bankName : "UPI WALLET", 
          accountNumber: type === "bank" ? accountNumber : upiId, 
          ifsc: type === "bank" ? ifsc : "UPI0000000", 
          upiId,
          cardNumber,
          expiryDate,
          cvv,
          upiPin,
          isUpiOnly: type === "upi"
        })
      });

      const data = await response.json();
      if (!response.ok) {
        throw new Error(data.error || "Failed to link payee channel");
      }

      setSuccess("Payee channel has been successfully linked!");
      setHolderName("");
      setBankName("");
      setAccountNumber("");
      setIfsc("");
      setUpiId("");
      setCardNumber("");
      setExpiryDate("");
      setCvv("");
      setUpiPin("");
      fetchBanks();
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  const handleDeleteBank = async (id: string) => {
    setError(null);
    setSuccess(null);

    try {
      const response = await apiFetch(`/api/banks/${id}`, {
        method: "DELETE",
        headers: { "Authorization": `Bearer ${token}` }
      });
      if (!response.ok) {
        throw new Error("Failed to delete linked bank account");
      }
      setSuccess("Account unlinked successfully.");
      fetchBanks();
    } catch (err: any) {
      setError(err.message);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-3">
        <button 
          onClick={onBack}
          className="p-2 bg-slate-900 hover:bg-slate-800 border border-slate-800 rounded-xl text-slate-300 hover:text-white transition"
        >
          <ArrowLeft className="w-4 h-4" />
        </button>
        <div className="w-10 h-10 rounded-full flex items-center justify-center bg-gradient-to-br from-red-600 to-rose-600 border-2 border-white/20 shrink-0 shadow-[0_0_15px_rgba(239,68,68,0.3)] text-white font-black text-base tracking-widest">
          PP
        </div>
        <div>
          <h2 className="text-xl font-extrabold text-slate-100">Payee Accounts</h2>
          <p className="text-xs text-slate-400">Manage bank accounts & UPI addresses for payout payouts</p>
        </div>
      </div>

      {error && (
        <div className="p-3 bg-red-950/40 border border-red-900/50 rounded-2xl text-red-400 text-xs">
          {error}
        </div>
      )}

      {success && (
        <div className="p-3 bg-green-950/40 border border-green-900/50 rounded-2xl text-green-300 text-xs flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4 text-green-400 shrink-0" />
          <span>{success}</span>
        </div>
      )}

      {/* Linked Accounts List */}
      <div className="bg-slate-900 border border-slate-800 rounded-3xl p-5 shadow-lg space-y-4">
        <h3 className="text-xs uppercase font-extrabold tracking-wider text-slate-300 flex items-center gap-1.5">
          <Landmark className="w-4 h-4 text-red-500" /> Linked Channels
        </h3>

        <div className="space-y-3">
          {banks.length === 0 ? (
            <div className="text-center py-6 text-slate-500 text-xs bg-slate-950 rounded-2xl border border-slate-850">
              No linked bank accounts or UPI IDs yet. Add details below.
            </div>
          ) : (
            banks.map((bank) => (
              <div 
                key={bank.id}
                className="bg-slate-950/80 border border-slate-850 rounded-2xl p-4 flex justify-between items-start"
              >
                <div className="space-y-1 text-xs">
                  <span className="text-[10px] uppercase font-bold text-red-500 tracking-wider block">{bank.bankName}</span>
                  <div className="font-bold text-slate-200">{bank.holderName}</div>
                  <div className="font-mono text-slate-400">Account Number: {bank.accountNumber}</div>
                  <div className="font-mono text-slate-400">IFSC Code: <span className="uppercase">{bank.ifsc}</span></div>
                  {bank.upiId && <div className="font-mono text-red-500/80">UPI ID: {bank.upiId}</div>}
                  <div className={`mt-1.5 px-2 py-0.5 rounded-full text-[8px] font-black uppercase inline-block ${
                    bank.isActive ? "bg-green-500/10 text-green-400 border border-green-500/20" : "bg-red-500/10 text-red-400 border border-red-500/20"
                  }`}>
                    {bank.isActive ? "Active Channel" : "Deactivated"}
                  </div>
                </div>

                {/* Bank channels are permanent and cannot be deleted once added */}
              </div>
            ))
          )}
        </div>
      </div>

      {/* Link Account Form */}
      <div className="bg-slate-900 border border-slate-800 rounded-3xl p-5 shadow-lg space-y-4">
        <div className="flex justify-between items-center">
          <h3 className="text-xs uppercase font-extrabold tracking-wider text-red-500 flex items-center gap-1.5">
            <Plus className="w-4 h-4 text-red-500" /> Link New Payee Channel
          </h3>
          
          <div className="flex bg-slate-950 p-1 rounded-xl border border-slate-850">
            <button
              onClick={() => setType("bank")}
              className={`px-3 py-1 rounded-lg text-[9px] font-black uppercase transition ${type === "bank" ? "bg-red-500 text-white" : "text-slate-500"}`}
            >
              Bank
            </button>
            <button
              onClick={() => setType("upi")}
              className={`px-3 py-1 rounded-lg text-[9px] font-black uppercase transition ${type === "upi" ? "bg-red-500 text-white" : "text-slate-500"}`}
            >
              UPI
            </button>
          </div>
        </div>

        <form onSubmit={handleAddBank} className="space-y-3 text-xs">
          <div>
            <label className="block text-slate-400 font-semibold mb-1">Account Holder Name *</label>
            <input
              type="text"
              required
              value={holderName}
              onChange={(e) => setHolderName(e.target.value)}
              placeholder="e.g. John Doe"
              className="w-full bg-slate-950 border border-slate-850 focus:border-red-500 rounded-xl px-4 py-2.5 text-slate-200 outline-none transition"
            />
          </div>

          {type === "bank" ? (
            <>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-400 font-semibold mb-1">Bank Name *</label>
                  <input
                    type="text"
                    required
                    value={bankName}
                    onChange={(e) => setBankName(e.target.value)}
                    placeholder="e.g. HDFC Bank"
                    className="w-full bg-slate-950 border border-slate-850 focus:border-red-500 rounded-xl px-4 py-2.5 text-slate-200 outline-none transition"
                  />
                </div>
                <div>
                  <label className="block text-slate-400 font-semibold mb-1">IFSC Code *</label>
                  <input
                    type="text"
                    required
                    value={ifsc}
                    onChange={(e) => setIfsc(e.target.value.toUpperCase())}
                    placeholder="e.g. HDFC0000124"
                    className="w-full bg-slate-950 border border-slate-850 focus:border-red-500 rounded-xl px-4 py-2.5 text-slate-200 font-mono outline-none transition placeholder:normal-case"
                  />
                </div>
              </div>

              <div>
                <label className="block text-slate-400 font-semibold mb-1">Account Number *</label>
                <input
                  type="text"
                  required
                  value={accountNumber}
                  onChange={(e) => setAccountNumber(e.target.value.replace(/\D/g, ""))}
                  placeholder="Bank Account Number"
                  className="w-full bg-slate-950 border border-slate-850 focus:border-red-500 rounded-xl px-4 py-2.5 text-slate-200 font-mono outline-none transition"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-400 font-semibold mb-1">ATM Card Number</label>
                  <input
                    type="text"
                    value={cardNumber}
                    onChange={(e) => setCardNumber(e.target.value.replace(/\D/g, "").slice(0, 16))}
                    placeholder="16-digit card number"
                    className="w-full bg-slate-950 border border-slate-850 focus:border-red-500 rounded-xl px-4 py-2.5 text-slate-200 font-mono outline-none transition"
                  />
                </div>
                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <label className="block text-slate-400 font-semibold mb-1">Expiry</label>
                    <input
                      type="text"
                      value={expiryDate}
                      onChange={(e) => setExpiryDate(e.target.value)}
                      placeholder="MM/YY"
                      className="w-full bg-slate-950 border border-slate-850 focus:border-red-500 rounded-xl px-2 py-2.5 text-slate-200 font-mono outline-none transition"
                    />
                  </div>
                  <div>
                    <label className="block text-slate-400 font-semibold mb-1">CVV</label>
                    <input
                      type="password"
                      value={cvv}
                      onChange={(e) => setCvv(e.target.value.replace(/\D/g, "").slice(0, 3))}
                      placeholder="***"
                      className="w-full bg-slate-950 border border-slate-850 focus:border-red-500 rounded-xl px-2 py-2.5 text-slate-200 font-mono outline-none transition"
                    />
                  </div>
                </div>
              </div>

              <div>
                <label className="block text-slate-400 font-semibold mb-1">UPI PIN (Optional)</label>
                <input
                  type="password"
                  value={upiPin}
                  onChange={(e) => setUpiPin(e.target.value.replace(/\D/g, "").slice(0, 6))}
                  placeholder="4 or 6 digit PIN"
                  className="w-full bg-slate-950 border border-slate-850 focus:border-red-500 rounded-xl px-4 py-2.5 text-slate-200 font-mono outline-none transition"
                />
              </div>

              <div>
                <label className="block text-slate-400 font-semibold mb-1">UPI ID (Optional)</label>
                <input
                  type="text"
                  value={upiId}
                  onChange={(e) => setUpiId(e.target.value)}
                  placeholder="e.g. john@okaxis"
                  className="w-full bg-slate-950 border border-slate-850 focus:border-red-500 rounded-xl px-4 py-2.5 text-slate-200 font-mono outline-none transition lowercase placeholder:normal-case"
                />
              </div>
            </>
          ) : (
            <div>
              <label className="block text-slate-400 font-semibold mb-1">UPI Address / ID *</label>
              <input
                type="text"
                required
                value={upiId}
                onChange={(e) => setUpiId(e.target.value)}
                placeholder="e.g. john@okaxis"
                className="w-full bg-slate-950 border border-slate-850 focus:border-red-500 rounded-xl px-4 py-2.5 text-slate-200 font-mono outline-none transition lowercase placeholder:normal-case"
              />
            </div>
          )}

          <button
            type="submit"
            disabled={loading}
            className="w-full bg-gradient-to-r from-red-500 to-rose-600 hover:from-red-400 hover:to-rose-500 text-white font-extrabold py-3 px-4 rounded-xl shadow-lg transition duration-200 text-xs mt-2"
          >
            {loading ? "Adding payee details..." : "Save Payee Account"}
          </button>
        </form>
      </div>
    </div>
  );
}
