export default function Support() {
  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-2xl font-bold text-white mb-2">Support Tickets</h1>
        <p className="text-neutral-400">Get help with your account or transactions.</p>
      </div>

      <div className="bg-neutral-950 border border-neutral-800 rounded-2xl p-8 text-center">
        <h2 className="text-xl font-bold text-white mb-3">Support feature coming soon</h2>
        <p className="text-neutral-400 max-w-md mx-auto">
          We are currently building the support ticketing system. If you need immediate assistance, please email our team at support@vaultex.example.com.
        </p>
      </div>
    </div>
  );
}
