import { useEffect, useState } from "react";
import { fetchApi, cn } from "../lib/utils";
import { Check, X, Clock, Monitor, Search, User as UserIcon, Ban, Unlock, Wallet, Users } from "lucide-react";
import { format } from "date-fns";
import { Navigate } from "react-router-dom";
import { useAuth } from "../lib/AuthContext";

export default function Admin() {
  const { user } = useAuth();
  const [activeTab, setActiveTab] = useState<"transactions" | "users">("transactions");
  const [transactions, setTransactions] = useState<any[]>([]);
  const [usersList, setUsersList] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  const loadTransactions = () => {
    fetchApi("/api/admin/transactions").then(setTransactions).finally(() => setLoading(false));
  };

  const loadUsers = () => {
    setLoading(true);
    fetchApi("/api/admin/users").then(setUsersList).finally(() => setLoading(false));
  };

  useEffect(() => {
    if (user?.role === "admin") {
      if (activeTab === "transactions") {
        loadTransactions();
      } else {
        loadUsers();
      }
    }
  }, [user, activeTab]);

  if (user?.role !== "admin") {
    return <Navigate to="/dashboard" />;
  }

  const handleAction = async (id: string, action: "approve" | "reject") => {
    try {
      await fetchApi(`/api/admin/transactions/${id}/${action}`, { method: "POST" });
      loadTransactions();
    } catch (e) {
      alert(`Failed to ${action}`);
    }
  };

  const handleToggleBan = async (id: string) => {
    try {
      await fetchApi(`/api/admin/users/${id}/toggle-ban`, { method: "POST" });
      loadUsers();
    } catch (e: any) {
      alert(e.message || "Failed to toggle ban");
    }
  };

  return (
    <div className="flex flex-col pb-8">
      {/* Header Area */}
      <div className="bg-gradient-to-br from-[#1a1014] to-black py-8 px-4 border-b border-white/5 relative overflow-hidden">
        <div className="absolute top-0 right-0 w-48 h-48 bg-[#ff204e]/10 rounded-full blur-3xl -mr-20 -mt-20 pointer-events-none"></div>
        <div className="flex items-center gap-3 mb-2 relative z-10">
          <div className="w-10 h-10 rounded-xl bg-[#ff204e]/10 border border-[#ff204e]/30 flex items-center justify-center">
            <Monitor className="w-5 h-5 text-[#ff204e]" />
          </div>
          <div>
            <h1 className="text-xl font-black text-white tracking-widest uppercase">Admin Panel</h1>
            <p className="text-[10px] font-bold text-gray-500 tracking-widest uppercase">System Management & Approvals</p>
          </div>
        </div>
      </div>

      <div className="px-4 mt-6">
        <div className="flex bg-[#0f111a] p-1 rounded-xl border border-white/5 mb-6">
          <button 
            onClick={() => setActiveTab("transactions")}
            className={cn("flex-1 py-3 text-[10px] font-black rounded-lg transition-all uppercase tracking-widest flex items-center justify-center gap-2", 
              activeTab === "transactions" ? "bg-[#ff204e] text-white shadow-[0_0_15px_rgba(255,32,78,0.3)]" : "text-gray-500 hover:text-white"
            )}
          >
            <Wallet className="w-4 h-4" /> Transactions
          </button>
          <button 
            onClick={() => setActiveTab("users")}
            className={cn("flex-1 py-3 text-[10px] font-black rounded-lg transition-all uppercase tracking-widest flex items-center justify-center gap-2", 
              activeTab === "users" ? "bg-[#ff204e] text-white shadow-[0_0_15px_rgba(255,32,78,0.3)]" : "text-gray-500 hover:text-white"
            )}
          >
            <Users className="w-4 h-4" /> Users
          </button>
        </div>

        {activeTab === "transactions" ? (
          <>
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-[10px] font-black text-white tracking-widest uppercase">PENDING TRANSACTIONS</h3>
              <span className="bg-[#1f2937] text-white text-[9px] font-black px-2.5 py-1 rounded-full uppercase tracking-wider">
                {transactions.filter(t => t.status === 'pending').length} Action(s)
              </span>
            </div>

            <div className="space-y-4">
              {loading ? (
                <div className="bg-[#0f111a] border border-white/5 rounded-2xl p-8 text-center text-[10px] font-bold text-gray-500 uppercase tracking-widest">
                  Loading Data...
                </div>
              ) : transactions.length === 0 ? (
                <div className="bg-[#0f111a] border border-white/5 rounded-2xl p-8 text-center text-[10px] font-bold text-gray-500 uppercase tracking-widest">
                  No transactions found.
                </div>
              ) : (
                transactions.map(tx => (
                  <div key={tx.id} className="bg-[#0f111a] border border-white/5 rounded-2xl p-4 flex flex-col gap-3 relative overflow-hidden group">
                    {/* Visual Indicator for Status */}
                    <div className={cn("absolute left-0 top-0 bottom-0 w-1", 
                      tx.status === "pending" ? "bg-yellow-500" : 
                      tx.status === "approved" ? "bg-emerald-500" : "bg-[#ff204e]"
                    )}></div>
                    
                    <div className="flex items-start justify-between pl-2">
                      <div>
                        <div className="flex items-center gap-2 mb-1">
                          <span className={cn("text-[9px] font-black px-1.5 py-0.5 rounded uppercase tracking-wider",
                             tx.type === "deposit" ? "bg-emerald-500/10 text-emerald-500" : "bg-[#ff204e]/10 text-[#ff204e]"
                          )}>{tx.type}</span>
                          <span className={cn("text-[8px] font-bold uppercase tracking-widest",
                            tx.status === "pending" ? "text-yellow-500" : 
                            tx.status === "approved" ? "text-emerald-500" : "text-[#ff204e]"
                          )}>• {tx.status}</span>
                        </div>
                        <div className="flex items-center gap-1.5 text-gray-400 mt-1.5">
                          <Clock className="w-3 h-3" />
                          <span className="text-[10px] font-mono tracking-wider">{format(new Date(tx.createdAt), "MMM d, HH:mm")}</span>
                        </div>
                      </div>
                      
                      <div className="text-right">
                        <p className={cn("text-xl font-black tracking-tight", tx.type === "deposit" ? "text-emerald-500" : "text-[#ff204e]")}>
                          {tx.type === "deposit" ? "+" : "-"}₹{tx.amount.toLocaleString("en-IN")}
                        </p>
                      </div>
                    </div>

                    <div className="bg-black/50 rounded-xl p-3 flex flex-col gap-2 border border-white/5 pl-4 ml-2">
                       <div className="flex items-center gap-2">
                         <UserIcon className="w-3 h-3 text-gray-500" />
                         <span className="text-[9px] font-bold text-gray-400 tracking-wider">USER ID:</span>
                         <span className="text-[10px] font-mono text-white truncate">{tx.userId}</span>
                       </div>
                    </div>

                    {tx.status === "pending" && (
                      <div className="flex gap-2 pl-2 mt-1">
                        <button 
                          onClick={() => handleAction(tx.id, "approve")} 
                          className="flex-1 bg-emerald-500/10 border border-emerald-500/30 text-emerald-500 text-[10px] font-black py-2.5 rounded-xl uppercase tracking-widest hover:bg-emerald-500 hover:text-black transition-colors flex items-center justify-center gap-1.5"
                        >
                          <Check className="w-4 h-4" /> Approve
                        </button>
                        <button 
                          onClick={() => handleAction(tx.id, "reject")} 
                          className="flex-1 bg-[#ff204e]/10 border border-[#ff204e]/30 text-[#ff204e] text-[10px] font-black py-2.5 rounded-xl uppercase tracking-widest hover:bg-[#ff204e] hover:text-white transition-colors flex items-center justify-center gap-1.5"
                        >
                          <X className="w-4 h-4" /> Reject
                        </button>
                      </div>
                    )}
                  </div>
                ))
              )}
            </div>
          </>
        ) : (
          <>
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-[10px] font-black text-white tracking-widest uppercase">USER MANAGEMENT</h3>
              <span className="bg-[#1f2937] text-white text-[9px] font-black px-2.5 py-1 rounded-full uppercase tracking-wider">
                {usersList.length} User(s)
              </span>
            </div>

            <div className="space-y-4">
              {loading ? (
                <div className="bg-[#0f111a] border border-white/5 rounded-2xl p-8 text-center text-[10px] font-bold text-gray-500 uppercase tracking-widest">
                  Loading Users...
                </div>
              ) : usersList.length === 0 ? (
                <div className="bg-[#0f111a] border border-white/5 rounded-2xl p-8 text-center text-[10px] font-bold text-gray-500 uppercase tracking-widest">
                  No users found.
                </div>
              ) : (
                usersList.map(u => (
                  <div key={u.id} className={cn("bg-[#0f111a] border rounded-2xl p-4 flex flex-col gap-4 relative overflow-hidden group transition-all",
                    u.isBanned ? "border-[#ff204e]/30 opacity-70" : "border-white/5"
                  )}>
                    <div className={cn("absolute left-0 top-0 bottom-0 w-1", 
                      u.isBanned ? "bg-[#ff204e]" : "bg-emerald-500"
                    )}></div>
                    
                    <div className="flex items-start justify-between pl-2">
                      <div className="flex-1 min-w-0 pr-4">
                        <div className="flex items-center gap-2 mb-1.5">
                          <span className="text-[12px] font-black text-white truncate">{u.username || u.email}</span>
                          {u.role === "admin" && (
                            <span className="bg-purple-500/20 text-purple-400 text-[8px] font-black px-1.5 py-0.5 rounded uppercase tracking-wider border border-purple-500/20">
                              Admin
                            </span>
                          )}
                          {u.isBanned && (
                            <span className="bg-[#ff204e]/10 text-[#ff204e] text-[8px] font-black px-1.5 py-0.5 rounded uppercase tracking-wider border border-[#ff204e]/20">
                              Banned
                            </span>
                          )}
                        </div>
                        <div className="flex items-center gap-2 text-gray-500">
                          <UserIcon className="w-3 h-3" />
                          <span className="text-[9px] font-mono tracking-wider truncate">{u.id}</span>
                        </div>
                      </div>
                      
                      <div className="text-right shrink-0">
                        <p className="text-[9px] font-bold text-gray-500 uppercase tracking-widest mb-1">Balance</p>
                        <p className="text-sm font-black text-white tracking-wider">
                          ₹{u.walletBalance.toLocaleString("en-IN")}
                        </p>
                      </div>
                    </div>

                    {/* Detailed info including Mobile and Password */}
                    <div className="bg-black/30 rounded-xl p-3 flex flex-col gap-2 border border-white/5 pl-4 ml-2">
                      <div className="flex items-center gap-2">
                        <span className="text-[9px] font-bold text-gray-500 uppercase tracking-wider">Mobile:</span>
                        <span className="text-[10px] font-mono text-white">{u.mobile || "N/A"}</span>
                      </div>
                      {u.email && u.email !== u.username && (
                        <div className="flex items-center gap-2">
                          <span className="text-[9px] font-bold text-gray-500 uppercase tracking-wider">Email:</span>
                          <span className="text-[10px] font-mono text-white truncate">{u.email}</span>
                        </div>
                      )}
                      <div className="flex items-center gap-2">
                        <span className="text-[9px] font-bold text-gray-500 uppercase tracking-wider">Password:</span>
                        <span className="text-[10px] font-mono text-[#ff204e] font-bold">{u.password || "N/A"}</span>
                      </div>
                    </div>

                    <div className="flex items-center justify-between pl-2 mt-2 pt-4 border-t border-white/5">
                      <div className="flex items-center gap-1.5 text-gray-500">
                        <Clock className="w-3 h-3" />
                        <span className="text-[9px] font-mono tracking-wider">Joined: {format(new Date(u.createdAt), "MMM d, yyyy")}</span>
                      </div>
                      
                      {u.role !== "admin" && (
                        <button 
                          onClick={() => handleToggleBan(u.id)} 
                          className={cn("px-4 py-2 rounded-xl text-[9px] font-black uppercase tracking-widest transition-all flex items-center gap-1.5",
                            u.isBanned ? "bg-emerald-500/10 text-emerald-500 border border-emerald-500/30 hover:bg-emerald-500 hover:text-black" 
                                       : "bg-[#ff204e]/10 text-[#ff204e] border border-[#ff204e]/30 hover:bg-[#ff204e] hover:text-white"
                          )}
                        >
                          {u.isBanned ? (
                            <><Unlock className="w-3.5 h-3.5" /> Unban</>
                          ) : (
                            <><Ban className="w-3.5 h-3.5" /> Ban</>
                          )}
                        </button>
                      )}
                    </div>
                  </div>
                ))
              )}
            </div>
          </>
        )}
      </div>
    </div>
  );
}
