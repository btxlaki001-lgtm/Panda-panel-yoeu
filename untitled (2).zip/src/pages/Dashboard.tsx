import React, { useEffect, useState } from "react";
import { useAuth } from "../lib/AuthContext";
import { fetchApi, cn } from "../lib/utils";
import { ArrowDownToLine, ArrowUpFromLine, Clock, Headset, ShieldCheck, Bitcoin, Send, Plus, Users, Smartphone, Download, Settings } from "lucide-react";
import { Link } from "react-router-dom";
import { format } from "date-fns";

function ActionBox({ icon: Icon, label, to }: { icon: any, label: string, to: string }) {
  return (
    <Link to={to} className="bg-[#0f111a] border border-white/5 rounded-2xl p-3 flex flex-col items-center justify-center gap-2 hover:bg-[#1a1d2d] transition-colors">
      <Icon className="w-5 h-5 text-blue-500/80" />
      <span className="text-[9px] font-bold text-gray-500 tracking-wider uppercase text-center">{label}</span>
    </Link>
  );
}

export default function Dashboard() {
  const { user } = useAuth();
  const [transactions, setTransactions] = useState<any[]>([]);
  const [bankAccounts, setBankAccounts] = useState<any[]>([]);
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    fetchApi("/api/wallet/transactions").then(setTransactions).catch(() => {});
    fetchApi("/api/bank-accounts").then(setBankAccounts).catch(() => {});
  }, []);

  const handleCopyReferral = () => {
    navigator.clipboard.writeText(user?.referralCode || "PANDAADMIN");
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="flex flex-col">
      {/* Marquee */}
      <div className="bg-black py-2.5 border-b border-white/5 overflow-hidden flex items-center">
        <span className="text-[#ff204e] text-xs font-black uppercase tracking-[0.25em] whitespace-nowrap animate-marquee">
          WITHDRAWALS ACTIVE • PLAY AND WIN • SECURE PANEL • FAST PAYOUTS • 
        </span>
      </div>

      {/* Admin Panel Warning */}
      {user?.role === "admin" && (
        <div className="mx-4 mt-4 bg-[#0f111a] border border-white/10 rounded-2xl p-3 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Settings className="w-5 h-5 text-[#ff204e]" />
            <div>
              <p className="text-sm font-bold text-white tracking-wide">Control Panel Loaded</p>
              <p className="text-[9px] font-medium text-gray-400 mt-0.5 uppercase tracking-wide">Manage deposits, withdraws & site settings</p>
            </div>
          </div>
          <Link to="/admin" className="bg-[#ff204e] text-white text-[10px] font-black px-3 py-1.5 rounded-full uppercase tracking-wider shrink-0">
            Admin Panel
          </Link>
        </div>
      )}

      {/* Balance Card */}
      <div className="mx-4 mt-4 mb-6 bg-gradient-to-br from-[#ff204e] to-[#c70b31] rounded-3xl p-6 shadow-[0_8px_30px_-5px_rgba(255,32,78,0.4)] relative overflow-hidden">
        <div className="absolute top-0 right-0 w-32 h-32 bg-white/20 rounded-full blur-3xl -mr-10 -mt-10 pointer-events-none"></div>
        <div className="flex justify-between items-start mb-6 relative z-10">
          <div className="text-white text-[10px] font-bold uppercase tracking-widest leading-tight">
            Panda Panel<br/>Balance
          </div>
          <div className="bg-emerald-500 text-white text-[9px] font-black px-2.5 py-1 rounded-full uppercase tracking-widest shadow-sm">
            10% COMMISSION
          </div>
        </div>
        <div className="text-5xl font-black text-white tracking-tight relative z-10">
          ₹{user?.walletBalance.toLocaleString("en-IN", { maximumFractionDigits: 2 }) || "0"}
        </div>
      </div>

      {/* Actions Grid */}
      <div className="px-4 grid grid-cols-[1.2fr_1fr] gap-3 mb-8">
        <div className="grid grid-cols-2 gap-2">
          <ActionBox to="/wallet" icon={ArrowDownToLine} label="Deposit" />
          <ActionBox to="/wallet" icon={ArrowUpFromLine} label="Withdraw" />
          <ActionBox to="/dashboard" icon={Clock} label="History" />
          <ActionBox to="/support" icon={Headset} label="Support" />
          <ActionBox to="/dashboard" icon={ShieldCheck} label="Activate" />
          <ActionBox to="/dashboard" icon={Bitcoin} label="USDT Exch" />
        </div>
        <div className="flex flex-col gap-2">
          <div className="bg-[#0f111a] border border-white/5 rounded-2xl p-4 flex flex-col justify-center flex-1 relative overflow-hidden">
            <p className="text-[8px] text-blue-400/80 font-black mb-1.5 tracking-widest uppercase">EARNED COMMISSION</p>
            <p className="text-2xl font-black text-[#ff204e]">₹{Number(user?.totalEarnings || 0).toLocaleString("en-IN", { maximumFractionDigits: 2 })}</p>
          </div>
          <div className="bg-[#0f111a] border border-white/5 rounded-2xl p-4 flex flex-col items-center justify-center flex-1 cursor-pointer hover:bg-[#1a1d2d] transition-colors">
            <Send className="w-6 h-6 text-[#ff204e] mb-1.5" />
            <p className="text-[9px] font-black text-gray-500 tracking-widest uppercase">TELEGRAM</p>
          </div>
        </div>
      </div>

      {/* Bank Accounts Header */}
      <div className="px-4 mb-3 flex items-center justify-between">
        <h3 className="text-[10px] font-black text-white tracking-widest">BANK ACCOUNTS</h3>
        <Link to="/bank-accounts" className="flex items-center gap-1 border border-[#ff204e]/30 bg-[#ff204e]/10 text-[#ff204e] px-2 py-1 rounded-full text-[9px] font-bold uppercase tracking-wider">
          <Plus className="w-3 h-3" /> ADD
        </Link>
      </div>
      <div className="px-4 mb-8">
        {bankAccounts.length > 0 ? (
          bankAccounts.map(acc => (
            <div key={acc.id} className="bg-[#0f111a] border border-white/5 rounded-2xl p-4 flex items-center justify-between hover:bg-[#1a1d2d] transition-colors cursor-pointer mb-2">
              <div>
                <div className="flex items-center gap-2 mb-1.5">
                  <span className="text-[#ff204e] text-xs font-black tracking-wider uppercase">{acc.bankName}</span>
                  <span className="bg-emerald-500/20 text-emerald-400 text-[8px] font-black px-1.5 py-0.5 rounded uppercase tracking-wider">Active</span>
                </div>
                <p className="text-white text-sm font-bold tracking-wide">{acc.accountName}</p>
                <p className="text-gray-500 text-xs font-mono mt-0.5 tracking-wider">••••{acc.accountNumber.slice(-4)}</p>
              </div>
            </div>
          ))
        ) : (
          <Link to="/bank-accounts" className="bg-[#0f111a] border border-dashed border-white/10 rounded-2xl p-6 flex flex-col items-center justify-center text-center hover:bg-[#1a1d2d] transition-colors">
            <p className="text-gray-400 text-xs font-bold uppercase tracking-wider">No linked bank accounts yet.</p>
            <p className="text-gray-600 text-[10px] font-bold uppercase tracking-widest mt-1">Tap to link a bank account for instant withdrawals</p>
          </Link>
        )}
      </div>

      {/* Split Data Display */}
      <div className="px-4 grid grid-cols-2 gap-3 mb-8">
        {/* Top Investors */}
        <div>
          <div className="flex items-center gap-2 mb-3">
            <h3 className="text-[9px] font-black text-white tracking-widest">TOP INVESTORS</h3>
            <span className="bg-[#ff204e] text-white text-[7px] font-black px-1.5 py-0.5 rounded-full uppercase tracking-wider">LIVE</span>
          </div>
          <div className="bg-[#0f111a] border border-white/5 rounded-2xl p-4 space-y-4">
            {[
              { id: "01", name: "Arun V.", amount: "₹85,000" },
              { id: "02", name: "Rahul S.", amount: "₹62,400" },
              { id: "03", name: "Deepak K.", amount: "₹54,200" },
              { id: "04", name: "Amit P.", amount: "₹48,900" },
            ].map(inv => (
              <div key={inv.id} className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span className="text-[#ff204e] text-[9px] font-black bg-[#ff204e]/10 px-1.5 py-0.5 rounded">{inv.id}</span>
                  <span className="text-white text-[10px] font-bold truncate max-w-[50px]">{inv.name}</span>
                </div>
                <span className="text-[#ff204e] text-[10px] font-black">{inv.amount}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Transaction History */}
        <div>
          <div className="flex items-center justify-between mb-3">
            <h3 className="text-[9px] font-black text-white tracking-widest leading-tight">TRANSACTION<br/>HISTORY</h3>
            <span className="bg-[#1f2937] text-white text-[7px] font-black px-2 py-1 rounded-full uppercase tracking-wider">AUTO-SYNC</span>
          </div>
          <div className="bg-[#0f111a] border border-white/5 rounded-2xl p-3 relative h-[155px] overflow-hidden flex flex-col">
             <div className="flex items-center gap-1.5 mb-3 text-gray-500 shrink-0">
               <Clock className="w-3 h-3" />
               <span className="text-[8px] font-bold tracking-widest">REAL-TIME RECORDS</span>
             </div>
             <div className="flex-1 overflow-y-auto hide-scrollbar pr-1 space-y-3.5">
                {transactions.length > 0 ? transactions.map(tx => (
                  <div key={tx.id} className="flex justify-between items-center">
                     <div>
                       <p className="text-white text-[10px] font-bold capitalize tracking-wide">{tx.type}</p>
                       <p className="text-gray-500 text-[8px] font-bold uppercase tracking-widest mt-0.5">{tx.status}</p>
                     </div>
                     <div className="text-right">
                       <p className="text-gray-500 text-[8px] font-mono mb-0.5 tracking-wider">{format(new Date(tx.createdAt), "HH:mm")}</p>
                       <p className={cn("text-[10px] font-black tracking-wide", tx.type === "deposit" ? "text-emerald-500" : "text-[#ff204e]")}>
                          {tx.type === "deposit" ? "+" : "-"}₹{tx.amount.toLocaleString("en-IN")}
                       </p>
                     </div>
                  </div>
                )) : (
                  <p className="text-xs text-gray-600 font-bold text-center mt-4">No records yet.</p>
                )}
             </div>
          </div>
        </div>
      </div>

      {/* Referral Link */}
      <div className="px-4 mb-8">
        <div className="bg-[#0f111a] border border-white/5 rounded-2xl p-5">
          <div className="flex items-center justify-between mb-4">
             <div className="flex items-center gap-2">
               <Users className="w-4 h-4 text-[#ff204e]" />
               <span className="text-[10px] font-black text-white tracking-widest">REFERRAL LINK</span>
             </div>
             <span className="bg-[#ff204e] text-white text-[8px] font-black px-2 py-0.5 rounded-full uppercase tracking-wider shadow-[0_0_10px_rgba(255,32,78,0.5)]">LIVE</span>
          </div>
          <div className="bg-black rounded-xl p-1.5 flex items-center justify-between border border-white/10">
            <span className="text-gray-500 text-[11px] font-mono px-3 font-bold tracking-widest">{user?.referralCode || "PANDAADMIN"}</span>
            <button onClick={handleCopyReferral} className="bg-[#1f2937] text-white text-[9px] font-black px-4 py-2.5 rounded-lg uppercase tracking-widest hover:bg-gray-700 transition-colors">
              {copied ? "COPIED!" : "COPY"}
            </button>
          </div>
        </div>
      </div>

      {/* Decorative Panda Badge */}
      <div className="flex justify-center pb-8 opacity-80">
         <div className="w-20 h-20 rounded-[24px] bg-[#0f111a] border border-[#ff204e]/20 flex items-center justify-center text-3xl font-black text-white tracking-widest">PP</div>
      </div>

    </div>
  );
}
