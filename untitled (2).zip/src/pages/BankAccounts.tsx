import React, { useEffect, useState } from "react";
import { fetchApi } from "../lib/utils";
import { Building2, Plus } from "lucide-react";

export default function BankAccounts() {
  const [accounts, setAccounts] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [showAdd, setShowAdd] = useState(false);
  const [form, setForm] = useState({ accountName: "", accountNumber: "", bankName: "", routingNumber: "" });

  const loadAccounts = () => {
    fetchApi("/api/bank-accounts").then(setAccounts).finally(() => setLoading(false));
  };

  useEffect(() => {
    loadAccounts();
  }, []);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await fetchApi("/api/bank-accounts", {
        method: "POST",
        body: JSON.stringify(form),
      });
      setShowAdd(false);
      setForm({ accountName: "", accountNumber: "", bankName: "", routingNumber: "" });
      loadAccounts();
    } catch (e) {
      alert("Failed to add account");
    }
  };

  return (
    <div className="space-y-8">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold text-white mb-2">Bank Accounts</h1>
          <p className="text-neutral-400">Manage your linked accounts for withdrawals.</p>
        </div>
        {!showAdd && (
          <button onClick={() => setShowAdd(true)} className="flex items-center gap-2 bg-emerald-500 text-white px-4 py-2 rounded-xl font-medium hover:bg-emerald-600 transition-colors">
            <Plus className="w-5 h-5" /> Add Account
          </button>
        )}
      </div>

      {showAdd && (
        <div className="bg-neutral-950 border border-neutral-800 rounded-2xl p-6">
          <h2 className="text-lg font-bold text-white mb-4">Add New Bank Account</h2>
          <form onSubmit={handleSubmit} className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-neutral-400 mb-1">Account Holder Name</label>
              <input required value={form.accountName} onChange={(e) => setForm({...form, accountName: e.target.value})} className="w-full bg-neutral-900 border border-neutral-800 rounded-xl py-2 px-3 text-white focus:ring-2 focus:ring-emerald-500 focus:outline-none" />
            </div>
            <div>
              <label className="block text-sm font-medium text-neutral-400 mb-1">Bank Name</label>
              <input required value={form.bankName} onChange={(e) => setForm({...form, bankName: e.target.value})} className="w-full bg-neutral-900 border border-neutral-800 rounded-xl py-2 px-3 text-white focus:ring-2 focus:ring-emerald-500 focus:outline-none" />
            </div>
            <div>
              <label className="block text-sm font-medium text-neutral-400 mb-1">Account Number</label>
              <input required value={form.accountNumber} onChange={(e) => setForm({...form, accountNumber: e.target.value})} className="w-full bg-neutral-900 border border-neutral-800 rounded-xl py-2 px-3 text-white focus:ring-2 focus:ring-emerald-500 focus:outline-none" />
            </div>
            <div>
              <label className="block text-sm font-medium text-neutral-400 mb-1">Routing Number</label>
              <input required value={form.routingNumber} onChange={(e) => setForm({...form, routingNumber: e.target.value})} className="w-full bg-neutral-900 border border-neutral-800 rounded-xl py-2 px-3 text-white focus:ring-2 focus:ring-emerald-500 focus:outline-none" />
            </div>
            <div className="md:col-span-2 flex justify-end gap-3 mt-2">
              <button type="button" onClick={() => setShowAdd(false)} className="px-4 py-2 text-neutral-400 hover:text-white">Cancel</button>
              <button type="submit" className="px-6 py-2 bg-emerald-500 text-white rounded-xl font-medium hover:bg-emerald-600">Save Account</button>
            </div>
          </form>
        </div>
      )}

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {loading ? (
          <p className="text-neutral-500">Loading...</p>
        ) : accounts.length === 0 ? (
          <p className="text-neutral-500">No linked bank accounts.</p>
        ) : (
          accounts.map(acc => (
            <div key={acc.id} className="bg-neutral-950 border border-neutral-800 p-5 rounded-2xl flex items-start gap-4">
              <div className="w-10 h-10 rounded-full bg-neutral-900 flex items-center justify-center border border-neutral-800 shrink-0">
                <Building2 className="w-5 h-5 text-neutral-400" />
              </div>
              <div>
                <h3 className="text-white font-medium">{acc.bankName}</h3>
                <p className="text-neutral-400 text-sm mt-0.5">{acc.accountName}</p>
                <div className="mt-3 flex gap-4 text-sm">
                  <div className="text-neutral-500">
                    <span className="block text-xs uppercase tracking-wider mb-0.5">Account</span>
                    <span className="text-neutral-300">••••{acc.accountNumber.slice(-4)}</span>
                  </div>
                  <div className="text-neutral-500">
                    <span className="block text-xs uppercase tracking-wider mb-0.5">Routing</span>
                    <span className="text-neutral-300">{acc.routingNumber}</span>
                  </div>
                </div>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
}
