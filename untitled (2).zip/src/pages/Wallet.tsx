import React, { useState, useEffect } from "react";
import { useAuth } from "../lib/AuthContext";
import { fetchApi, cn } from "../lib/utils";
import { ArrowDownToLine, ArrowUpFromLine, Clock, CheckCircle2, XCircle } from "lucide-react";
import { format } from "date-fns";

export default function Wallet() {
  const { user, refreshUser } = useAuth();
  const [activeTab, setActiveTab] = useState<"deposit" | "withdraw">("deposit");
  const [amount, setAmount] = useState("");
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState("");
  const [transactions, setTransactions] = useState<any[]>([]);

  const loadTransactions = () => {
    fetchApi("/api/wallet/transactions").then(setTransactions);
  };

  useEffect(() => {
    loadTransactions();
  }, []);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setMessage("");
    try {
      await fetchApi(`/api/wallet/${activeTab}`, {
        method: "POST",
        body: JSON.stringify({ amount: parseFloat(amount) }),
      });
      setMessage(`${activeTab === "deposit" ? "Deposit" : "Withdrawal"} request submitted successfully!`);
      setAmount("");
      loadTransactions();
      refreshUser();
    } catch (err: any) {
      setMessage(err.message || "Failed to submit request");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="flex flex-col pb-6">
      {/* Header Area */}
      <div className="bg-gradient-to-br from-[#1a1014] to-black py-8 px-4 border-b border-white/5 relative overflow-hidden">
        <div className="absolute top-0 right-0 w-48 h-48 bg-[#ff204e]/10 rounded-full blur-3xl -mr-20 -mt-20 pointer-events-none"></div>
        <div className="flex items-center gap-3 mb-2 relative z-10">
          <div className="w-10 h-10 rounded-xl bg-black border border-white/10 flex items-center justify-center">
            {activeTab === "deposit" ? <ArrowDownToLine className="w-5 h-5 text-emerald-500" /> : <ArrowUpFromLine className="w-5 h-5 text-[#ff204e]" />}
          </div>
          <div>
            <h1 className="text-xl font-black text-white tracking-widest uppercase">Wallet Actions</h1>
            <p className="text-[10px] font-bold text-gray-500 tracking-widest uppercase">Request deposits or withdrawals</p>
          </div>
        </div>
      </div>

      <div className="px-4 mt-6">
        <div className="bg-[#0f111a] border border-white/5 rounded-2xl p-4 mb-6 relative overflow-hidden">
          <div className="absolute top-0 right-0 w-32 h-32 bg-[#ff204e]/5 rounded-full blur-3xl -mr-10 -mt-10 pointer-events-none"></div>
          
          <div className="flex gap-2 mb-6 bg-black p-1.5 rounded-xl border border-white/5 relative z-10">
            <button
              onClick={() => { setActiveTab("deposit"); setMessage(""); }}
              className={cn("flex-1 py-2.5 text-[10px] font-black rounded-lg transition-all uppercase tracking-widest flex items-center justify-center gap-1.5", 
                activeTab === "deposit" ? "bg-emerald-500 text-black shadow-[0_0_15px_rgba(16,185,129,0.3)]" : "text-gray-500 hover:text-white")}
            >
              <ArrowDownToLine className="w-3.5 h-3.5" /> Deposit
            </button>
            <button
              onClick={() => { setActiveTab("withdraw"); setMessage(""); }}
              className={cn("flex-1 py-2.5 text-[10px] font-black rounded-lg transition-all uppercase tracking-widest flex items-center justify-center gap-1.5", 
                activeTab === "withdraw" ? "bg-[#ff204e] text-white shadow-[0_0_15px_rgba(255,32,78,0.3)]" : "text-gray-500 hover:text-white")}
            >
              <ArrowUpFromLine className="w-3.5 h-3.5" /> Withdraw
            </button>
          </div>

          <form onSubmit={handleSubmit} className="space-y-4 relative z-10">
            <div>
              <label className="block text-[9px] font-black text-gray-400 mb-2 tracking-widest uppercase">Amount (INR)</label>
              <div className="relative">
                <span className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-500 font-bold">₹</span>
                <input
                  type="number"
                  min="1"
                  step="1"
                  required
                  value={amount}
                  onChange={(e) => setAmount(e.target.value)}
                  className="w-full bg-black border border-white/10 rounded-xl py-3 pl-8 pr-4 text-white text-sm font-bold focus:outline-none focus:border-[#ff204e] transition-colors"
                  placeholder="0"
                />
              </div>
            </div>

            {message && (
              <div className={cn("p-3 rounded-xl text-[10px] font-bold uppercase tracking-wider text-center border",
                message.includes("success") ? "bg-emerald-500/10 text-emerald-400 border-emerald-500/20" : "bg-red-500/10 text-red-400 border-red-500/20"
              )}>
                {message}
              </div>
            )}

            <button
              disabled={loading || !amount}
              className={cn("w-full font-black py-3 rounded-xl uppercase tracking-widest transition-all text-[11px]",
                activeTab === "deposit" ? "bg-emerald-500 hover:bg-emerald-400 text-black shadow-[0_0_15px_rgba(16,185,129,0.3)] disabled:opacity-50" : 
                "bg-[#ff204e] hover:bg-[#ff406e] text-white shadow-[0_0_15px_rgba(255,32,78,0.3)] disabled:opacity-50"
              )}
            >
              {loading ? "Processing..." : `Submit ${activeTab === "deposit" ? "Deposit" : "Withdrawal"}`}
            </button>
          </form>
        </div>

        <div className="flex items-center justify-between mb-4">
          <h3 className="text-[10px] font-black text-white tracking-widest uppercase">TRANSACTION HISTORY</h3>
        </div>

        <div className="bg-[#0f111a] border border-white/5 rounded-2xl p-4">
          <div className="space-y-4">
            {transactions.length === 0 ? (
              <p className="text-gray-500 text-[10px] font-bold uppercase tracking-widest text-center py-4">No transactions found.</p>
            ) : (
              transactions.map((tx) => (
                <div key={tx.id} className="flex items-center justify-between relative overflow-hidden pb-4 border-b border-white/5 last:border-0 last:pb-0">
                  <div className="flex items-center gap-3">
                    <div className={cn("w-8 h-8 rounded-xl flex items-center justify-center border",
                      tx.type === "deposit" ? "bg-emerald-500/10 border-emerald-500/20 text-emerald-500" : "bg-[#ff204e]/10 border-[#ff204e]/20 text-[#ff204e]"
                    )}>
                      {tx.type === "deposit" ? <ArrowDownToLine className="w-4 h-4" /> : <ArrowUpFromLine className="w-4 h-4" />}
                    </div>
                    <div>
                      <p className="text-xs text-white font-black capitalize tracking-wider">{tx.type}</p>
                      <div className="flex items-center gap-1.5 mt-0.5">
                        {tx.status === "pending" && <Clock className="w-2.5 h-2.5 text-yellow-500" />}
                        {tx.status === "approved" && <CheckCircle2 className="w-2.5 h-2.5 text-emerald-500" />}
                        {tx.status === "rejected" && <XCircle className="w-2.5 h-2.5 text-[#ff204e]" />}
                        <p className={cn("text-[8px] font-bold uppercase tracking-widest",
                          tx.status === "pending" ? "text-yellow-500" :
                          tx.status === "approved" ? "text-emerald-500" : "text-[#ff204e]"
                        )}>{tx.status}</p>
                      </div>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className={cn("text-sm font-black tracking-wider", tx.type === "deposit" ? "text-emerald-500" : "text-[#ff204e]")}>
                      {tx.type === "deposit" ? "+" : "-"}₹{tx.amount.toLocaleString("en-IN")}
                    </p>
                    <p className="text-[9px] text-gray-500 font-mono tracking-wider mt-0.5">{format(new Date(tx.createdAt), "MMM d, HH:mm")}</p>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
