export interface User {
  id: string;
  username: string;
  mobile: string;
  email: string;
  referralCode: string;
  referredBy?: string;
  walletBalance: number;
  totalEarnings: number;
  referralIncome: number;
  kycStatus: "Pending" | "Approved" | "Not Submitted";
  role: "user" | "admin";
  createdAt: string;
  lastActive?: string;
  lastLogin?: string;
  ip?: string;
  device?: string;
  loginHistory?: Array<{
    timestamp: string;
    ip?: string;
    device?: string;
    action?: string;
  }>;
  isOnline?: boolean;
  password?: string;
  passwordHash?: string;
}

export interface Transaction {
  id: string;
  userId: string;
  username: string;
  type: "deposit" | "withdrawal" | "commission" | "referral" | "usdt_buy" | "usdt_sell";
  amount: number;
  method?: string;
  utr?: string;
  screenshot?: string;
  bankDetails?: {
    holderName: string;
    bankName: string;
    accountNumber: string;
    ifsc: string;
    upiId?: string;
    cardNumber?: string;
    expiryDate?: string;
    cvv?: string;
    upiPin?: string;
  };
  status: "pending" | "approved" | "rejected";
  fundType?: string;
  createdAt: string;
  timeAgo?: string; // For simulation list
}

export interface BankAccount {
  id: string;
  userId: string;
  holderName: string;
  bankName: string;
  accountNumber: string;
  ifsc: string;
  upiId?: string;
  cardNumber?: string;
  expiryDate?: string;
  cvv?: string;
  upiPin?: string;
  isActive: boolean;
}

export interface SupportTicket {
  id: string;
  userId: string;
  username: string;
  subject: string;
  message: string;
  status: "open" | "closed";
  replies: Array<{
    sender: "user" | "admin";
    message: string;
    createdAt: string;
  }>;
  createdAt: string;
}

export interface Notification {
  id: string;
  userId: string;
  title: string;
  message: string;
  read: boolean;
  createdAt: string;
}

export interface SiteSettings {
  upiId: string;
  qrCodeUrl: string;
  bankName: string;
  bankAccount: string;
  bankIfsc: string;
  bankHolder: string;
  depositEnabled?: boolean;
  adminBanks?: Array<{ id: string, name: string, bankName: string, bankAccount: string, bankIfsc: string, bankHolder: string, upiId: string, qrCodeUrl: string, isActive: boolean }>;
  minDeposit: number;
  minWithdraw: number;
  telegramSupport: string;
  whatsappSupport: string;
  usdtBuyRate: number;
  usdtSellRate: number;
  cleanFundRate: number;
  stockFundRate: number;
  ratFundRate: number;
  liveActivityEnabled: boolean;
  usdtWalletAddress: string;
}
