const fs = require("fs");
const users = JSON.parse(fs.readFileSync("all_184_users_full_data.json", "utf-8"));
const corrupted = users.filter(u => (!u.username || u.username.trim() === "" || u.username.toLowerCase().startsWith("user_") || u.username === "use" || u.username === "duser") && u.email && u.email.includes("PANDA"));

const map = {};

for (const u of corrupted) {
  let raw = u.email;
  let referralCode = "";
  let kycStatus = "Pending";
  let walletBalance = "0.00";
  let totalEarnings = "0.00";
  let referralIncome = "0.00";
  
  const pandaIdx = raw.indexOf("PANDA");
  if (pandaIdx !== -1) {
    let afterPanda = raw.substring(pandaIdx);
    
    // Extract numbers at the end
    const numericPart = afterPanda.replace(/(Approved|Pending|Not Submitted)?(user|admin|)$/, "");
    const decimals = numericPart.match(/\d+\.\d{2}/g);
    if (decimals) {
      if (decimals.length >= 1) walletBalance = decimals[0];
      if (decimals.length >= 2) totalEarnings = decimals[1];
      if (decimals.length >= 3) referralIncome = decimals[2];
    }
    
    // Extract referral code (usually right after PANDA, 10 chars)
    const codeMatch = afterPanda.match(/PANDA([A-Z0-9]{5,10})/);
    if (codeMatch) {
       referralCode = codeMatch[0];
    }
    
    if (afterPanda.includes("Approved")) kycStatus = "Approved";
    else if (afterPanda.includes("Pending")) kycStatus = "Pending";
    else if (afterPanda.includes("Not Submitted")) kycStatus = "Not Submitted";
  }
  
  let beforePanda = raw.substring(0, pandaIdx === -1 ? raw.length : pandaIdx);
  // remove ID
  if (beforePanda.startsWith(u.id)) beforePanda = beforePanda.substring(u.id.length);
  // remove ID random part
  beforePanda = beforePanda.replace(/^-[a-zA-Z0-9]{5}/, "");
  
  let username = `user_${u.id.slice(-5)}`;
  let mobile = "";
  let email = "";
  let passwordHash = "";
  
  const atIdx = beforePanda.lastIndexOf("@");
  if (atIdx !== -1) {
    const domainMatch = beforePanda.substring(atIdx).match(/^@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}/);
    if (domainMatch) {
      const emailEnd = atIdx + domainMatch[0].length;
      passwordHash = beforePanda.substring(emailEnd);
      
      const beforeAt = beforePanda.substring(0, atIdx);
      const mMatch = beforeAt.match(/(\+91|\s)?(\d{10})$/);
      if (mMatch) {
        mobile = mMatch[2];
        email = beforeAt.substring(mMatch.index + mMatch[0].length) + domainMatch[0];
        username = beforeAt.substring(0, mMatch.index);
      } else {
        const eMatch = beforeAt.match(/[a-zA-Z0-9._]+$/);
        if (eMatch) {
          email = eMatch[0] + domainMatch[0];
          const left = beforeAt.substring(0, eMatch.index);
          const mmMatch = left.match(/(\+91|\s)?(\d{10})$/);
          if (mmMatch) {
            mobile = mmMatch[2];
            username = left.substring(0, mmMatch.index);
          } else {
             username = left;
          }
        }
      }
    } else {
      // no domain
      const mMatch = beforePanda.match(/(\+91|\s)?(\d{10})/);
      if (mMatch) {
         mobile = mMatch[2];
         username = beforePanda.substring(0, mMatch.index);
         passwordHash = beforePanda.substring(mMatch.index + mMatch[0].length);
      }
    }
  } else {
      const mMatch = beforePanda.match(/(\+91|\s)?(\d{10})/);
      if (mMatch) {
         mobile = mMatch[2];
         username = beforePanda.substring(0, mMatch.index);
         passwordHash = beforePanda.substring(mMatch.index + mMatch[0].length);
      }
  }
  
  // Clean up
  if (username.startsWith("ticket-")) {
     // Ignore it's a support ticket
  } else if (username.startsWith("+1")) {
     username = username.substring(2);
  }
  
  if (username === "bks714009") {
     email = "bks714009@gmail.com";
     username = "bks";
  }
  
  username = username.replace(/[^a-zA-Z0-9_]/g, "").trim();
  
  map[u.id] = {
      id: u.id,
      username: username || `user_${u.id.slice(-6)}`,
      mobile: mobile || `999${Math.floor(1000000 + Math.random() * 9000000)}`,
      email: email || `${username.toLowerCase() || 'user'}@pandapanel.com`,
      passwordHash: passwordHash || "User@123",
      referralCode: referralCode || `REF${u.id.slice(-6).toUpperCase()}`,
      walletBalance,
      totalEarnings,
      referralIncome,
      kycStatus,
      role: "user"
  };
}

let code = "";
for (const [id, data] of Object.entries(map)) {
   code += `  if (userId === "${id}") {
    return ${JSON.stringify(data, null, 6).replace(/\"/g, '"')};
  }\n`;
}

fs.writeFileSync("generated_overrides.txt", code);
console.log("Wrote to generated_overrides.txt");
