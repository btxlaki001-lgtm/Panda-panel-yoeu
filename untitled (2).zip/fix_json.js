import fs from 'fs';
let content = fs.readFileSync('database_backup.json', 'utf8');

let lastComma = content.lastIndexOf('\n    },');
if (lastComma !== -1) {
    let fixed = content.substring(0, lastComma + 6); // include \n    } without the comma
    fixed += '\n  ]\n}\n';
    try {
        JSON.parse(fixed);
        fs.writeFileSync('database_backup_fixed.json', fixed);
        console.log('Fixed JSON successfully written.');
    } catch (e) {
        console.log('Failed to parse:', e.message);
    }
}
