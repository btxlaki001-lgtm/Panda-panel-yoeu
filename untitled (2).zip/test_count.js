import Database from 'better-sqlite3';
const db = new Database('local.db');
const users = db.prepare('SELECT id, username, role FROM users').all();
console.log(`SQLite count: ${users.length}`);
console.log('Sample of users:');
console.log(users.slice(0, 10));
console.log('Last 10 users:');
console.log(users.slice(-10));
