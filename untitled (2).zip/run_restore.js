import Database from 'better-sqlite3';
import fs from 'fs';

const db = new Database('local.db');
const data = JSON.parse(fs.readFileSync('./database_backup_fixed.json', 'utf-8'));

function insertData(table, rows) {
  if (!rows || rows.length === 0) return;
  const cols = Object.keys(rows[0]);
  const placeholders = cols.map(() => '?').join(',');
  const stmt = db.prepare(`INSERT OR IGNORE INTO ${table} (${cols.join(',')}) VALUES (${placeholders})`);
  
  const insertMany = db.transaction((items) => {
    for (const item of items) {
      // convert boolean and arrays if needed, sqlite needs strings or ints
      const values = cols.map(c => {
        let val = item[c];
        if (typeof val === 'boolean') return val ? 1 : 0;
        if (Array.isArray(val) || typeof val === 'object') {
            if (val === null) return null;
            return JSON.stringify(val);
        }
        if (typeof val === 'string' && val.endsWith('Z')) {
            // try to parse timestamp string to number since schema expects integer mode for dates
            // Wait, drizzle integer mode timestamp actually expects milliseconds number in DB
            const d = new Date(val);
            if (!isNaN(d.getTime())) return d.getTime();
        }
        return val;
      });
      stmt.run(values);
    }
  });
  
  insertMany(rows);
  console.log(`Restored ${rows.length} rows to ${table}`);
}

try {
  insertData('users', data.users);
  insertData('bank_accounts', data.bankAccounts || data.bank_accounts);
  insertData('notifications', data.notifications);
  insertData('support_tickets', data.supportTickets || data.support_tickets);
  insertData('site_settings', data.siteSettings || data.site_settings);
  insertData('transactions', data.transactions);
  console.log('Restore successful');
} catch (e) {
  console.error('Error during restore', e);
}
