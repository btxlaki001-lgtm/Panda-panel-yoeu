const { initializeApp } = require("firebase/app");
const { getFirestore, collection, getDocs } = require("firebase/firestore");
const fs = require("fs");

async function run() {
  const cfg = JSON.parse(fs.readFileSync("firebase-applet-config.json", "utf-8"));
  const app = initializeApp(cfg);
  const db = getFirestore(app, cfg.firestoreDatabaseId);
  
  const snap = await getDocs(collection(db, "users"));
  console.log("Firestore count:", snap.size);
  process.exit(0);
}
run().catch(console.error);
