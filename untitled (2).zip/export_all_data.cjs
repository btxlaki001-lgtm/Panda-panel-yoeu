const fs = require("fs");
const Database = require("better-sqlite3");
const { initializeApp } = require("firebase/app");
const { getFirestore, collection, getDocs } = require("firebase/firestore");

async function run() {
  if (!fs.existsSync("public")) fs.mkdirSync("public");
  
  // 1. Get SQLite Data
  let sqliteUsers = [];
  try {
     const db = new Database("local.db");
     sqliteUsers = db.prepare("SELECT * FROM users").all();
  } catch (e) {
     console.error("SQLite error:", e);
  }
  
  // 2. Get Firestore Data
  let firestoreUsers = [];
  try {
     const cfg = JSON.parse(fs.readFileSync("firebase-applet-config.json", "utf-8"));
     const app = initializeApp(cfg);
     const db = getFirestore(app);
     const snap = await getDocs(collection(db, "users"));
     firestoreUsers = snap.docs.map(d => d.data());
  } catch (e) {
     console.error("Firestore error:", e);
  }

  let rawJson = [];
  try {
     rawJson = JSON.parse(fs.readFileSync("all_184_users_full_data.json", "utf-8"));
  } catch(e) {}
  
  const finalData = {
     sqlite_users: sqliteUsers,
     firestore_users: firestoreUsers,
     original_json_data: rawJson
  };
  
  fs.writeFileSync("public/All_Users_Data.json", JSON.stringify(finalData, null, 2));
  console.log("JSON export created at public/All_Users_Data.json");
  process.exit(0);
}

run().catch(console.error);
