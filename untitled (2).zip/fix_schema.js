import fs from 'fs/promises';

async function main() {
  let code = await fs.readFile('src/db/schema.ts', 'utf8');

  code = code.replace(
    /import \{.*\} from "drizzle-orm\/pg-core";/g,
    'import { sqliteTable, text, integer, real, index } from "drizzle-orm/sqlite-core";'
  );

  code = code.replace(/pgTable/g, 'sqliteTable');
  code = code.replace(/timestamp\(([^)]+)\)/g, 'integer($1, { mode: "timestamp" })');
  code = code.replace(/decimal\(([^,]+),[^)]+\)/g, 'text($1)'); // use text for decimals
  code = code.replace(/boolean\(([^)]+)\)/g, 'integer($1, { mode: "boolean" })');
  code = code.replace(/jsonb\(([^)]+)\)/g, 'text($1, { mode: "json" })');
  code = code.replace(/\.defaultNow\(\)/g, '.$defaultFn(() => new Date())');
  code = code.replace(/\.default\(\[\]\)/g, '.default([] as any)');
  code = code.replace(/\.default\("0\.00"\)/g, '.default("0.00")');

  await fs.writeFile('src/db/schema.ts', code);
}
main();
