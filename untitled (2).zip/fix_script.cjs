const fs = require("fs");

let content = fs.readFileSync("restore_real_data_perfectly.ts", "utf-8");
const overrides = fs.readFileSync("generated_overrides.txt", "utf-8");

content = content.replace("// Corrupted parsing fallback for any other cases", overrides + "\n  // Corrupted parsing fallback for any other cases");

fs.writeFileSync("restore_real_data_perfectly.ts", content);
