import { apiFetch } from "./lib/api";
import React, { useState, useEffect } from "react";
import { 
  Shield, Landmark, Users, MessageSquare, Bell, LogOut, Key, UserCheck, 
  HelpCircle, ChevronRight, X, User as UserIcon, Settings, Calendar, Award, RefreshCw, Smartphone
} from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import AuthScreens from "./components/AuthScreens";
import UserDashboard from "./components/UserDashboard";
import DepositModule from "./components/DepositModule";
import WithdrawalModule from "./components/WithdrawalModule";
import BankManager from "./components/BankManager";
import ReferralSystem from "./components/ReferralSystem";
import SupportCenter from "./components/SupportCenter";
import AdminPanel from "./components/AdminPanel";
import LiveActivityTicker from "./components/LiveActivityTicker";
import CryptoModule from "./components/CryptoModule";
import { User, Transaction, Notification, SiteSettings, BankAccount } from "./types";
import { useLiveActivity } from "./hooks/useLiveActivity";

export default function App() {
  const [splash, setSplash] = useState(true);
  const [token, setToken] = useState<string | null>(localStorage.getItem("panda_token"));
  const { activities, isLocked: tickerLocked } = useLiveActivity();
  const [user, setUser] = useState<User | null>(null);
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [banks, setBanks] = useState<BankAccount[]>([]);
  const [settings, setSettings] = useState<SiteSettings | null>(null);
  
  // Tab control
  const [currentTab, setCurrentTab] = useState<"dashboard" | "deposit" | "withdraw" | "banks" | "referrals" | "support" | "profile" | "crypto">("dashboard");
  const [showNotifications, setShowNotifications] = useState(false);
  const [loadingStats, setLoadingStats] = useState(false);

  // Profile forms
  const [kycLoading, setKycLoading] = useState(false);
  const [oldPassword, setOldPassword] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [passError, setPassError] = useState<string | null>(null);
  const [passSuccess, setPassSuccess] = useState<string | null>(null);
  const [dbWakingMsg, setDbWakingMsg] = useState<string | null>(null);

  useEffect(() => {
    const handleWaking = (e: any) => {
      setDbWakingMsg(e.detail.message);
      setTimeout(() => setDbWakingMsg(null), 10000); // clear after 10s
    };
    window.addEventListener('db-waking-up', handleWaking);
    return () => window.removeEventListener('db-waking-up', handleWaking);
  }, []);


  // Auto-fill referral code from query params
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const refCode = params.get("ref");
    if (refCode) {
      localStorage.setItem("panda_ref_fill", refCode.toUpperCase());
    }
  }, []);

  // Splash Screen countdown
  useEffect(() => {
    const timer = setTimeout(() => {
      setSplash(false);
    }, 1800);
    return () => clearTimeout(timer);
  }, []);

  const fetchProfile = async (authToken: string) => {
    try {
      const response = await apiFetch("/api/auth/profile", {
        headers: { "Authorization": `Bearer ${authToken}` }
      });
      const contentType = response.headers.get("content-type");
      if (!contentType || !contentType.includes("application/json")) return;
      const data = await response.json();
      if (response.ok) {
        setUser(data);
      } else {
        // Clear stale token
        handleLogout();
      }
    } catch (err) {
      console.error("Error loading user profile", err);
    }
  };

  const fetchStats = async (authToken: string) => {
    try {
      setLoadingStats(true);
      const response = await apiFetch("/api/dashboard-stats", {
        headers: { "Authorization": `Bearer ${authToken}` }
      });
      const contentType = response.headers.get("content-type");
      if (!contentType || !contentType.includes("application/json")) return;
      const data = await response.json();
      if (response.ok) {
        setTransactions(data.transactions || []);
        if (user) {
          setUser(prev => prev ? {
            ...prev,
            walletBalance: data.walletBalance,
            totalEarnings: data.totalEarnings,
            referralIncome: data.referralIncome,
            kycStatus: data.kycStatus
          } : null);
        }
      }
    } catch (err) {
      console.error("Error loading statistics", err);
    } finally {
      setLoadingStats(false);
    }
  };

  const fetchNotifications = async (authToken: string) => {
    try {
      const response = await apiFetch("/api/user-notifications", {
        headers: { "Authorization": `Bearer ${authToken}` }
      });
      const contentType = response.headers.get("content-type");
      if (!contentType || !contentType.includes("application/json")) return;
      const data = await response.json();
      if (response.ok && Array.isArray(data)) {
        setNotifications(data);
      }
    } catch (err) {
      console.error("Error loading notifications", err);
    }
  };

  const fetchBanks = async (authToken: string) => {
    try {
      const response = await apiFetch("/api/banks", {
        headers: { "Authorization": `Bearer ${authToken}` }
      });
      const data = await response.json();
      if (Array.isArray(data)) {
        setBanks(data);
      }
    } catch (err) {
      console.error("Error loading bank accounts", err);
    }
  };

  const fetchGlobalSettings = async () => {
    try {
      const response = await apiFetch("/api/settings");
      const contentType = response.headers.get("content-type");
      if (!contentType || !contentType.includes("application/json")) return;
      const data = await response.json();
      if (response.ok) {
        setSettings(data);
      }
    } catch (err) {
      console.error("Error loading settings configuration", err);
    }
  };

  const handleRefreshData = () => {
    if (token) {
      fetchProfile(token);
      fetchStats(token);
      fetchNotifications(token);
      fetchBanks(token);
    }
    fetchGlobalSettings();
  };

  useEffect(() => {
    if (token) {
      handleRefreshData();
      // Poll notifications and stats every 15s to keep it dynamic and live
      const interval = setInterval(() => {
        if (token) {
          fetchStats(token);
          fetchNotifications(token);
        }
      }, 15000);
      return () => clearInterval(interval);
    } else {
      fetchGlobalSettings();
    }
  }, [token]);

  const handleLoginSuccess = (newToken: string, loginUser: { id: string; username: string; role: "user" | "admin" }) => {
    localStorage.setItem("panda_token", newToken);
    setToken(newToken);
    setCurrentTab("dashboard");
  };

  const handleLogout = () => {
    localStorage.removeItem("panda_token");
    setToken(null);
    setUser(null);
    setTransactions([]);
    setNotifications([]);
    setCurrentTab("dashboard");
  };

  const handleKycSubmit = async () => {
    if (!token) return;
    setKycLoading(true);
    try {
      const response = await apiFetch("/api/auth/kyc", {
        method: "POST",
        headers: { "Authorization": `Bearer ${token}` }
      });
      if (response.ok) {
        handleRefreshData();
      }
    } catch (err) {
      console.error(err);
    } finally {
      setKycLoading(false);
    }
  };

  const handlePasswordChange = async (e: React.FormEvent) => {
    e.preventDefault();
    setPassError(null);
    setPassSuccess(null);

    if (!oldPassword || !newPassword) {
      setPassError("All fields are required");
      return;
    }

    try {
      const response = await apiFetch("/api/auth/change-password", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Authorization": `Bearer ${token}`
        },
        body: JSON.stringify({ oldPassword, newPassword })
      });
      const data = await response.json();
      if (!response.ok) {
        throw new Error(data.error || "Password change failed");
      }
      setPassSuccess("Password updated successfully!");
      setOldPassword("");
      setNewPassword("");
    } catch (err: any) {
      setPassError(err.message);
    }
  };

  const markNotificationsAsRead = async () => {
    if (!token) return;
    try {
      await apiFetch("/api/user-notifications/mark-read", {
        method: "POST",
        headers: { "Authorization": `Bearer ${token}` }
      });
      fetchNotifications(token);
    } catch (err) {
      console.error(err);
    }
  };

  const handleToggleBankStatus = async (bankId: string, isActive: boolean) => {
    if (!token) return;
    try {
      const response = await apiFetch(`/api/banks/${bankId}/toggle`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Authorization": `Bearer ${token}`
        },
        body: JSON.stringify({ isActive })
      });
      if (response.ok) {
        fetchBanks(token);
      }
    } catch (err) {
      console.error("Error toggling bank status", err);
    }
  };

  const unreadCount = notifications.filter(n => !n.read).length;

  const urlParams = new URLSearchParams(window.location.search);
  const showAdminGate = urlParams.get("mode") === "admin";

  return (
    <div className="min-h-screen bg-black text-slate-200 font-sans flex flex-col antialiased selection:bg-red-500/30 selection:text-red-400">
      
      {/* Dynamic Animated Splash Screen */}
      <AnimatePresence>
        {splash && (
          <motion.div
            key="splash"
            initial={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.4 }}
            className="fixed inset-0 z-50 bg-black flex flex-col items-center justify-center p-4"
          >
            <motion.div
              initial={{ scale: 0.7, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              transition={{ delay: 0.2, type: "spring", stiffness: 100 }}
              className="w-24 h-24 rounded-3xl bg-slate-900 border border-slate-800 p-0 overflow-hidden shadow-[0_0_40px_rgba(239,68,68,0.2)] mb-6 flex items-center justify-center"
            >
              <img src="/src/assets/images/panda_penal_logo_1786117256951.jpg" alt="Logo" className="w-full h-full object-cover rounded-full" referrerPolicy="no-referrer" />
            </motion.div>
            <motion.h1
              initial={{ y: 15, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              transition={{ delay: 0.4 }}
              className="text-4xl font-black bg-gradient-to-r from-red-400 via-rose-500 to-orange-300 bg-clip-text text-transparent tracking-tight"
            >
              PANDA PANEL
            </motion.h1>
            <motion.p
              initial={{ opacity: 0 }}
              animate={{ opacity: 0.4 }}
              transition={{ delay: 0.8 }}
              className="text-[8px] text-slate-500 uppercase tracking-[2px] mt-1 font-bold text-center"
            >
              Earn Premium Level Commissions
            </motion.p>
            <div className="mt-8 w-16 h-1 bg-slate-900 rounded-full overflow-hidden">
              <motion.div 
                initial={{ left: "-100%" }}
                animate={{ left: "100%" }}
                transition={{ repeat: Infinity, duration: 1.2, ease: "linear" }}
                className="h-full bg-red-500 w-1/2 relative rounded-full"
              />
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Main Container framed like a premium smartphone viewport for high density */}
      <div className="w-full max-w-md mx-auto flex-1 flex flex-col bg-black min-h-screen relative shadow-[0_0_50px_rgba(0,0,0,0.8)] border-x border-slate-900/40">
        
        {/* Top App Header with brand */}
        <header className="sticky top-0 z-30 bg-black/90 backdrop-blur-xl border-b border-slate-900/50 px-4 py-3 flex flex-col gap-2">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl overflow-hidden border border-slate-800 bg-slate-900">
                 <img src="/src/assets/images/panda_penal_logo_1786117256951.jpg" alt="Panda" className="w-full h-full object-cover rounded-full" referrerPolicy="no-referrer" />
              </div>
              <div className="flex flex-col">
                <span className="font-black text-xl tracking-tighter uppercase text-red-500 leading-none">
                PANDA PANEL™
                </span>
              </div>
            </div>

            <div className="flex items-center gap-1.5">
              <button 
                onClick={() => setCurrentTab("support")}
                className="w-14 h-14 bg-slate-900/50 border border-slate-800 rounded-xl flex flex-col items-center justify-center gap-1 transition active:scale-95"
              >
                <HelpCircle className="w-5 h-5 text-red-500" />
                <span className="text-[8px] font-bold text-slate-300 uppercase tracking-tighter">Help</span>
              </button>

              <button 
                onClick={() => {
                  setShowNotifications(true);
                  markNotificationsAsRead();
                }} 
                className="w-14 h-14 bg-slate-900/50 border border-slate-800 rounded-xl flex flex-col items-center justify-center gap-1 transition active:scale-95 relative"
              >
                <Bell className="w-5 h-5 text-red-500" />
                <span className="text-[8px] font-bold text-slate-300 uppercase tracking-tighter">Notifications</span>
                {unreadCount > 0 && (
                  <span className="absolute top-2 right-2 w-1.5 h-1.5 bg-red-500 rounded-full animate-ping" />
                )}
              </button>

              <button 
                onClick={() => setCurrentTab("profile")}
                className="w-14 h-14 bg-slate-900/50 border border-slate-800 rounded-xl flex flex-col items-center justify-center gap-1 transition active:scale-95"
              >
                <UserIcon className="w-5 h-5 text-red-500" />
                <span className="text-[8px] font-bold text-slate-300 uppercase tracking-tighter">Account</span>
              </button>
            </div>
          </div>

          {/* Sub-ticker */}
          <div className="flex items-center justify-center overflow-hidden border-y border-slate-900/50 py-1">
            <div className="flex gap-8 animate-infinite-scroll">
              <span className="text-[10px] font-black text-red-500 uppercase tracking-widest whitespace-nowrap">
                • PANDA PANEL™ •
              </span>
              <span className="text-[10px] font-black text-red-500 uppercase tracking-widest whitespace-nowrap">
                • DEPOSITS LIVE •
              </span>
              <span className="text-[10px] font-black text-red-500 uppercase tracking-widest whitespace-nowrap">
                • WITHDRAWALS ACTIVE •
              </span>
            </div>
          </div>
        </header>

        {/* Content Flow Container */}
        <main className="flex-1 p-4 pb-20 space-y-6">
          <AnimatePresence mode="wait">
            {!token ? (
              /* Unauthorized Screens */
              <motion.div
                key="auth"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
              >
                <AuthScreens 
                  onLoginSuccess={handleLoginSuccess} 
                  adminAutoToggle={() => handleLoginSuccess("admin-1", { id: "admin-1", username: "admin", role: "admin" })}
                  showAdminGate={showAdminGate}
                />
                
                {/* Global Live activity shown on auth for security showcase */}
                <div className="mt-8">
                  <LiveActivityTicker activities={activities} isLocked={tickerLocked} />
                </div>
              </motion.div>
            ) : !user ? (
              /* Loading Profile */
              <div className="flex flex-col items-center justify-center py-20">
                <RefreshCw className="w-8 h-8 text-red-400 animate-spin" />
                <p className="text-xs text-slate-500 mt-2 font-mono">Connecting securely to PANDA ledger...</p>
              </div>
            ) : (
              /* Authorized Screens */
              <motion.div
                key="main"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                className="space-y-6"
              >
                {/* Admin Quick Redirection Access Banner */}
                {user.role === "admin" && (
                  <div className="p-3 bg-red-500/10 border border-red-500/20 rounded-2xl flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <Settings className="w-4 h-4 text-red-500 animate-spin" />
                      <div className="text-xs">
                        <span className="font-extrabold text-red-400">Control Panel Loaded</span>
                        <p className="text-[10px] text-slate-400 mt-0.5">Manage deposits, withdraws & site settings</p>
                      </div>
                    </div>
                    <button
                      onClick={() => setCurrentTab("support")} // We use standard tabs or render AdminPanel overlay
                      className="text-[10px] bg-red-500 hover:bg-red-400 text-white font-extrabold px-2.5 py-1 rounded-lg transition shrink-0"
                    >
                      Admin Panel
                    </button>
                  </div>
                )}

                {/* Main Dynamic View routing switcher */}
                {currentTab === "dashboard" && settings && (
                  <div className="space-y-6">
                    <UserDashboard 
                      user={user}
                      settings={settings}
                      transactions={transactions}
                      onNavigate={(tab) => setCurrentTab(tab)}
                      onRefresh={handleRefreshData}
                      unreadNotificationsCount={unreadCount}
                      onOpenNotifications={() => {
                        setShowNotifications(true);
                        markNotificationsAsRead();
                      }}
                      onKycSubmit={() => setCurrentTab("profile")}
                      banks={banks}
                      onToggleBankStatus={handleToggleBankStatus}
                      tickerActivities={activities}
                      tickerLocked={tickerLocked}
                    />

                    {/* Global live feed ledger ticker */}
                    <LiveActivityTicker activities={activities} isLocked={tickerLocked} />
                  </div>
                )}

                {currentTab === "deposit" && settings && (
                  <DepositModule 
                    settings={settings}
                    onBack={() => setCurrentTab("dashboard")}
                    token={token}
                    onRefresh={handleRefreshData}
                    tickerActivities={activities}
                    tickerLocked={tickerLocked}
                  />
                )}

                {currentTab === "withdraw" && settings && (
                  <WithdrawalModule 
                    settings={settings}
                    walletBalance={user.walletBalance}
                    onBack={() => setCurrentTab("dashboard")}
                    token={token}
                    onRefresh={handleRefreshData}
                    transactions={transactions}
                  />
                )}

                {currentTab === "banks" && (
                  <BankManager 
                    onBack={() => setCurrentTab("dashboard")}
                    token={token}
                  />
                )}

                {currentTab === "referrals" && (
                  <ReferralSystem 
                    onBack={() => setCurrentTab("dashboard")}
                    token={token}
                  />
                )}

                {currentTab === "support" && user.role === "admin" ? (
                  /* Admin Panel directly overrides Support Tab for Admins */
                  <AdminPanel 
                    onBack={() => setCurrentTab("dashboard")}
                    token={token}
                  />
                ) : currentTab === "support" && settings && (
                  <SupportCenter 
                    settings={settings}
                    onBack={() => setCurrentTab("dashboard")}
                    token={token}
                  />
                )}

                {currentTab === "crypto" && settings && (
                  <CryptoModule 
                    user={user}
                    settings={settings}
                    onBack={() => setCurrentTab("dashboard")}
                    token={token}
                    onRefresh={handleRefreshData}
                  />
                )}

                {currentTab === "profile" && (
                  <div className="space-y-6">
                    {/* User Info Details Summary */}
                    <div className="bg-slate-900 border border-slate-800 rounded-3xl p-5 text-center relative overflow-hidden">
                      <div className="w-16 h-16 rounded-2xl bg-gradient-to-tr from-red-500 to-rose-300 flex items-center justify-center font-bold text-white text-2xl mx-auto shadow-md">
                        {user.username.substring(0, 2).toUpperCase()}
                      </div>
                      <h3 className="font-extrabold text-slate-100 text-lg mt-3">{user.username}</h3>
                      <p className="text-xs text-slate-400 mt-0.5 font-mono">{user.email || "No email linked"}</p>

                      <div className="mt-4 flex justify-center gap-2">
                        <span className="text-[10px] px-2.5 py-1 bg-slate-950 rounded-xl border border-slate-850 font-bold text-slate-300">
                          ID: {user.id.substring(0, 8).toUpperCase()}
                        </span>
                        <span className={`text-[10px] px-2.5 py-1 rounded-xl border font-bold ${
                          user.kycStatus === "Approved" 
                            ? "bg-green-500/10 text-green-400 border-green-500/20" 
                            : user.kycStatus === "Pending"
                            ? "bg-red-500/10 text-red-400 border-red-500/20 animate-pulse"
                            : "bg-red-500/10 text-red-400 border-red-500/20"
                        }`}>
                          KYC: {user.kycStatus}
                        </span>
                      </div>
                    </div>

                    {/* KYC Document Submission Module */}
                    {user.kycStatus !== "Approved" && (
                      <div className="bg-slate-900 border border-slate-800 rounded-3xl p-5 space-y-3">
                        <h4 className="text-xs font-bold uppercase tracking-wider text-red-500 flex items-center gap-1.5">
                          <UserCheck className="w-4 h-4 text-red-500" /> Complete KYC Credentials
                        </h4>
                        <p className="text-xs text-slate-400 leading-normal">
                          Provide secure document verification details below. Approval will instantly remove withdraw limit locks.
                        </p>

                        {user.kycStatus === "Not Submitted" ? (
                          <button
                            onClick={handleKycSubmit}
                            disabled={kycLoading}
                            className="w-full bg-red-500 hover:bg-red-400 text-white text-xs font-bold py-2 px-4 rounded-xl transition flex justify-center items-center gap-1"
                          >
                            <span>{kycLoading ? "Submitting..." : "Apply Instantly for KYC Verification"}</span>
                          </button>
                        ) : (
                          <div className="p-3 bg-slate-950 rounded-2xl border border-slate-850 text-center">
                            <span className="text-xs text-red-400 font-bold block animate-pulse">Verification Underway</span>
                            <p className="text-[10px] text-slate-500 mt-0.5">Please allow up to 24 hours for manual review clearance.</p>
                          </div>
                        )}
                      </div>
                    )}

                    {/* Change Password Form */}
                    <div className="bg-slate-900 border border-slate-800 rounded-3xl p-5 space-y-4">
                      <h4 className="text-xs font-bold uppercase tracking-wider text-red-500 flex items-center gap-1.5">
                        <Key className="w-4 h-4 text-red-500" /> Security Settings
                      </h4>

                      {passError && <div className="p-2 bg-red-950/40 border border-red-900/50 text-red-400 text-xs rounded-xl">{passError}</div>}
                      {passSuccess && <div className="p-2 bg-green-950/40 border border-green-900/50 text-green-400 text-xs rounded-xl">{passSuccess}</div>}

                      <form onSubmit={handlePasswordChange} className="space-y-3 text-xs">
                        <div>
                          <label className="block text-slate-400 font-semibold mb-1">Current Password</label>
                          <input
                            type="password"
                            required
                            value={oldPassword}
                            onChange={(e) => setOldPassword(e.target.value)}
                            placeholder="Current account password"
                            className="w-full bg-slate-950 border border-slate-850 focus:border-red-500 rounded-xl px-4 py-2.5 text-slate-200 outline-none transition"
                          />
                        </div>
                        <div>
                          <label className="block text-slate-400 font-semibold mb-1">New Password</label>
                          <input
                            type="password"
                            required
                            value={newPassword}
                            onChange={(e) => setNewPassword(e.target.value)}
                            placeholder="Create new secure password"
                            className="w-full bg-slate-950 border border-slate-850 focus:border-red-500 rounded-xl px-4 py-2.5 text-slate-200 outline-none transition"
                          />
                        </div>
                        <button
                          type="submit"
                          className="w-full bg-slate-950 hover:bg-slate-900 border border-slate-800 text-slate-200 text-xs font-bold py-2.5 px-4 rounded-xl transition"
                        >
                          Update Password Credentials
                        </button>
                      </form>
                    </div>

                    {/* Sign out block */}
                    <button
                      onClick={handleLogout}
                      className="w-full bg-red-600/10 hover:bg-red-600/25 border border-red-500/20 text-red-400 text-xs font-extrabold py-3.5 rounded-2xl flex items-center justify-center gap-2 transition"
                    >
                      <LogOut className="w-4 h-4 text-red-500" />
                      <span>Log Out PANDA PANEL Session</span>
                    </button>
                  </div>
                )}
              </motion.div>
            )}
          </AnimatePresence>
        </main>

        {/* Global Notifications Dialog Modal Sheet Overlay */}
        <AnimatePresence>
          {showNotifications && (
            <motion.div
              key="notifications-sheet"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 z-40 bg-black/60 backdrop-blur-sm flex justify-center items-end"
              onClick={() => setShowNotifications(false)}
            >
              <motion.div
                initial={{ y: "100%" }}
                animate={{ y: 0 }}
                exit={{ y: "100%" }}
                transition={{ type: "spring", damping: 25, stiffness: 220 }}
                className="w-full max-w-md bg-slate-900 rounded-t-[32px] border-t border-slate-800 p-6 max-h-[80vh] overflow-y-auto space-y-4"
                onClick={(e) => e.stopPropagation()}
              >
                <div className="flex justify-between items-center pb-2 border-b border-slate-800">
                  <h3 className="text-sm font-black uppercase text-red-500 tracking-wider flex items-center gap-1.5">
                    <Bell className="w-4 h-4 text-red-500" /> Notifications Feed
                  </h3>
                  <button 
                    onClick={() => setShowNotifications(false)}
                    className="p-1 hover:bg-slate-800 rounded-lg text-slate-400 hover:text-white"
                  >
                    <X className="w-4 h-4" />
                  </button>
                </div>

                <div className="space-y-3 text-xs">
                  {notifications.length === 0 ? (
                    <p className="text-center text-slate-500 py-6">Your inbox is empty.</p>
                  ) : (
                    notifications.map((notif) => (
                      <div 
                        key={notif.id}
                        className={`p-3.5 rounded-2xl border ${
                          notif.read ? "bg-slate-950/40 border-slate-855" : "bg-slate-950 border-red-500/30 text-slate-100"
                        }`}
                      >
                        <div className="flex justify-between items-start gap-2">
                          <span className="font-extrabold text-slate-200">{notif.title}</span>
                          <span className="text-[9px] text-slate-500 font-mono shrink-0">{new Date(notif.createdAt).toLocaleDateString()}</span>
                        </div>
                        <p className="text-slate-400 mt-1 leading-relaxed text-[11px]">{notif.message}</p>
                      </div>
                    ))
                  )}
                </div>
              </motion.div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Global Bottom Navigation Sticky Dock Bar */}
        {token && user && (
          <nav className="fixed bottom-0 left-1/2 -translate-x-1/2 w-full max-w-md bg-slate-950/95 backdrop-blur-md border-t border-slate-900 px-4 py-2 flex justify-around items-center z-30">
            <button
              onClick={() => setCurrentTab("dashboard")}
              className={`flex flex-col items-center gap-1 transition ${
                currentTab === "dashboard" ? "text-red-400" : "text-slate-500 hover:text-slate-300"
              }`}
            >
              <Smartphone className="w-5 h-5" />
              <span className="text-[10px] font-bold">Home</span>
            </button>

            <button
              onClick={() => setCurrentTab("banks")}
              className={`flex flex-col items-center gap-1 transition ${
                currentTab === "banks" ? "text-red-400" : "text-slate-500 hover:text-slate-300"
              }`}
            >
              <Landmark className="w-5 h-5" />
              <span className="text-[10px] font-bold">Payees</span>
            </button>

            <button
              onClick={() => setCurrentTab("referrals")}
              className={`flex flex-col items-center gap-1 transition ${
                currentTab === "referrals" ? "text-red-400" : "text-slate-500 hover:text-slate-300"
              }`}
            >
              <Users className="w-5 h-5" />
              <span className="text-[10px] font-bold">Referrals</span>
            </button>

            <button
              onClick={() => setCurrentTab("support")}
              className={`flex flex-col items-center gap-1 transition ${
                currentTab === "support" ? "text-red-400" : "text-slate-500 hover:text-slate-300"
              }`}
            >
              <MessageSquare className="w-5 h-5" />
              <span className="text-[10px] font-bold">
                {user.role === "admin" ? "Control" : "Support"}
              </span>
            </button>

            <button
              onClick={() => setCurrentTab("profile")}
              className={`flex flex-col items-center gap-1 transition ${
                currentTab === "profile" ? "text-red-400" : "text-slate-500 hover:text-slate-300"
              }`}
            >
              <UserIcon className="w-5 h-5" />
              <span className="text-[10px] font-bold">Profile</span>
            </button>
          </nav>
        )}
      </div>
    </div>
  );
}
