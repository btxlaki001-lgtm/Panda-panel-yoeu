import React, { useState } from "react";
import { 
  Wallet, TrendingUp, Users, HelpCircle, Bell, ArrowDown, 
  ArrowUp, History, MessageSquare, Clipboard, ExternalLink, ShieldCheck, 
  ShieldAlert, Shield, Clock, Headset, BarChart3, Send, Plus, Lock,
  Bitcoin, Smartphone
} from "lucide-react";
import { motion } from "motion/react";
import LiveActivityTicker from "./LiveActivityTicker";
import { Transaction, User, SiteSettings, BankAccount } from "../types";

interface UserDashboardProps {
  user: User;
  settings: SiteSettings;
  transactions: Transaction[];
  onNavigate: (tab: "dashboard" | "deposit" | "withdraw" | "banks" | "referrals" | "support" | "profile" | "crypto") => void;
  onRefresh: () => void;
  unreadNotificationsCount: number;
  onOpenNotifications: () => void;
  onKycSubmit: () => void;
  banks: BankAccount[];
  onToggleBankStatus: (id: string, isActive: boolean) => void;
  tickerActivities: any[];
  tickerLocked: boolean;
}

export default function UserDashboard({ 
  user, 
  settings, 
  transactions, 
  onNavigate, 
  onRefresh, 
  unreadNotificationsCount, 
  onOpenNotifications,
  onKycSubmit,
  banks,
  onToggleBankStatus,
  tickerActivities,
  tickerLocked
}: UserDashboardProps) {
  const [copiedCode, setCopiedCode] = useState(false);

  // Calculate Ticker Stats
  const tickerDeposits = tickerActivities.filter(a => a.type === "deposit").reduce((sum, a) => sum + a.amount, 0);
  const tickerWithdrawals = tickerActivities.filter(a => a.type === "withdrawal").reduce((sum, a) => sum + a.amount, 0);
  const tickerVolume = tickerDeposits + tickerWithdrawals;
  const tickerCommissionRaw = tickerVolume * 0.1;
  const pandaBalanceDisplayRaw = (tickerDeposits - tickerWithdrawals) - tickerCommissionRaw;

  // Gate the system behind 2000 deposit condition
  const hasMinDeposit = transactions.some(t => t.type === "deposit" && t.status === "approved" && Number(t.amount) >= 2000);
  const tickerCommission = hasMinDeposit ? tickerCommissionRaw : 0;
  const pandaBalanceDisplay = hasMinDeposit ? pandaBalanceDisplayRaw : 0;

  const handleCopyReferral = () => {
    const referralLink = `${window.location.origin}/?ref=${user.referralCode}`;
    navigator.clipboard.writeText(referralLink);
    setCopiedCode(true);
    setTimeout(() => setCopiedCode(false), 2000);
  };

  const getKycBadgeColor = () => {
    switch(user.kycStatus) {
      case "Approved": return "bg-green-500/10 text-green-400 border-green-500/20";
      case "Pending": return "bg-red-500/10 text-red-400 border-red-500/20 animate-pulse";
      default: return "bg-red-500/10 text-red-400 border-red-500/20";
    }
  };

  return (
    <div className="space-y-6">
      {/* Balance & Commission Section */}
      <div className="grid grid-cols-12 gap-3">
        {/* Main Balance Card */}
        <div className="col-span-12 bg-gradient-to-br from-red-400 via-rose-500 to-rose-600 rounded-[32px] p-6 relative overflow-hidden shadow-xl min-h-[180px] flex flex-col justify-between">
          <div className="flex justify-between items-start">
            <div className="flex flex-col">
              <span className="text-[10px] font-black text-rose-900 uppercase tracking-tighter leading-none">
                PANDA PANEL
              </span>
              <span className="text-[10px] font-black text-rose-900 uppercase tracking-tighter">
                BALANCE
              </span>
            </div>
            <div className="bg-green-600/90 backdrop-blur-sm px-3 py-1 rounded-full border border-white/20">
              <span className="text-[9px] font-black text-white uppercase whitespace-nowrap">
                10% COMMISSION
              </span>
            </div>
          </div>

          <div className="mt-4">
            <span className="text-5xl font-black text-rose-950 tracking-tighter">
              ₹{(user.walletBalance + pandaBalanceDisplay).toLocaleString(undefined, { maximumFractionDigits: 0 })}
            </span>
          </div>

          {/* Abstract circle decoration */}
          <div className="absolute -bottom-10 -right-10 w-32 h-32 bg-red-400/20 rounded-full blur-2xl" />
        </div>

        {/* Action Grid */}
        <div className="col-span-7 grid grid-cols-2 gap-2">
          {[
            { id: "deposit", icon: ArrowDown, label: "DEPOSIT", color: "text-red-500", action: () => onNavigate("deposit") },
            { id: "withdraw", icon: ArrowUp, label: "WITHDRAW", color: "text-slate-400", action: () => onNavigate("withdraw") },
            { id: "history", icon: Clock, label: "HISTORY", color: "text-slate-400", action: () => onNavigate("profile") },
            { id: "support", icon: Headset, label: "SUPPORT", color: "text-slate-400", action: () => onNavigate("support") },
            { id: "activate", icon: ShieldCheck, label: "ACTIVATE", color: "text-slate-400", action: () => onNavigate("deposit") },
            { id: "crypto", icon: Bitcoin, label: "USDT EXCH", color: "text-red-500", action: () => onNavigate("crypto") },
          ].map((btn) => (
            <button
              key={btn.id}
              onClick={btn.action}
              className="bg-slate-900/60 border border-slate-800/80 rounded-2xl p-3 flex flex-col items-center justify-center gap-1.5 transition active:scale-95"
            >
              <btn.icon className={`w-5 h-5 ${btn.color}`} />
              <span className="text-[8px] font-black text-slate-500 uppercase tracking-tighter">{btn.label}</span>
            </button>
          ))}
        </div>

        {/* Side Stack */}
        <div className="col-span-5 flex flex-col gap-2">
          {/* Commission Earned */}
          <div className="flex-1 bg-slate-900/60 border border-slate-800/80 rounded-[28px] p-4 flex flex-col justify-between">
            <span className="text-[9px] font-black text-slate-500 uppercase tracking-tighter">
              EARNED COMMISSION
            </span>
            <span className="text-2xl font-black text-red-500 mt-2">
              ₹{(user.referralIncome + tickerCommission).toLocaleString(undefined, { maximumFractionDigits: 0 })}
            </span>
          </div>

          {/* Telegram Large Button */}
          <a
            href={settings.telegramSupport}
            target="_blank"
            rel="noopener noreferrer"
            className="flex-1 bg-slate-900/60 border border-slate-800/80 rounded-[28px] p-4 flex flex-col items-center justify-center gap-2 group transition active:scale-95"
          >
            <div className="p-2 bg-red-500/10 rounded-xl group-hover:bg-red-500 group-hover:text-black transition duration-300">
              <Send className="w-5 h-5 text-red-500 group-hover:text-black" />
            </div>
            <span className="text-[10px] font-black text-slate-400 uppercase tracking-tighter">TELEGRAM</span>
          </a>
        </div>
      </div>

      {/* Live Activity & Bank Accounts Row */}
      <div className="grid grid-cols-2 gap-4">
        {/* Live Activity Section */}
        <div className="space-y-3"><LiveActivityTicker activities={tickerActivities} isLocked={tickerLocked} /></div>

        {/* Bank Accounts Section */}
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <h3 className="text-[11px] font-black text-slate-100 uppercase tracking-widest">BANK ACCOUNTS</h3>
            <button 
              onClick={() => onNavigate("banks")}
              className="bg-slate-900 border border-slate-800 rounded-lg px-2 py-1 flex items-center gap-1 transition active:scale-95"
            >
              <Plus className="w-3 h-3 text-red-500" />
              <span className="text-[8px] font-black text-red-500 uppercase">Add</span>
            </button>
          </div>

          <div className="bg-slate-900/40 border border-slate-800/60 rounded-3xl p-4 h-[180px] overflow-y-auto space-y-2 custom-scrollbar">
            {banks.length === 0 ? (
              <div className="flex flex-col items-center justify-center text-center gap-4 h-full">
                <p className="text-[10px] font-bold text-slate-500 uppercase tracking-tighter leading-tight">
                  No bank accounts<br />linked
                </p>
                <button
                  onClick={() => onNavigate("banks")}
                  className="bg-red-500 hover:bg-red-400 text-white text-[10px] font-black uppercase px-6 py-2.5 rounded-xl transition shadow-lg shadow-red-500/10"
                >
                  Add Bank
                </button>
              </div>
            ) : (
              banks.map((bank) => (
                <div key={bank.id} className="bg-slate-950/60 border border-slate-800/50 rounded-2xl p-3 space-y-2">
                  <div className="flex justify-between items-start">
                    <div>
                      <div className="text-[9px] font-black text-red-500 uppercase">{bank.bankName}</div>
                      <div className="text-[10px] font-bold text-slate-200 truncate max-w-[100px]">{bank.holderName}</div>
                    </div>
                    <button
                      onClick={() => onToggleBankStatus(bank.id, !bank.isActive)}
                      className={`px-2 py-0.5 rounded-full text-[8px] font-black uppercase transition ${
                        bank.isActive ? "bg-green-500/10 text-green-400 border border-green-500/20" : "bg-red-500/10 text-red-400 border border-red-500/20"
                      }`}
                    >
                      {bank.isActive ? "Active" : "Deactivated"}
                    </button>
                  </div>
                  <div className="text-[9px] font-mono text-slate-500">{bank.accountNumber}</div>
                </div>
              ))
            )}
          </div>
        </div>
      </div>

      {/* Top Investors & Live User Activity Row */}
      <div className="grid grid-cols-2 gap-4 pb-4">
        {/* Top Investors Section */}
        <div className="space-y-3">
          <div className="flex items-center gap-2">
            <h3 className="text-[11px] font-black text-slate-100 uppercase tracking-widest">TOP INVESTORS</h3>
            <div className="bg-red-600 px-2 py-0.5 rounded-full flex items-center gap-1">
              <span className="text-[8px] font-black text-white uppercase">LIVE</span>
            </div>
          </div>
          
          <div className="bg-slate-900/40 border border-slate-800/60 rounded-3xl p-4 h-[240px] flex flex-col gap-2 overflow-hidden">
            {[
              { name: "Arun V.", amount: "₹85,000", rank: "01" },
              { name: "Rahul S.", amount: "₹62,400", rank: "02" },
              { name: "Deepak K.", amount: "₹54,200", rank: "03" },
              { name: "Amit P.", amount: "₹48,900", rank: "04" },
            ].map((investor) => (
              <div key={investor.rank} className="flex items-center justify-between bg-slate-950/40 p-2.5 rounded-2xl border border-slate-800/40">
                <div className="flex items-center gap-3">
                  <span className="text-[9px] font-black text-red-500/60">{investor.rank}</span>
                  <span className="text-[10px] font-black text-slate-300">{investor.name}</span>
                </div>
                <span className="text-[10px] font-black text-red-500">{investor.amount}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Live User Activity Section */}
        <div className="space-y-3">
          
          <div className="flex items-center gap-2">
            <h3 className="text-[11px] font-black text-slate-100 uppercase tracking-widest">TRANSACTION HISTORY</h3>
            <div className="bg-slate-800 px-2 py-0.5 rounded-full flex items-center gap-1">
              <span className="text-[8px] font-black text-white uppercase">AUTO-SYNC</span>
            </div>
          </div>
          <div className="bg-slate-900/40 border border-slate-800/60 rounded-3xl overflow-hidden h-[240px] flex flex-col">
            <div className="p-3 border-b border-slate-800/60 bg-slate-950/40 flex items-center gap-2">
               <Clock className="w-3 h-3 text-slate-500" />
               <span className="text-[9px] font-black text-slate-500 uppercase tracking-tighter">REAL-TIME RECORDS</span>
            </div>
            <div className="p-3 space-y-3 overflow-y-auto custom-scrollbar flex-1">
              {transactions.length === 0 ? (
                <p className="text-xs text-slate-500 text-center py-4">No transactions yet.</p>
              ) : (
                transactions.map((act) => {
                  const date = new Date(act.createdAt);
                  const timeStr = date.toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'});
                  return (
                    <div key={act.id} className="flex flex-col gap-0.5">
                      <div className="flex justify-between items-center">
                        <span className="text-[10px] font-black text-slate-200 capitalize">{act.type.replace('_', ' ')}</span>
                        <span className="text-[8px] font-bold text-slate-600 uppercase">{timeStr}</span>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="text-[9px] font-bold text-slate-500 uppercase tracking-tighter">{act.status}</span>
                        <span className={"text-[10px] font-bold uppercase tracking-tighter " + (act.type === 'deposit' ? 'text-green-500' : 'text-red-500')}>
                          {act.type === 'deposit' ? '+' : '-'}₹{act.amount.toLocaleString()}
                        </span>
                      </div>
                    </div>
                  );
                })
              )}
            </div>
</div>
        </div>
      </div>

      {/* Referral Link Quick Access */}
      <div className="bg-slate-900/40 border border-slate-800/60 rounded-3xl p-5 relative overflow-hidden">
        <div className="flex justify-between items-center mb-4">
          <h4 className="text-[11px] font-black text-slate-100 uppercase tracking-widest flex items-center gap-2">
            <Users className="w-4 h-4 text-red-500" /> REFERRAL LINK
          </h4>
          <div className="bg-red-600 px-2 py-0.5 rounded-full flex items-center gap-1">
            <span className="text-[8px] font-black text-white uppercase">LIVE</span>
          </div>
        </div>
        
        <div className="flex items-center gap-2 bg-slate-950/80 border border-slate-800/50 rounded-2xl p-2 pl-4">
          <span className="font-mono text-[10px] font-black text-red-500 tracking-widest truncate flex-1">{user.referralCode}</span>
          <button
            onClick={handleCopyReferral}
            className="bg-slate-900 hover:bg-slate-800 border border-slate-800 text-[9px] font-black text-slate-200 px-4 py-2 rounded-xl transition uppercase"
          >
            {copiedCode ? "Copied" : "Copy"}
          </button>
        </div>
      </div>

      {/* Mobile App Download Promotion */}
      <div className="bg-gradient-to-r from-red-600/20 to-rose-600/20 border border-red-500/30 rounded-3xl p-5 flex items-center justify-between group cursor-pointer hover:border-red-500/50 transition">
        <div className="flex items-center gap-4">
          <div className="w-12 h-12 bg-slate-900 rounded-2xl border border-slate-800 flex items-center justify-center shadow-lg group-hover:scale-110 transition duration-300">
            <Smartphone className="w-6 h-6 text-red-500" />
          </div>
          <div>
            <h4 className="text-[11px] font-black text-slate-100 uppercase tracking-widest">MOBILE APPLICATION</h4>
            <p className="text-[9px] text-slate-400 font-bold uppercase tracking-tighter mt-0.5">Download PANDA PANEL v2.0 APK</p>
          </div>
        </div>
        <button className="bg-red-500 hover:bg-red-400 text-white p-2.5 rounded-xl shadow-lg transition active:scale-90">
          <ArrowDown className="w-4 h-4" />
        </button>
      </div>

      {/* Panda Logo Branding */}
      <div className="flex flex-col items-center justify-center pt-8 pb-4">
        <div className="w-16 h-16 rounded-2xl bg-slate-900 border border-slate-800 p-0 overflow-hidden shadow-[0_0_20px_rgba(239,68,68,0.3)] animate-bounce duration-[2000ms]">
          <img src="/src/assets/images/panda_penal_logo_1786117256951.jpg" alt="Panda Logo" className="w-full h-full object-cover rounded-full" referrerPolicy="no-referrer" />
        </div>
        <div className="w-16 h-2 bg-red-500/20 blur-xl rounded-full mt-4 scale-x-150" />
      </div>
    </div>
  );
}
