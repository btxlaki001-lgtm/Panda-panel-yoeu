import { apiFetch } from "../lib/api";
import React, { useEffect, useState } from "react";
import { ArrowUpRight, ArrowDownLeft, RefreshCw, Users, Lock } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";

interface Activity {
  id: string;
  username: string;
  type: "deposit" | "withdrawal";
  amount: number;
  status: string;
  timeAgo: string;
}

interface LiveActivityTickerProps {
  activities?: Activity[];
  isLocked?: boolean;
}

export default function LiveActivityTicker({ activities: propsActivities, isLocked: propsIsLocked }: LiveActivityTickerProps) {
  const [internalActivities, setInternalActivities] = useState<Activity[]>([]);
  const [isLocked, setIsLocked] = useState(true);

  const fetchLiveActivity = async () => {
    try {
      const response = await apiFetch("/api/live-activity", {
        headers: {
          "Authorization": `Bearer ${localStorage.getItem("panda_token") || ""}`
        }
      });
      
      if (!response.ok) return;
      
      const contentType = response.headers.get("content-type");
      if (!contentType || !contentType.includes("application/json")) {
        return; // Skip if response is not JSON (e.g., auth proxy HTML)
      }
      
      const data = await response.json();
      if (data.isLocked !== undefined) setIsLocked(data.isLocked);
      if (data.activities) setInternalActivities(data.activities);
    } catch (err) {
      console.error("Error loading live activity ticker", err);
    }
  };

  useEffect(() => {
    if (propsActivities === undefined) {
      fetchLiveActivity();
      const interval = setInterval(fetchLiveActivity, 5000);
      return () => clearInterval(interval);
    }
  }, [propsActivities]);

  const activities = propsActivities !== undefined ? propsActivities : internalActivities;
  const locked = propsIsLocked !== undefined ? propsIsLocked : isLocked;

  if (!activities.length && !locked) return null;

  return (
    <div className="bg-[#0b0c10] border-t border-[#1a1b23] pt-6 relative overflow-hidden rounded-b-3xl">
      <div className="flex items-center gap-3 mb-6 px-2">
        <div className="w-6 h-6 rounded-md overflow-hidden border border-slate-800 bg-slate-900 shrink-0">
           <img src="/src/assets/images/panda_penal_logo_1786117256951.jpg" alt="P" className="w-full h-full object-cover rounded-full" referrerPolicy="no-referrer" />
        </div>
        <h3 className="text-[13px] uppercase font-extrabold tracking-[0.2em] text-white">
          LIVE ACTIVITY
        </h3>
        <span className="bg-red-600 text-white text-[9px] px-2 py-0.5 rounded-full flex items-center gap-1.5 font-bold tracking-wider">
          <div className="w-1.5 h-1.5 bg-white rounded-full animate-pulse"></div>
          LIVE
        </span>
      </div>

      {locked ? (
        <div className="bg-[#0f111a] border border-[#1a1b26] rounded-[2.5rem] p-10 flex flex-col items-center justify-center text-center mx-1 shadow-lg">
          <div className="w-[72px] h-[72px] border-2 border-[#1e202d] rounded-[2rem] flex items-center justify-center mb-6 bg-transparent">
            <Lock className="w-7 h-7 text-slate-400/80" strokeWidth={1.5} />
          </div>
          <h4 className="text-white font-extrabold text-[15px] mb-2.5 uppercase tracking-wide">LIVE DEPOSITS LOCKED</h4>
          <p className="text-[11px] text-slate-400 font-bold uppercase tracking-widest">DEPOSIT ₹2,000 TO UNLOCK</p>
        </div>
      ) : (
        <div className="space-y-3 max-h-[300px] overflow-y-auto pr-1 custom-scrollbar px-1">
          <AnimatePresence mode="popLayout">
            {activities.length === 0 ? (
              <p className="text-xs text-slate-500 text-center py-4">No recent live activity.</p>
            ) : (
              activities.map((activity) => (
                <motion.div
                  key={activity.id}
                  initial={{ opacity: 0, y: -10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, scale: 0.95 }}
                  transition={{ duration: 0.3 }}
                  className="flex items-center justify-between bg-[#0f111a] border border-[#1a1b26] rounded-2xl p-4 text-xs transition"
                >
                  <div className="flex items-center gap-4">
                    <div
                      className={`p-2.5 rounded-xl ${
                        activity.type === "deposit"
                          ? "bg-green-500/10 text-green-400"
                          : "bg-red-500/10 text-red-400"
                      }`}
                    >
                      {activity.type === "deposit" ? (
                        <ArrowDownLeft className="w-5 h-5" strokeWidth={2.5} />
                      ) : (
                        <ArrowUpRight className="w-5 h-5" strokeWidth={2.5} />
                      )}
                    </div>
                    <div>
                      <div className="font-bold text-slate-200 text-[13px] mb-1">{activity.username}</div>
                      <div className="text-[9px] text-slate-500 uppercase tracking-widest">
                        {activity.type} • <span className="text-green-500 font-bold capitalize">Confirmed by Admin</span>
                      </div>
                    </div>
                  </div>
                  <div className="text-right">
                    <div
                      className={`font-mono font-bold text-sm mb-1 tracking-tight ${
                        activity.type === "deposit" ? "text-green-400" : "text-red-400"
                      }`}
                    >
                      {activity.type === "deposit" ? "+" : "-"}₹{activity.amount.toLocaleString()}
                    </div>
                    <div className="text-[10px] text-slate-500 font-medium tracking-wide">{activity.timeAgo}</div>
                  </div>
                </motion.div>
              ))
            )}
          </AnimatePresence>
        </div>
      )}
    </div>
  );
}
