const fs = require("fs");
const Database = require("better-sqlite3");
const PDFDocument = require("pdfkit");
const { initializeApp } = require("firebase/app");
const { getFirestore, collection, getDocs } = require("firebase/firestore");

async function run() {
  if (!fs.existsSync("public")) fs.mkdirSync("public");
  
  // 1. Get SQLite Data
  let sqliteUsers = [];
  try {
     const db = new Database("local.db");
     sqliteUsers = db.prepare("SELECT * FROM users").all();
  } catch (e) {
     console.error("SQLite error:", e);
  }
  
  // 2. Get Firestore Data
  let firestoreUsers = [];
  try {
     const cfg = JSON.parse(fs.readFileSync("firebase-applet-config.json", "utf-8"));
     const app = initializeApp(cfg);
     const db = getFirestore(app);
     const snap = await getDocs(collection(db, "users"));
     firestoreUsers = snap.docs.map(d => d.data());
  } catch (e) {
     console.error("Firestore error:", e);
  }
  
  // 3. Write PDF
  const doc = new PDFDocument({ margin: 30, size: 'A4' });
  doc.pipe(fs.createWriteStream("public/All_Users_Data.pdf"));
  
  doc.fontSize(16).text("All Users Data Report (Local + Firestore)", { align: 'center' });
  doc.moveDown();
  
  doc.fontSize(12).text(`SQLite Users Count: ${sqliteUsers.length}`);
  doc.text(`Firestore Users Count: ${firestoreUsers.length}`);
  doc.moveDown();
  
  doc.fontSize(14).text("--- SQLite Users ---");
  doc.moveDown();
  for (const u of sqliteUsers) {
     doc.fontSize(9).text(JSON.stringify(u, null, 2));
     doc.moveDown(0.5);
  }
  
  doc.addPage();
  doc.fontSize(14).text("--- Firestore Users ---");
  doc.moveDown();
  for (const u of firestoreUsers) {
     doc.fontSize(9).text(JSON.stringify(u, null, 2));
     doc.moveDown(0.5);
  }
  
  // Also include the original JSON data if they want "all" data
  try {
     const rawJson = JSON.parse(fs.readFileSync("all_184_users_full_data.json", "utf-8"));
     doc.addPage();
     doc.fontSize(14).text(`--- Original Corrupted JSON (${rawJson.length} users) ---`);
     doc.moveDown();
     for (const u of rawJson) {
         doc.fontSize(9).text(JSON.stringify(u, null, 2));
         doc.moveDown(0.5);
     }
  } catch(e) {}
  
  doc.end();
  console.log("PDF created successfully at public/All_Users_Data.pdf");
}

run().catch(console.error);
